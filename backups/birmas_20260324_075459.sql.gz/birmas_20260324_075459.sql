--
-- PostgreSQL database dump
--

\restrict 05nu6niK3oEZ5lGiYGPov4aYshcx3MYBUqHLe167PFvLZLNZNyH0fwFiJFZfPFN

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: birmas_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO birmas_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: events; Type: TABLE; Schema: public; Owner: birmas_user
--

CREATE TABLE public.events (
    ts timestamp without time zone DEFAULT now() NOT NULL,
    camera_id character varying,
    product_brand character varying,
    product_name character varying,
    confidence double precision,
    id integer NOT NULL,
    label character varying,
    bbox character varying,
    event_type character varying DEFAULT 'added'::character varying
);


ALTER TABLE public.events OWNER TO birmas_user;

--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: birmas_user
--

CREATE SEQUENCE public.events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.events_id_seq OWNER TO birmas_user;

--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: birmas_user
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.ts;


--
-- Name: events_id_seq1; Type: SEQUENCE; Schema: public; Owner: birmas_user
--

CREATE SEQUENCE public.events_id_seq1
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.events_id_seq1 OWNER TO birmas_user;

--
-- Name: events_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: birmas_user
--

ALTER SEQUENCE public.events_id_seq1 OWNED BY public.events.id;


--
-- Name: product; Type: TABLE; Schema: public; Owner: birmas_user
--

CREATE TABLE public.product (
    class_id integer,
    class_name character varying NOT NULL,
    product_brand character varying NOT NULL,
    product_name character varying NOT NULL
);


ALTER TABLE public.product OWNER TO birmas_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: birmas_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying,
    password_hash character varying
);


ALTER TABLE public.users OWNER TO birmas_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: birmas_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO birmas_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: birmas_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: birmas_user
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq1'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: birmas_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: birmas_user
--

COPY public.events (ts, camera_id, product_brand, product_name, confidence, id, label, bbox, event_type) FROM stdin;
2026-02-15 00:24:36.411577	cam1	Corona	Extra 355ml	0.8397	1151	47corona_eS	[274,299,209,186]	sold
2025-08-22 00:22:13.411577	cam1	Extra Joss	Ultimate 250ml	0.686	1152	53extrajK	[369,97,176,73]	restock
2026-02-18 10:55:36.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.6784	1153	01ot_apiptB	[196,364,43,149]	sold
2025-11-04 07:28:48.411577	cam1	Jose Cuervo	750ml	0.7055	1154	50josecuervoB	[351,230,129,100]	added
2025-03-29 17:55:51.411577	cam1	Canard	Kolsch 330ml	0.6973	1155	04canard_kK	[160,39,147,69]	restock
2025-03-22 15:54:04.411577	cam1	Iceland	Original 700ml	0.9304	1156	03icelandB	[399,302,160,148]	restock
2025-07-06 04:54:12.411577	cam1	Suntory Roku	Gin 700ml	0.7868	1157	43rokuB	[324,250,135,131]	added
2025-10-02 10:05:01.411577	cam1	Bullsit	Gin 500ml	0.6852	1158	16bullsit_gS	[341,127,213,210]	added
2026-01-29 12:12:25.411577	cam1	Iceland	Lychee Martini 275ml	0.775	1159	03iceland_lmS	[270,303,159,50]	restock
2025-10-23 00:35:26.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.879	1160	01ot_atlasrpB	[44,96,245,169]	restock
2025-04-26 17:14:00.411577	cam1	Drum	Whisky Black 700ml	0.9017	1161	22drum_wbB	[161,341,107,98]	sold
2025-11-18 08:49:15.411577	cam1	Bintang	Radler 330ml	0.8406	1162	06bintang_radlerS	[297,223,246,77]	sold
2025-10-04 10:57:57.411577	cam1	Santai	Passionfruit & Guava 330ml	0.7704	1163	14santai_pgK	[220,332,216,47]	sold
2025-04-18 22:48:48.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.7948	1164	01ot_atlasrpB	[51,89,207,223]	added
2025-08-29 19:29:51.411577	cam1	Extra Joss	Ultimate 250ml	0.9058	1165	53extrajK	[234,38,243,85]	restock
2025-09-07 17:27:14.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.7695	1166	08baliwein_abjmB	[129,285,160,143]	sold
2025-04-08 09:22:46.411577	cam1	Smirnoff	Vodka 700ml	0.9585	1167	45smirnoffB	[321,341,174,128]	sold
2025-06-03 21:37:28.411577	cam1	Guiness	Foreign Extra Stout 620ml	0.8845	1168	34guiness_fesB	[14,395,65,136]	added
2025-05-09 23:54:37.411577	cam1	Kura Kura	Easy Ale 330ml	0.9109	1169	05kura_eaK	[146,120,213,47]	added
2025-06-07 09:05:10.411577	cam1	Gilbey's	Gin 350ml	0.6503	1170	37gilbeys_gS	[149,281,36,49]	added
2025-09-19 15:52:53.411577	cam1	Iceland	Lychee Martini 275ml	0.8777	1171	03iceland_lmS	[76,370,91,137]	sold
2025-04-15 16:48:21.411577	cam1	Heineken	330ml	0.9402	1172	46heinekenS	[274,161,133,193]	added
2025-04-04 01:44:51.411577	cam1	Orang Tua	Atlas Lychee 620ml	0.882	1173	01ot_atlaslB	[67,66,106,246]	sold
2025-06-22 17:01:09.411577	cam1	Wija	Blueberry 360ml	0.866	1174	15wija_bS	[11,188,81,39]	added
2026-02-28 08:43:54.411577	cam1	Baliwein	Anggur Salak 750ml	0.817	1175	08baliwein_absB	[295,239,224,238]	sold
2025-10-27 11:36:59.411577	cam1	Bacardi	Spiced Rum 750ml	0.8677	1176	36bacardi_srB	[113,184,98,60]	added
2026-02-09 23:23:25.411577	cam1	Jagermeister	700ml	0.8365	1177	42jagermeisterB	[183,78,146,136]	added
2025-04-26 04:38:45.411577	cam1	New City	1L	0.7812	1178	24newcityB	[304,212,76,34]	sold
2025-05-03 16:09:24.411577	cam1	Gordon's	PinkPremium 750ml	0.7217	1179	44gordon_ppB	[372,12,129,75]	restock
2025-03-12 20:06:15.411577	cam1	Captain Morgan	Silver Rum 750ml	0.785	1180	35cm_ssB	[215,143,213,82]	added
2025-05-16 21:44:22.411577	cam1	Jose Cuervo	750ml	0.7833	1181	50josecuervoB	[239,279,112,125]	added
2025-06-01 04:38:39.411577	cam1	Guiness	Foreign Extra Stout 620ml	0.9199	1182	34guiness_fesB	[155,75,238,186]	restock
2025-10-29 17:59:20.411577	cam1	Orang Tua	Anggur Merah 275ml	0.8904	1183	01ot_amerS	[27,392,90,208]	added
2025-05-11 17:35:35.411577	cam1	Rajawali	Prost 620ml	0.7771	1184	19rajawali_prostB	[57,152,224,199]	added
2026-03-02 03:23:32.411577	cam1	Orang Tua	Anggur Putih 620ml	0.673	1185	01ot_aputB	[366,376,169,76]	added
2025-04-22 09:29:10.411577	cam1	Iceland	Original 700ml	0.7208	1186	03icelandB	[53,49,124,136]	added
2025-03-29 22:44:24.411577	cam1	Three Peaks	Dry Gin 700ml	0.9352	1187	33threep_dgB	[389,395,32,193]	restock
2025-08-13 09:18:20.411577	cam1	Iceland	Lychee Martini 275ml	0.9801	1188	03iceland_lmS	[139,216,55,182]	sold
2025-06-22 00:20:13.411577	cam1	Iceland	Original 700ml	0.7084	1189	03icelandB	[46,340,114,182]	added
2025-08-02 06:37:45.411577	cam1	Baliwein	Anggur Salak 750ml	0.9581	1190	08baliwein_absB	[273,283,159,208]	added
2025-03-16 09:39:09.411577	cam1	Bintang	Pilsener 620ml	0.8762	1191	06bintangB	[93,307,42,33]	sold
2025-05-24 01:35:56.411577	cam1	Sababay	Pink Blossom 750ml	0.7213	1192	02sababay_pbB	[18,49,240,92]	restock
2025-12-16 19:09:20.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.9569	1193	10kawa_merahB	[380,335,245,152]	restock
2025-04-18 02:24:26.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.9141	1194	08baliwein_abjmB	[208,223,133,42]	added
2026-01-03 02:10:01.411577	cam1	Albens	Apple Lychee Cider 330ml	0.7801	1195	07albens_alcS	[262,292,119,199]	sold
2026-02-06 10:11:21.411577	cam1	Guiness	Draught Stout 500ml	0.876	1196	34guiness_dsBC	[48,372,43,250]	added
2025-05-23 06:45:07.411577	cam1	Suntory Roku	Gin 700ml	0.7263	1197	43rokuB	[192,317,147,233]	added
2025-05-13 03:39:34.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.7383	1198	10kawa_merahB	[229,199,38,189]	sold
2025-03-16 12:14:34.411577	cam1	Santai	Passionfruit & Guava 330ml	0.7192	1199	14santai_pgK	[182,148,191,244]	added
2025-04-10 01:09:27.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.9109	1200	01ot_amergoldB	[141,69,89,90]	added
2025-09-08 13:12:14.411577	cam1	Extra Joss	Ultimate 250ml	0.6783	1201	53extrajK	[227,124,133,31]	restock
2026-01-29 04:23:50.411577	cam1	Pokka	Green Tea 300ml	0.8876	1202	57pokkaK	[341,399,214,67]	added
2025-04-27 05:09:21.411577	cam1	Baliwein	Anggur Salak 750ml	0.7123	1203	08baliwein_absB	[62,374,96,100]	sold
2025-08-10 18:52:25.411577	cam1	Pokka	Green Tea 300ml	0.971	1204	57pokkaK	[273,265,117,227]	restock
2025-07-18 13:16:09.411577	cam1	Albens	Apple Cier 330ml	0.6516	1205	07albensS	[346,386,74,106]	sold
2025-06-19 12:14:15.411577	cam1	Bacardi	Carta Blanca 750ml	0.9819	1206	36bacardi_cbB	[22,172,65,123]	restock
2025-11-29 22:23:46.411577	cam1	Kulturale	L. L. Stout 330ml	0.7119	1207	09kulturale_llsK	[192,218,213,217]	sold
2025-04-21 16:46:37.411577	cam1	Albens	Apple Mango Cider 330ml	0.812	1208	07albens_amcS	[191,394,212,230]	restock
2025-05-02 11:13:17.411577	cam1	Sapporo	330ml	0.8995	1209	49sapporoK	[102,207,78,202]	restock
2025-03-27 13:15:08.411577	cam1	Orang Tua	Singaraja 620ml	0.7005	1210	01ot_singarajaB	[314,350,113,72]	added
2025-08-20 16:21:25.411577	cam1	Sababay	Ludisia 750ml	0.7065	1211	02sababay_lB	[279,339,148,66]	added
2025-08-06 14:06:49.411577	cam1	Bullsit	Vodka 500ml	0.8777	1212	16bullsit_vS	[138,175,67,124]	added
2025-09-11 21:16:35.411577	cam1	Sapporo	330ml	0.9805	1213	49sapporoK	[353,197,63,61]	restock
2025-07-17 15:50:39.411577	cam1	Kulturale	L. L. Stout 330ml	0.9245	1214	09kulturale_llsK	[149,237,250,33]	added
2025-09-08 10:42:41.411577	cam1	Santai	Passionfruit & Guava 330ml	0.7555	1215	14santai_pgK	[372,252,70,145]	restock
2026-02-11 11:54:34.411577	cam1	Yakult	1 pack 325ml	0.8432	1216	60yakultK	[274,102,144,157]	restock
2025-06-11 19:56:54.411577	cam1	Guiness	Foreign Extra Stout 320ml	0.8929	1217	34guinessK_fesKC	[273,298,242,78]	added
2025-05-08 11:48:45.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.822	1218	14santai_agaK	[397,33,249,44]	restock
2026-02-13 00:07:07.411577	cam1	Chum Churum	Soju 360ml	0.9574	1219	12chumS	[321,247,104,113]	added
2025-09-16 01:42:30.411577	cam1	Polaris	Soda Water 330ml	0.7172	1220	54polarisK	[168,70,56,109]	sold
2025-06-29 23:12:48.411577	cam1	Jameson	Irish Whiskey 700ml	0.7637	1221	41jamesonB	[245,89,71,136]	sold
2025-12-06 16:01:30.411577	cam1	Pokka	Green Tea 300ml	0.8514	1222	57pokkaK	[208,139,216,31]	sold
2025-05-10 20:41:17.411577	cam1	Canard	Session IPA 330ml	0.8331	1223	04canard_siK	[291,321,226,230]	sold
2025-10-17 12:10:14.411577	cam1	Kura Kura	Easy Ale 330ml	0.889	1224	05kura_eaK	[162,259,74,89]	restock
2025-12-24 21:50:13.411577	cam1	Cham Joeun	Lychee 360ml	0.735	1225	40chamj_lS	[270,77,188,137]	sold
2025-11-04 03:06:38.411577	cam1	Sababay	Pink Blossom 750ml	0.9839	1226	02sababay_pbB	[314,364,143,153]	added
2026-02-09 03:04:18.411577	cam1	Orang Tua	Atlas Lychee 620ml	0.8872	1227	01ot_atlaslB	[158,99,162,190]	added
2025-07-09 01:05:58.411577	cam1	Beaches	Cerveza 330ml	0.7605	1228	32beachescK	[66,154,32,40]	added
2026-01-11 12:54:32.411577	cam1	Drum	Whisky Black 700ml	0.8403	1229	22drum_wbB	[21,82,163,231]	added
2025-10-26 11:41:08.411577	cam1	Canard	Weizenbock 330ml	0.774	1230	04canard_weK	[297,215,170,146]	added
2025-04-14 08:14:26.411577	cam1	Baliwein	Anggur Salak 750ml	0.7	1231	08baliwein_absB	[248,156,218,83]	restock
2025-08-20 19:06:28.411577	cam1	Pu Tao Chee Chiew	330ml	0.8975	1232	31putaoccS	[387,263,211,124]	added
2025-07-08 16:28:38.411577	cam1	Iceland	Blue Lagoon 275ml	0.6839	1233	03iceland_blS	[328,263,248,48]	restock
2025-10-15 15:09:09.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.6792	1234	19rajawali_prostalK	[301,196,231,211]	added
2026-02-16 15:42:44.411577	cam1	Iceland	Blue Lagoon 275ml	0.7012	1235	03iceland_blS	[21,352,162,75]	sold
2025-12-17 03:16:05.411577	cam1	Cham Joeun	Soju 360ml	0.8321	1236	40chamjS	[75,73,206,246]	added
2025-05-01 10:07:55.411577	cam1	Bacardi	Spiced Rum 750ml	0.8457	1237	36bacardi_srB	[150,355,249,133]	sold
2025-12-28 13:05:58.411577	cam1	Santai	Lemon & Lime 330ml	0.6707	1238	14santai_llK	[74,334,117,229]	sold
2025-08-10 23:47:32.411577	cam1	Heineken	330ml	0.8109	1239	46heinekenS	[400,15,117,242]	added
2025-12-06 14:42:58.411577	cam1	Gordon's	PinkPremium 750ml	0.8079	1240	44gordon_ppB	[301,220,43,82]	restock
2025-09-12 22:37:30.411577	cam1	Baliwein	Semara 750ml	0.7391	1241	08baliwein_semB	[256,284,67,147]	sold
2025-06-29 16:39:27.411577	cam1	Batavia	Whisky 700ml	0.7248	1242	21bataviaB	[142,393,173,42]	added
2025-04-06 05:55:32.411577	cam1	Chum Churum	Peach 360ml	0.7567	1243	12chum_pS	[293,258,129,168]	restock
2025-06-22 10:00:19.411577	cam1	Canard	Weizenbock 330ml	0.7608	1244	04canard_weK	[198,11,184,41]	added
2025-06-23 10:50:35.411577	cam1	Jose Cuervo	750ml	0.9036	1245	50josecuervoB	[157,397,162,83]	sold
2025-08-08 13:42:27.411577	cam1	Iceland	Orange 700ml	0.9846	1246	03iceland_oB	[322,292,102,57]	sold
2025-06-08 03:57:09.411577	cam1	Bullsit	Vodka 500ml	0.9149	1247	16bullsit_vS	[80,149,205,191]	sold
2025-04-26 21:03:20.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.976	1248	01ot_apiptB	[249,282,178,165]	sold
2025-12-20 19:20:36.411577	cam1	Orang Tua	Atlas Lychee 620ml	0.7687	1249	01ot_atlaslB	[115,301,211,137]	restock
2025-10-29 10:31:03.411577	cam1	Kura Kura	IPA 330ml	0.7497	1250	05kura_ipaK	[397,325,109,142]	sold
2025-07-01 02:21:46.411577	cam1	Sababay	Black Velvet 750ml	0.8622	1251	02sababay_bvB	[213,374,169,87]	added
2025-08-03 10:26:50.411577	cam1	Guiness	Draught Stout 500ml	0.6942	1252	34guiness_dsBC	[201,20,36,140]	restock
2025-05-26 13:46:49.411577	cam1	Albens	Apple Mango Cider 330ml	0.9692	1253	07albens_amcS	[69,318,163,139]	added
2026-02-07 04:47:55.411577	cam1	Sprite	390ml	0.6531	1254	59spriteK	[112,311,54,41]	added
2025-12-08 00:59:05.411577	cam1	Bintang	Radler 330ml	0.8812	1255	06bintang_radlerS	[247,136,211,221]	restock
2025-12-08 23:32:30.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.744	1256	01ot_amergoldB	[324,52,246,144]	restock
2025-07-06 15:55:12.411577	cam1	Vibe	Exotic Lychee 700ml	0.8577	1257	11vibe_elB	[83,107,60,109]	sold
2025-11-07 08:32:30.411577	cam1	Albens	Apple Lychee Cider 330ml	0.9658	1258	07albens_alcS	[351,307,97,249]	sold
2025-05-11 16:43:27.411577	cam1	Chum Churum	Peach 360ml	0.9023	1259	12chum_pS	[116,263,229,194]	sold
2026-02-17 20:30:34.411577	cam1	Jameson	Irish Whiskey 700ml	0.9187	1260	41jamesonB	[99,276,131,206]	added
2025-04-18 13:52:01.411577	cam1	Jagermeister	700ml	0.9672	1261	42jagermeisterB	[30,339,202,159]	added
2025-10-18 20:30:49.411577	cam1	Asahi	Super Dry 334ml	0.7705	1262	48asahiK	[82,112,122,159]	sold
2025-03-16 10:49:25.411577	cam1	Bullsit	Vodka 500ml	0.8453	1263	16bullsit_vS	[173,260,189,72]	sold
2026-03-06 21:43:46.411577	cam1	Jameson	Irish Whiskey 700ml	0.6773	1264	41jamesonB	[94,323,204,243]	added
2025-06-01 10:11:31.411577	cam1	Asahi	Super Dry 334ml	0.9393	1265	48asahiK	[52,274,174,81]	sold
2025-06-19 20:20:43.411577	cam1	Kura Kura	Lager 330ml	0.8461	1266	05kura_lK	[197,358,148,136]	restock
2025-10-05 21:21:44.411577	cam1	Rajawali	Prost 620ml	0.8974	1267	19rajawali_prostB	[281,378,175,189]	added
2025-11-23 06:12:07.411577	cam1	New City	1L	0.7171	1268	24newcityB	[205,76,185,160]	added
2025-07-30 07:23:27.411577	cam1	Kura Kura	Session Hazy 330ml	0.851	1269	05kura_shK	[30,215,196,64]	added
2025-06-23 06:40:34.411577	cam1	Wija	Soju 360ml	0.6866	1270	15wijaS	[372,237,205,78]	sold
2025-10-27 00:38:20.411577	cam1	Bintang	Pilsener 330ml	0.9897	1271	06bintangK	[78,139,137,82]	sold
2025-10-11 02:11:26.411577	cam1	Smirnoff	Vodka 700ml	0.9345	1272	45smirnoffB	[144,52,121,189]	sold
2025-07-25 23:50:56.411577	cam1	Iceland	Lychee Martini 275ml	0.893	1273	03iceland_lmS	[210,305,31,120]	sold
2025-08-12 16:55:46.411577	cam1	Kulturale	N. R. K. DIPA 330ml	0.9757	1274	09kulturale_nrkK	[172,19,81,132]	added
2025-08-21 18:35:42.411577	cam1	Iceland	Blue Lagoon 275ml	0.9031	1275	03iceland_blS	[25,323,92,152]	restock
2025-08-26 22:05:51.411577	cam1	Bintang	Pilsener 500ml	0.7528	1276	06bintangBC	[128,186,99,167]	restock
2025-08-10 20:00:25.411577	cam1	Kura Kura	Session Hazy 330ml	0.8368	1277	05kura_shK	[382,139,221,138]	added
2026-03-07 01:58:04.411577	cam1	Iceland	Original 250ml	0.9713	1278	03icelandK	[26,181,238,68]	added
2025-11-11 07:52:46.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.9247	1279	10kawa_bcB	[39,140,71,88]	restock
2025-09-23 07:58:22.411577	cam1	Kura Kura	IPA 330ml	0.9388	1280	05kura_ipaK	[190,111,158,178]	restock
2025-09-03 09:40:14.411577	cam1	Bullsit	Gin 500ml	0.8192	1281	16bullsit_gS	[106,25,211,240]	sold
2025-03-14 10:55:39.411577	cam1	Pokka	Green Tea 300ml	0.8385	1282	57pokkaK	[353,130,38,52]	sold
2025-11-24 05:30:56.411577	cam1	Kulturale	Amarillo 330ml	0.6792	1283	09kulturale_aK	[34,359,33,55]	added
2025-07-04 11:15:06.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.8982	1284	23palapaB	[316,161,138,86]	added
2025-04-20 03:36:17.411577	cam1	Iceland	Berry Lemonade 275ml	0.8578	1285	03iceland_beleS	[63,317,138,50]	sold
2026-02-05 21:07:36.411577	cam1	Bintang	Pilsener 500ml	0.9837	1286	06bintangBC	[216,342,166,246]	added
2025-03-23 16:52:21.411577	cam1	Kura Kura	Easy Ale 330ml	0.8548	1287	05kura_eaK	[77,325,202,120]	sold
2025-03-23 08:03:15.411577	cam1	Kulturale	Amarillo 330ml	0.6892	1288	09kulturale_aK	[29,44,78,68]	restock
2025-06-17 09:16:01.411577	cam1	Santai	Passionfruit & Guava 330ml	0.8193	1289	14santai_pgK	[197,102,204,110]	sold
2025-04-20 11:12:40.411577	cam1	Orang Tua	Anggur Putih 620ml	0.8655	1290	01ot_aputB	[76,370,40,158]	sold
2025-12-21 19:00:56.411577	cam1	Wija	Blueberry 360ml	0.7921	1291	15wija_bS	[125,375,154,128]	sold
2025-08-15 23:37:19.411577	cam1	Orang Tua	Singaraja 620ml	0.8941	1292	01ot_singarajaB	[131,305,104,98]	added
2026-02-15 16:44:37.411577	cam1	Albens	Apple Lychee Cider 330ml	0.856	1293	07albens_alcS	[343,25,235,193]	added
2025-12-29 18:39:27.411577	cam1	Beaches	Cerveza 330ml	0.9195	1294	32beachescK	[88,215,86,146]	added
2025-09-19 22:49:43.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.6677	1295	08baliwein_abjmB	[308,55,95,244]	added
2025-12-31 04:57:20.411577	cam1	Orang Tua	Anggur Putih 620ml	0.7988	1296	01ot_aputB	[319,372,97,210]	added
2025-05-11 04:13:39.411577	cam1	Three Peaks	Dry Gin 700ml	0.8138	1297	33threep_dgB	[266,114,52,228]	added
2025-12-05 23:04:19.411577	cam1	Canard	Strawberry Gose 330ml	0.6877	1298	04canard_sgK	[144,87,76,123]	sold
2025-12-18 02:20:26.411577	cam1	Beaches	Cerveza 330ml	0.8047	1299	32beachescK	[106,56,210,175]	restock
2025-10-02 01:24:08.411577	cam1	Bullsit	Gin 500ml	0.7156	1300	16bullsit_gS	[85,180,146,136]	added
2026-01-24 11:34:28.411577	cam1	Suntory Roku	Gin 700ml	0.9202	1301	43rokuB	[157,119,185,137]	restock
2025-08-04 11:34:15.411577	cam1	Bintang	Pilsener 330ml	0.6638	1302	06bintangK	[131,54,45,158]	restock
2025-09-11 11:16:36.411577	cam1	Three Peaks	Dry Gin 700ml	0.8723	1303	33threep_dgB	[56,168,150,126]	restock
2025-12-12 10:15:49.411577	cam1	Extra Joss	Ultimate 250ml	0.8052	1304	53extrajK	[136,235,199,32]	sold
2025-03-30 17:19:40.411577	cam1	Smirnoff	Vodka 700ml	0.7035	1305	45smirnoffB	[308,247,59,149]	sold
2025-09-20 15:15:12.411577	cam1	Santai	Lemon & Lime 330ml	0.9654	1306	14santai_llK	[352,398,133,167]	added
2025-08-23 19:07:50.411577	cam1	Kulturale	Bravo 330ml	0.9592	1307	09kulturale_bK	[265,372,58,169]	sold
2025-08-03 14:19:59.411577	cam1	Kura Kura	Lager 330ml	0.6627	1308	05kura_lK	[83,218,176,101]	added
2025-12-24 09:15:53.411577	cam1	Wija	Lychee 360ml	0.667	1309	15wija_lS	[145,122,101,147]	sold
2025-04-05 18:17:07.411577	cam1	Orang Tua	Anggur Putih 620ml	0.8426	1310	01ot_aputB	[360,343,45,67]	restock
2025-12-12 08:49:40.411577	cam1	Sapporo	330ml	0.6826	1311	49sapporoK	[350,108,199,245]	sold
2025-11-20 00:13:51.411577	cam1	Cham Joeun	Soju 360ml	0.9496	1312	40chamjS	[52,124,228,234]	sold
2025-03-11 07:34:21.411577	cam1	Bullsit	Whisky 500ml	0.8686	1313	16bullsit_wS	[47,146,32,229]	sold
2025-10-02 08:05:28.411577	cam1	Albens	Apple Lychee Cider 330ml	0.8052	1314	07albens_alcS	[344,230,190,106]	added
2025-11-09 17:58:20.411577	cam1	Albens	Apple Cier 330ml	0.8509	1315	07albensS	[139,203,125,87]	added
2026-02-27 02:31:46.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.8763	1316	19rajawali_prostalK	[58,391,47,218]	sold
2025-07-04 18:05:41.411577	cam1	Sapporo	330ml	0.6702	1317	49sapporoK	[293,280,184,180]	sold
2025-09-15 12:17:16.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.6785	1318	01ot_amergoldB	[169,285,225,73]	sold
2026-02-27 08:05:35.411577	cam1	Beaches	Cerveza 330ml	0.7143	1319	32beachescK	[308,129,63,120]	restock
2025-09-01 12:08:05.411577	cam1	Chum Churum	Soju 360ml	0.6802	1320	12chumS	[269,185,145,234]	restock
2025-10-04 12:46:40.411577	cam1	Bacardi	Spiced Rum 750ml	0.9335	1321	36bacardi_srB	[378,221,179,104]	added
2025-08-01 03:01:53.411577	cam1	Baliwein	Anggur Salak 750ml	0.9244	1322	08baliwein_absB	[215,66,247,223]	sold
2025-08-18 03:56:40.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.6783	1323	19rajawali_prostalK	[230,100,112,197]	sold
2025-07-16 20:48:20.411577	cam1	Wija	Soju 360ml	0.9459	1324	15wijaS	[358,37,187,182]	added
2025-03-21 20:30:39.411577	cam1	Iceland	Lychee Martini 275ml	0.8383	1325	03iceland_lmS	[203,44,65,166]	sold
2025-12-05 17:32:08.411577	cam1	Bacardi	Carta Blanca 750ml	0.7297	1326	36bacardi_cbB	[357,292,150,240]	sold
2025-09-06 02:55:02.411577	cam1	Orang Tua	Anggur Merah 620ml	0.7004	1327	01ot_amerB	[193,369,217,224]	sold
2025-12-29 02:25:13.411577	cam1	Iceland	Original 700ml	0.6715	1328	03icelandB	[378,253,108,147]	sold
2025-08-24 17:23:18.411577	cam1	Royal Brewhouse	Gold Royale 350ml	0.6946	1329	18rb_grS	[158,371,152,228]	sold
2026-01-09 01:26:16.411577	cam1	Iceland	Lychee Martini 275ml	0.6616	1330	03iceland_lmS	[153,351,137,164]	added
2026-02-22 14:34:38.411577	cam1	Cham Joeun	Soju 360ml	0.717	1331	40chamjS	[308,233,45,206]	sold
2025-11-21 00:14:03.411577	cam1	Kura Kura	IPA 330ml	0.9157	1332	05kura_ipaK	[194,82,208,103]	added
2026-01-23 13:59:13.411577	cam1	Canard	Strawberry Gose 330ml	0.8121	1333	04canard_sgK	[236,398,38,116]	added
2025-04-20 01:56:03.411577	cam1	Gordon's	PinkPremium 750ml	0.8599	1334	44gordon_ppB	[358,92,103,210]	added
2026-02-05 12:28:16.411577	cam1	Jagermeister	700ml	0.808	1335	42jagermeisterB	[156,83,164,108]	sold
2025-12-21 00:04:46.411577	cam1	Kulturale	N. R. K. DIPA 330ml	0.955	1336	09kulturale_nrkK	[13,18,184,179]	sold
2025-12-17 19:37:17.411577	cam1	Orang Tua	Arak Obat 620ml	0.8802	1337	01ot_aoB	[113,16,65,166]	sold
2026-02-17 20:34:57.411577	cam1	Kura Kura	Lager 330ml	0.8367	1338	05kura_lK	[40,355,44,113]	sold
2025-11-14 13:31:53.411577	cam1	Guiness	Foreign Extra Stout 620ml	0.7956	1339	34guiness_fesB	[38,368,207,65]	restock
2025-07-12 11:23:22.411577	cam1	Guiness	Foreign Extra Stout 620ml	0.9191	1340	34guiness_fesB	[275,377,207,120]	added
2025-08-19 11:30:00.411577	cam1	Kulturale	Amarillo 330ml	0.7227	1341	09kulturale_aK	[234,72,226,152]	added
2025-08-19 18:10:41.411577	cam1	Sprite	390ml	0.6874	1342	59spriteK	[41,52,222,173]	sold
2026-01-29 17:47:29.411577	cam1	Kura Kura	Session Hazy 330ml	0.7713	1343	05kura_shK	[54,144,65,40]	added
2025-05-12 04:44:19.411577	cam1	Kulturale	N. R. K. DIPA 330ml	0.7045	1344	09kulturale_nrkK	[81,157,67,54]	sold
2025-09-02 07:35:43.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.855	1345	08baliwein_abjmB	[349,318,76,77]	restock
2026-02-18 04:06:01.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.963	1346	01ot_atlasrpB	[49,114,210,86]	sold
2025-04-24 01:11:49.411577	cam1	Pu Tao Chee Chiew	330ml	0.8965	1347	31putaoccS	[34,57,90,46]	sold
2026-01-11 00:17:21.411577	cam1	Baileys	Irish Cream 750ml	0.7639	1348	51baileys_icB	[27,177,115,220]	sold
2025-12-22 15:06:45.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.8173	1349	23palapaB	[164,39,211,240]	sold
2026-02-18 14:40:21.411577	cam1	Heineken	330ml	0.9538	1350	46heinekenS	[374,342,115,87]	added
2025-11-23 07:05:57.411577	cam1	Pokka	Green Tea 300ml	0.9596	1351	57pokkaK	[349,85,72,250]	added
2025-07-09 14:34:47.411577	cam1	Orang Tua	Intisari Blackcurrant 620ml	0.9169	1352	01ot_bcintB	[296,352,33,122]	sold
2025-12-18 04:28:10.411577	cam1	Wija	Soju 360ml	0.9359	1353	15wijaS	[385,43,233,219]	added
2026-01-07 15:11:00.411577	cam1	New City	1L	0.952	1354	24newcityB	[144,293,237,163]	added
2025-08-28 09:12:08.411577	cam1	Gilbey's	Gin 350ml	0.8534	1355	37gilbeys_gS	[246,273,97,39]	sold
2025-07-31 03:42:15.411577	cam1	Wija	Soju 360ml	0.8602	1356	15wijaS	[390,37,153,82]	sold
2025-07-24 18:35:53.411577	cam1	Jose Cuervo	750ml	0.9388	1357	50josecuervoB	[144,277,52,227]	sold
2025-05-22 12:21:38.411577	cam1	Baliwein	Semara 750ml	0.9702	1358	08baliwein_semB	[165,377,178,229]	sold
2026-03-10 11:32:46.411577	cam1	Asahi	Super Dry 334ml	0.7697	1359	48asahiK	[215,193,111,120]	sold
2025-10-24 23:50:59.411577	cam1	Captain Morgan	Spice Gold 750ml	0.8895	1360	35cm_sgB	[59,351,193,72]	sold
2025-10-24 08:02:34.411577	cam1	Captain Morgan	Spice Gold 750ml	0.6991	1361	35cm_sgB	[280,141,214,74]	sold
2026-03-08 21:21:21.411577	cam1	Jose Cuervo	750ml	0.858	1362	50josecuervoB	[253,123,127,108]	restock
2025-11-12 11:08:10.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.8087	1363	10kawa_hijauB	[335,107,156,239]	sold
2025-07-19 04:02:00.411577	cam1	Cham Joeun	Soju 360ml	0.9188	1364	40chamjS	[364,112,58,70]	added
2025-12-12 00:44:34.411577	cam1	Bacardi	Spiced Rum 750ml	0.7076	1365	36bacardi_srB	[111,328,146,142]	restock
2025-06-05 12:20:09.411577	cam1	Rajawali	Prost 620ml	0.9023	1366	19rajawali_prostB	[109,133,163,135]	added
2025-04-02 16:14:40.411577	cam1	Bintang	Pilsener 500ml	0.6575	1367	06bintangBC	[164,244,77,53]	added
2025-08-12 04:36:33.411577	cam1	Baliwein	Sekala 750ml	0.9818	1368	08baliwein_sekB	[67,201,231,145]	restock
2025-05-30 03:33:36.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.921	1369	01ot_atlasrpB	[48,144,240,44]	sold
2025-09-01 17:13:26.411577	cam1	Kulturale	N. R. K. DIPA 330ml	0.7612	1370	09kulturale_nrkK	[314,38,107,134]	sold
2026-03-08 07:26:53.411577	cam1	Bullsit	Gin 500ml	0.9737	1371	16bullsit_gS	[336,239,232,96]	sold
2025-12-09 19:58:30.411577	cam1	Batavia	Whisky 700ml	0.869	1372	21bataviaB	[244,36,127,122]	added
2025-05-29 13:08:35.411577	cam1	New City	1L	0.7135	1373	24newcityB	[258,217,50,51]	added
2025-06-19 04:17:32.411577	cam1	Orang Tua	Anggur Merah 620ml	0.9282	1374	01ot_amerB	[128,149,68,197]	added
2025-08-22 20:30:34.411577	cam1	Chum Churum	Yogurt 360ml	0.8216	1375	12chum_yS	[22,35,149,198]	added
2025-08-06 15:17:40.411577	cam1	Orang Tua	Arak Obat 620ml	0.9492	1376	01ot_aoB	[159,288,32,104]	sold
2025-07-21 21:56:36.411577	cam1	New City	1L	0.7591	1377	24newcityB	[86,222,240,46]	added
2026-01-02 05:12:44.411577	cam1	Orang Tua	Anggur Merah 275ml	0.7878	1378	01ot_amerS	[207,397,161,134]	added
2025-05-12 14:06:02.411577	cam1	Albens	Apple Mango Cider 330ml	0.9799	1379	07albens_amcS	[186,295,233,157]	sold
2025-09-04 12:46:34.411577	cam1	Bullsit	Vodka 500ml	0.7089	1380	16bullsit_vS	[347,26,89,145]	added
2025-07-26 14:24:50.411577	cam1	Albens	Apple Mango Cider 330ml	0.9682	1381	07albens_amcS	[104,138,137,155]	sold
2025-07-02 06:32:24.411577	cam1	Beaches	Cerveza 330ml	0.8774	1382	32beachescK	[322,349,228,163]	added
2025-08-15 20:49:57.411577	cam1	Baileys	Irish Cream 750ml	0.6794	1383	51baileys_icB	[32,378,243,112]	sold
2025-08-15 04:05:51.411577	cam1	Baileys	Irish Cream 750ml	0.7033	1384	51baileys_icB	[171,376,187,160]	sold
2025-06-22 11:38:51.411577	cam1	Chum Churum	Peach 360ml	0.6825	1385	12chum_pS	[75,46,118,236]	restock
2026-02-22 23:51:54.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.833	1386	19rajawali_prostalK	[14,219,85,79]	sold
2025-11-06 03:01:48.411577	cam1	Drum	Whisky Black 700ml	0.8091	1387	22drum_wbB	[78,201,216,104]	sold
2025-09-10 03:38:43.411577	cam1	Bacardi	Spiced Rum 750ml	0.8347	1388	36bacardi_srB	[85,237,93,147]	restock
2025-03-23 08:04:24.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.7764	1389	19rajawali_prostalK	[270,67,182,35]	sold
2025-12-14 12:00:30.411577	cam1	Asahi	Super Dry 334ml	0.8615	1390	48asahiK	[151,15,53,210]	sold
2025-09-13 09:26:19.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.8169	1391	19rajawali_prostalK	[271,66,183,166]	restock
2026-02-27 21:50:21.411577	cam1	Kura Kura	Lager 330ml	0.8158	1392	05kura_lK	[367,111,107,217]	added
2025-06-27 09:33:35.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.7726	1393	19rajawali_prostalK	[303,380,141,102]	added
2025-07-28 05:23:53.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.7142	1394	01ot_apiptB	[287,279,50,210]	sold
2025-06-26 16:11:17.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.9558	1395	01ot_apihjB	[289,397,112,66]	sold
2025-05-12 10:28:22.411577	cam1	Heineken	330ml	0.9473	1396	46heinekenS	[116,329,58,219]	added
2025-06-18 10:42:11.411577	cam1	Kura Kura	Session Hazy 330ml	0.8508	1397	05kura_shK	[50,130,169,234]	sold
2025-08-15 13:42:14.411577	cam1	Three Peaks	Dry Gin 700ml	0.7465	1398	33threep_dgB	[173,51,153,44]	added
2025-03-21 08:54:44.411577	cam1	Kulturale	L. L. Stout 330ml	0.9436	1399	09kulturale_llsK	[79,27,54,250]	sold
2025-07-28 15:31:52.411577	cam1	Gilbey's	Gin 350ml	0.9358	1400	37gilbeys_gS	[194,395,176,235]	restock
2025-08-18 11:31:27.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.9878	1401	14santai_agaK	[343,208,168,153]	added
2025-10-06 13:40:09.411577	cam1	Bullsit	Whisky 500ml	0.875	1402	16bullsit_wS	[338,45,197,146]	restock
2026-02-21 12:00:14.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.8952	1403	10kawa_hijauB	[64,258,122,176]	restock
2026-02-28 16:03:53.411577	cam1	Kulturale	L. L. Stout 330ml	0.7539	1404	09kulturale_llsK	[359,318,117,226]	sold
2026-02-17 02:52:10.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.8681	1405	14santai_agaK	[75,66,39,95]	added
2025-03-18 13:22:43.411577	cam1	Bintang	Pilsener 620ml	0.8838	1406	06bintangB	[287,121,150,56]	sold
2025-04-30 04:57:30.411577	cam1	Bullsit	Whisky 500ml	0.661	1407	16bullsit_wS	[68,247,31,94]	sold
2025-05-29 11:25:54.411577	cam1	Crystalline	330ml	0.7699	1408	55crystalinK	[28,323,113,85]	added
2025-12-19 19:14:32.411577	cam1	Cham Joeun	Lychee 360ml	0.825	1409	40chamj_lS	[231,86,242,111]	added
2025-10-26 02:54:36.411577	cam1	Baliwein	Anggur Salak 750ml	0.7611	1410	08baliwein_absB	[34,306,147,151]	restock
2025-04-28 11:32:01.411577	cam1	Chum Churum	Soju 360ml	0.7754	1411	12chumS	[118,381,203,183]	added
2025-04-08 17:34:56.411577	cam1	Three Peaks	Dry Gin 700ml	0.6554	1412	33threep_dgB	[173,52,119,165]	sold
2025-09-21 05:36:30.411577	cam1	Rajawali	Prost 620ml	0.6794	1413	19rajawali_prostB	[106,79,130,117]	restock
2025-04-21 02:11:10.411577	cam1	Sababay	Mascetti 750ml	0.8259	1414	02sababay_masB	[241,342,73,99]	added
2025-05-31 23:14:39.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.8224	1415	19rajawali_prostalK	[47,197,128,193]	restock
2026-02-23 23:48:02.411577	cam1	Extra Joss	Ultimate 250ml	0.718	1416	53extrajK	[347,113,228,169]	sold
2025-12-12 16:51:45.411577	cam1	Cham Joeun	Soju 360ml	0.726	1417	40chamjS	[52,256,132,148]	sold
2025-04-22 20:58:02.411577	cam1	Crystalline	330ml	0.8149	1418	55crystalinK	[292,195,146,62]	sold
2025-07-30 17:32:46.411577	cam1	Albens	Apple Cier 330ml	0.6697	1419	07albensS	[358,345,131,108]	added
2025-08-04 10:40:02.411577	cam1	Royal Brewhouse	Gold Royale 350ml	0.9759	1420	18rb_grS	[118,243,134,59]	added
2025-12-30 03:04:51.411577	cam1	Canard	Weizenbock 330ml	0.8112	1421	04canard_weK	[201,134,161,106]	added
2025-05-05 22:56:17.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.9504	1422	01ot_amergoldB	[229,338,213,66]	sold
2025-12-05 22:38:42.411577	cam1	Corona	Extra 355ml	0.6844	1423	47corona_eS	[357,247,218,160]	added
2025-08-07 23:15:39.411577	cam1	Sababay	Pink Blossom 750ml	0.8499	1424	02sababay_pbB	[43,136,84,104]	sold
2025-10-23 22:19:26.411577	cam1	Jagermeister	700ml	0.8845	1425	42jagermeisterB	[316,235,215,68]	sold
2025-04-04 05:50:43.411577	cam1	Bullsit	Vodka 500ml	0.7276	1426	16bullsit_vS	[122,301,115,171]	added
2026-01-28 10:18:48.411577	cam1	Crystalline	330ml	0.9677	1427	55crystalinK	[67,367,78,119]	sold
2025-09-05 14:53:08.411577	cam1	New City	1L	0.8269	1428	24newcityB	[21,142,214,212]	sold
2025-05-21 20:42:04.411577	cam1	Canard	Kolsch 330ml	0.9148	1429	04canard_kK	[105,92,139,139]	sold
2026-01-01 01:59:56.411577	cam1	Kura Kura	Island Ale 330ml	0.8435	1430	05kura_iaK	[57,370,158,89]	sold
2025-09-15 16:18:10.411577	cam1	Orang Tua	Anggur Merah 275ml	0.9554	1431	01ot_amerS	[287,374,199,31]	sold
2025-06-13 22:13:24.411577	cam1	Canard	Kolsch 330ml	0.9689	1432	04canard_kK	[259,304,74,204]	added
2025-10-11 15:58:41.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.9355	1433	01ot_atlasrpB	[209,150,59,164]	restock
2025-12-19 14:53:22.411577	cam1	Iceland	Lychee Martini 275ml	0.761	1434	03iceland_lmS	[144,246,205,199]	sold
2025-09-22 05:45:21.411577	cam1	Orang Tua	Intisari Blackcurrant 620ml	0.8917	1435	01ot_bcintB	[57,38,50,161]	sold
2026-01-28 16:36:35.411577	cam1	Guiness	Draught Stout 500ml	0.7704	1436	34guiness_dsBC	[319,179,185,237]	sold
2025-04-30 17:06:12.411577	cam1	Kura Kura	Island Ale 330ml	0.9813	1437	05kura_iaK	[395,124,188,57]	restock
2025-05-30 10:21:33.411577	cam1	Bullsit	Vodka 500ml	0.7922	1438	16bullsit_vS	[30,172,208,74]	sold
2025-12-23 09:23:18.411577	cam1	Iceland	Lychee Martini 275ml	0.7611	1439	03iceland_lmS	[292,280,227,139]	restock
2026-02-02 15:22:27.411577	cam1	Iceland	Lychee Martini 275ml	0.9697	1440	03iceland_lmS	[349,46,86,88]	sold
2025-07-18 05:19:47.411577	cam1	Guiness	Foreign Extra Stout 320ml	0.6559	1441	34guinessK_fesKC	[245,334,242,143]	added
2025-12-08 01:11:04.411577	cam1	Orang Tua	Singaraja 620ml	0.7464	1442	01ot_singarajaB	[320,55,163,119]	added
2025-09-06 21:04:27.411577	cam1	Kulturale	L. L. Stout 330ml	0.9015	1443	09kulturale_llsK	[386,343,172,222]	added
2026-03-08 17:24:56.411577	cam1	Three Peaks	Dry Gin 700ml	0.9401	1444	33threep_dgB	[154,398,49,202]	added
2026-02-08 08:24:42.411577	cam1	Iceland	Orange 700ml	0.6987	1445	03iceland_oB	[188,305,229,188]	sold
2025-11-24 02:21:43.411577	cam1	Captain Morgan	Spice Gold 750ml	0.6905	1446	35cm_sgB	[40,57,192,235]	sold
2025-06-05 14:49:37.411577	cam1	Wija	Soju 360ml	0.9042	1447	15wijaS	[68,44,48,248]	restock
2025-06-20 19:35:14.411577	cam1	Sapporo	330ml	0.874	1448	49sapporoK	[398,398,224,30]	added
2025-07-04 19:24:04.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.8141	1449	10kawa_hijauB	[353,374,155,250]	restock
2025-09-12 07:32:07.411577	cam1	Kura Kura	Island Ale 330ml	0.7721	1450	05kura_iaK	[396,292,185,238]	sold
2025-05-22 01:19:35.411577	cam1	Sababay	Pink Blossom 750ml	0.9774	1451	02sababay_pbB	[321,352,134,208]	sold
2025-07-15 04:44:39.411577	cam1	Three Peaks	Dry Gin 700ml	0.957	1452	33threep_dgB	[342,318,230,152]	added
2025-06-18 13:26:20.411577	cam1	Iceland	Original 700ml	0.8075	1453	03icelandB	[94,87,205,205]	sold
2025-04-13 20:11:32.411577	cam1	Iceland	Original 250ml	0.6691	1454	03icelandK	[203,224,233,134]	added
2025-10-29 14:58:55.411577	cam1	Canard	Session IPA 330ml	0.9117	1455	04canard_siK	[191,38,215,159]	restock
2026-01-14 22:38:46.411577	cam1	Sababay	Ludisia 750ml	0.8778	1456	02sababay_lB	[253,255,181,87]	sold
2025-08-08 08:49:51.411577	cam1	New City	1L	0.7483	1457	24newcityB	[218,237,154,44]	sold
2025-07-30 02:47:17.411577	cam1	Canard	Porter 330ml	0.9249	1458	04canard_pK	[315,347,102,168]	added
2025-10-26 17:38:35.411577	cam1	Canard	Witbier 330ml	0.8668	1459	04canard_wK	[72,14,136,159]	added
2025-08-18 09:27:56.411577	cam1	Gilbey's	Whisky 350ml	0.8064	1460	37gilbeys_wS	[317,48,65,91]	sold
2026-01-07 17:00:09.411577	cam1	Jagermeister	700ml	0.8442	1461	42jagermeisterB	[124,345,200,193]	restock
2025-10-18 05:47:08.411577	cam1	Sprite	390ml	0.7684	1462	59spriteK	[160,175,218,33]	sold
2025-12-02 15:56:22.411577	cam1	Crystalline	330ml	0.8316	1463	55crystalinK	[31,225,126,184]	sold
2025-04-23 13:55:25.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.7974	1464	14santai_agaK	[162,234,218,32]	restock
2025-03-23 09:18:06.411577	cam1	Bintang	Radler 330ml	0.838	1465	06bintang_radlerS	[28,212,236,75]	restock
2025-11-11 14:27:53.411577	cam1	Kura Kura	Session Hazy 330ml	0.776	1466	05kura_shK	[211,253,43,234]	added
2025-06-04 09:19:43.411577	cam1	Pokka	Green Tea 300ml	0.7751	1467	57pokkaK	[121,271,49,194]	sold
2025-09-05 09:12:59.411577	cam1	Sababay	Mascetti 750ml	0.9799	1468	02sababay_masB	[283,307,107,217]	added
2026-02-08 12:04:40.411577	cam1	Vibe	Exotic Lychee 700ml	0.755	1469	11vibe_elB	[335,298,238,85]	sold
2026-01-14 19:04:35.411577	cam1	Rajawali	Prost 620ml	0.8451	1470	19rajawali_prostB	[65,143,149,153]	restock
2025-10-06 12:45:15.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.9743	1471	10kawa_hijauB	[21,241,219,126]	restock
2025-10-17 01:07:40.411577	cam1	Bullsit	Gin 500ml	0.7936	1472	16bullsit_gS	[400,325,49,237]	added
2025-11-29 16:42:22.411577	cam1	Canard	Witbier 330ml	0.6985	1473	04canard_wK	[214,372,134,189]	added
2026-02-27 00:40:20.411577	cam1	Santai	Passionfruit & Guava 330ml	0.9847	1474	14santai_pgK	[119,119,150,172]	sold
2025-07-25 07:25:38.411577	cam1	Captain Morgan	Silver Rum 750ml	0.8095	1475	35cm_ssB	[168,270,120,73]	sold
2025-08-03 02:31:20.411577	cam1	Suntory Roku	Gin 700ml	0.7051	1476	43rokuB	[140,171,92,61]	added
2025-10-16 07:31:31.411577	cam1	Kulturale	Naganini 330ml	0.82	1477	09kulturale_nbwK	[192,355,113,93]	restock
2025-08-21 16:08:35.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.7793	1478	01ot_apihjB	[258,383,134,176]	sold
2026-03-02 04:35:40.411577	cam1	Iceland	Orange 700ml	0.8203	1479	03iceland_oB	[387,250,58,197]	added
2025-06-24 05:03:28.411577	cam1	Guiness	Draught Stout 500ml	0.8783	1480	34guiness_dsBC	[319,303,220,99]	added
2025-04-22 11:05:46.411577	cam1	Bullsit	Gin 500ml	0.7138	1481	16bullsit_gS	[71,221,56,92]	sold
2025-05-14 10:47:42.411577	cam1	Albens	Apple Lychee Cider 330ml	0.74	1482	07albens_alcS	[337,159,64,50]	sold
2026-02-01 07:20:43.411577	cam1	Canard	Strawberry Gose 330ml	0.9348	1483	04canard_sgK	[221,190,214,138]	sold
2026-02-26 16:22:05.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.773	1484	10kawa_hijauB	[353,195,154,191]	added
2026-03-04 07:39:46.411577	cam1	Captain Morgan	Spice Gold 750ml	0.7204	1485	35cm_sgB	[320,384,213,61]	added
2025-12-26 17:53:28.411577	cam1	Sababay	Pink Blossom 750ml	0.8904	1486	02sababay_pbB	[325,97,138,185]	sold
2026-02-12 04:34:07.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.7725	1487	10kawa_hijauB	[203,249,153,148]	added
2025-12-06 18:53:30.411577	cam1	Chum Churum	Yogurt 360ml	0.9546	1488	12chum_yS	[97,102,59,195]	added
2025-08-05 20:14:02.411577	cam1	Kulturale	Bravo 330ml	0.9417	1489	09kulturale_bK	[227,140,143,246]	added
2025-08-03 04:05:18.411577	cam1	Santai	Lemon & Lime 330ml	0.768	1490	14santai_llK	[360,265,178,64]	sold
2026-02-24 05:54:17.411577	cam1	Cham Joeun	Lychee 360ml	0.8087	1491	40chamj_lS	[53,136,185,127]	added
2025-12-29 11:19:48.411577	cam1	Bintang	Pilsener 330ml	0.9603	1492	06bintangK	[356,286,124,190]	added
2025-09-25 12:19:45.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.7888	1493	14santai_agaK	[223,281,118,103]	added
2025-09-03 17:50:10.411577	cam1	Asahi	Super Dry 334ml	0.7885	1494	48asahiK	[153,349,155,194]	sold
2025-06-27 13:14:19.411577	cam1	Albens	Apple Cier 330ml	0.9838	1495	07albensS	[54,290,181,40]	sold
2025-09-20 00:35:12.411577	cam1	Canard	Witbier 330ml	0.6948	1496	04canard_wK	[217,138,62,78]	sold
2025-12-19 05:36:23.411577	cam1	Kura Kura	Island Ale 330ml	0.7592	1497	05kura_iaK	[251,28,122,56]	added
2026-01-25 00:45:14.411577	cam1	Asahi	Super Dry 334ml	0.8283	1498	48asahiK	[206,233,183,151]	sold
2025-04-07 21:53:01.411577	cam1	Guiness	Draught Stout 500ml	0.8052	1499	34guiness_dsBC	[200,244,161,190]	sold
2025-06-29 07:04:44.411577	cam1	Kulturale	Naganini 330ml	0.9168	1500	09kulturale_nbwK	[66,164,90,118]	sold
2025-07-09 07:44:58.411577	cam1	Orang Tua	Anggur Merah 620ml	0.743	1501	01ot_amerB	[170,269,233,42]	restock
2025-10-12 16:44:25.411577	cam1	Gilbey's	Whisky 350ml	0.7231	1502	37gilbeys_wS	[320,34,230,141]	added
2025-11-18 10:33:58.411577	cam1	Sprite	390ml	0.8498	1503	59spriteK	[210,152,217,64]	sold
2025-05-16 23:29:06.411577	cam1	Vibe	Exotic Lychee 700ml	0.7826	1504	11vibe_elB	[363,43,238,177]	sold
2026-01-23 07:00:38.411577	cam1	Crystalline	330ml	0.6644	1505	55crystalinK	[317,60,216,35]	added
2025-05-17 18:29:34.411577	cam1	Pokka	Green Tea 300ml	0.856	1506	57pokkaK	[80,327,228,111]	added
2025-10-10 07:45:19.411577	cam1	Wija	Blueberry 360ml	0.9493	1507	15wija_bS	[356,114,205,217]	sold
2026-02-13 15:10:24.411577	cam1	Royal Brewhouse	Gold Royale 350ml	0.8908	1508	18rb_grS	[119,369,147,158]	restock
2026-03-07 22:02:11.411577	cam1	Suntory Roku	Gin 700ml	0.9312	1509	43rokuB	[26,50,151,157]	added
2025-05-30 19:10:34.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.7462	1510	01ot_amergoldB	[59,186,221,143]	added
2025-04-13 10:43:20.411577	cam1	Iceland	Original 250ml	0.9233	1511	03icelandK	[64,25,105,85]	added
2025-12-28 07:00:15.411577	cam1	Gilbey's	Gin 350ml	0.9129	1512	37gilbeys_gS	[116,127,227,243]	sold
2025-04-16 10:14:30.411577	cam1	Canard	Witbier 330ml	0.6993	1513	04canard_wK	[130,43,156,234]	restock
2025-03-28 11:13:42.411577	cam1	Three Peaks	Dry Gin 700ml	0.7493	1514	33threep_dgB	[175,143,158,171]	added
2025-10-01 09:16:47.411577	cam1	Baliwein	Anggur Salak 750ml	0.7718	1515	08baliwein_absB	[200,172,211,167]	restock
2025-10-30 01:45:26.411577	cam1	Orang Tua	Anggur Merah 620ml	0.8453	1516	01ot_amerB	[285,173,157,212]	sold
2025-05-01 18:52:20.411577	cam1	Wija	Blueberry 360ml	0.733	1517	15wija_bS	[357,357,62,144]	sold
2025-06-15 14:23:35.411577	cam1	Pu Tao Chee Chiew	330ml	0.7125	1518	31putaoccS	[74,222,89,80]	sold
2026-03-01 08:15:43.411577	cam1	Wija	Blueberry 360ml	0.8596	1519	15wija_bS	[221,217,90,219]	added
2025-07-09 07:33:03.411577	cam1	Guiness	Foreign Extra Stout 620ml	0.9801	1520	34guiness_fesB	[296,100,237,156]	added
2025-06-08 19:04:37.411577	cam1	Vibe	Exotic Lychee 700ml	0.9046	1521	11vibe_elB	[86,31,145,177]	sold
2025-07-19 19:34:10.411577	cam1	Santai	Passionfruit & Guava 330ml	0.9515	1522	14santai_pgK	[69,42,239,82]	sold
2025-06-17 23:51:02.411577	cam1	Chum Churum	Yogurt 360ml	0.6514	1523	12chum_yS	[91,54,139,181]	sold
2025-08-01 08:10:28.411577	cam1	Canard	Weizenbock 330ml	0.6741	1524	04canard_weK	[154,77,86,196]	restock
2025-04-14 09:44:12.411577	cam1	Sababay	Pink Blossom 750ml	0.9734	1525	02sababay_pbB	[318,341,54,103]	added
2025-04-14 09:46:42.411577	cam1	Kulturale	Amarillo 330ml	0.8019	1526	09kulturale_aK	[77,271,80,216]	sold
2025-07-20 22:51:42.411577	cam1	Three Peaks	Dry Gin 700ml	0.9361	1527	33threep_dgB	[13,108,44,146]	added
2026-02-13 09:42:12.411577	cam1	Bullsit	Vodka 500ml	0.8783	1528	16bullsit_vS	[350,41,180,136]	restock
2025-12-09 00:23:41.411577	cam1	Iceland	Orange 700ml	0.7829	1529	03iceland_oB	[100,211,79,104]	added
2025-08-17 16:43:13.411577	cam1	Canard	Weizenbock 330ml	0.8093	1530	04canard_weK	[194,82,191,233]	sold
2025-07-08 01:17:07.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.7832	1531	01ot_apihjB	[317,133,38,209]	restock
2025-04-15 22:44:06.411577	cam1	Bintang	Radler 330ml	0.8049	1532	06bintang_radlerS	[11,285,79,77]	sold
2025-07-10 12:32:54.411577	cam1	Canard	Strawberry Gose 330ml	0.863	1533	04canard_sgK	[85,347,33,118]	sold
2025-06-11 08:39:04.411577	cam1	Pu Tao Chee Chiew	330ml	0.662	1534	31putaoccS	[373,226,62,196]	added
2025-10-13 16:25:46.411577	cam1	Bullsit	Gin 500ml	0.9048	1535	16bullsit_gS	[263,305,166,172]	restock
2025-03-28 22:57:03.411577	cam1	Vibe	Black Tea 700ml	0.8233	1536	11vibe_btB	[23,252,186,156]	added
2025-11-12 19:14:17.411577	cam1	Baileys	Irish Cream 750ml	0.7003	1537	51baileys_icB	[170,346,81,164]	sold
2025-12-08 22:23:38.411577	cam1	Cham Joeun	Lychee 360ml	0.7176	1538	40chamj_lS	[367,109,88,174]	added
2025-07-13 22:39:13.411577	cam1	Iceland	Berry Lemonade 275ml	0.8205	1539	03iceland_beleS	[373,331,41,155]	sold
2025-06-28 21:41:52.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.8149	1540	01ot_amergoldB	[11,378,157,188]	restock
2025-04-11 12:16:48.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.711	1541	23palapaB	[272,198,204,46]	added
2025-07-31 08:21:03.411577	cam1	Cham Joeun	Soju 360ml	0.945	1542	40chamjS	[43,163,219,199]	sold
2026-01-28 12:40:16.411577	cam1	Guiness	Foreign Extra Stout 320ml	0.9252	1543	34guinessK_fesKC	[274,347,178,94]	sold
2025-11-18 03:18:11.411577	cam1	Bintang	Pilsener 330ml	0.7112	1544	06bintangK	[271,19,182,58]	sold
2025-04-04 05:35:45.411577	cam1	Orang Tua	Intisari Anggur Hijau 620ml	0.8734	1545	01ot_hijauintB	[125,389,205,56]	sold
2025-04-07 15:19:17.411577	cam1	Baliwein	Sekala 750ml	0.6516	1546	08baliwein_sekB	[364,295,204,235]	sold
2025-10-21 14:29:31.411577	cam1	Baliwein	Semara 750ml	0.6662	1547	08baliwein_semB	[172,263,134,160]	sold
2025-12-29 13:42:11.411577	cam1	Chum Churum	Yogurt 360ml	0.6616	1548	12chum_yS	[328,238,92,129]	added
2026-01-14 10:00:50.411577	cam1	Iceland	Blue Lagoon 275ml	0.8799	1549	03iceland_blS	[343,378,85,67]	sold
2025-12-09 00:46:46.411577	cam1	Albens	Apple Cier 330ml	0.9447	1550	07albensS	[210,28,48,192]	added
2025-05-19 02:43:46.411577	cam1	Drum	Whisky Black 700ml	0.7964	1551	22drum_wbB	[294,83,186,125]	added
2025-09-12 02:37:24.411577	cam1	Crystalline	330ml	0.9653	1552	55crystalinK	[133,104,207,166]	restock
2025-08-08 01:13:56.411577	cam1	Orang Tua	Atlas Lychee 620ml	0.9018	1553	01ot_atlaslB	[104,363,201,55]	added
2026-03-11 03:16:48.411577	cam1	Kulturale	Amarillo 330ml	0.9211	1554	09kulturale_aK	[137,75,198,125]	added
2026-01-22 07:54:07.411577	cam1	Orang Tua	Anggur Putih 620ml	0.8644	1555	01ot_aputB	[366,333,192,175]	sold
2025-08-03 03:45:50.411577	cam1	Kura Kura	Island Ale 330ml	0.8223	1556	05kura_iaK	[12,145,48,95]	added
2026-02-28 16:08:05.411577	cam1	Asahi	Super Dry 334ml	0.7139	1557	48asahiK	[221,328,114,189]	added
2025-07-19 15:48:37.411577	cam1	Wija	Blueberry 360ml	0.8645	1558	15wija_bS	[261,99,73,31]	added
2025-11-07 04:00:34.411577	cam1	Albens	Apple Mango Cider 330ml	0.7616	1559	07albens_amcS	[54,40,102,48]	restock
2025-06-21 08:12:30.411577	cam1	Sababay	Ludisia 750ml	0.665	1560	02sababay_lB	[399,329,245,208]	added
2025-04-07 00:06:45.411577	cam1	Canard	Witbier 330ml	0.665	1561	04canard_wK	[313,71,46,157]	sold
2025-03-28 23:33:46.411577	cam1	Polaris	Soda Water 330ml	0.7543	1562	54polarisK	[270,76,155,58]	added
2026-01-03 14:00:26.411577	cam1	Iceland	Original 250ml	0.8308	1563	03icelandK	[125,335,163,38]	restock
2025-03-31 09:00:48.411577	cam1	Baliwein	Semara 750ml	0.8867	1564	08baliwein_semB	[362,14,94,236]	added
2025-06-22 11:54:41.411577	cam1	Sprite	390ml	0.9026	1565	59spriteK	[213,345,175,114]	added
2025-12-09 13:12:53.411577	cam1	Sapporo	330ml	0.8032	1566	49sapporoK	[181,397,237,44]	added
2025-04-17 09:49:35.411577	cam1	Heineken	330ml	0.9155	1567	46heinekenS	[54,108,218,96]	sold
2026-01-07 01:18:58.411577	cam1	Orang Tua	Anggur Merah 275ml	0.7565	1568	01ot_amerS	[364,135,87,225]	restock
2025-07-23 18:57:35.411577	cam1	Jose Cuervo	750ml	0.7908	1569	50josecuervoB	[386,61,126,137]	sold
2025-08-27 17:58:52.411577	cam1	Captain Morgan	Silver Rum 750ml	0.877	1570	35cm_ssB	[397,344,100,191]	added
2025-07-24 03:27:45.411577	cam1	Sababay	Mascetti 750ml	0.936	1571	02sababay_masB	[66,110,149,183]	sold
2025-12-29 13:04:21.411577	cam1	Canard	Session IPA 330ml	0.9022	1572	04canard_siK	[219,176,122,188]	sold
2026-02-12 09:40:39.411577	cam1	Three Peaks	Dry Gin 700ml	0.7362	1573	33threep_dgB	[296,183,193,228]	restock
2025-08-30 13:13:20.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.7898	1574	23palapaB	[221,150,149,212]	added
2025-07-08 20:37:31.411577	cam1	Kura Kura	Session Hazy 330ml	0.6723	1575	05kura_shK	[320,330,139,187]	sold
2025-10-11 05:54:47.411577	cam1	Kulturale	Amarillo 330ml	0.6683	1576	09kulturale_aK	[289,180,119,126]	restock
2025-09-08 07:07:35.411577	cam1	Canard	Weizenbock 330ml	0.7152	1577	04canard_weK	[102,218,162,136]	added
2025-08-20 14:06:18.411577	cam1	Gilbey's	Whisky 350ml	0.8336	1578	37gilbeys_wS	[68,125,232,94]	added
2025-06-17 21:03:22.411577	cam1	Vibe	Exotic Lychee 700ml	0.7535	1579	11vibe_elB	[101,334,197,219]	added
2025-05-06 15:23:40.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.8117	1580	01ot_apihjB	[80,67,126,108]	added
2026-01-01 07:27:17.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.7408	1581	01ot_atlasrpB	[281,310,203,185]	added
2025-05-13 03:14:02.411577	cam1	Wija	Blueberry 360ml	0.6652	1582	15wija_bS	[197,267,249,210]	restock
2025-03-31 16:45:34.411577	cam1	Iceland	Lychee Martini 275ml	0.6892	1583	03iceland_lmS	[40,369,171,218]	added
2025-06-16 17:42:59.411577	cam1	Rajawali	Prost 620ml	0.9306	1584	19rajawali_prostB	[161,342,86,85]	sold
2025-04-25 06:13:27.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.7572	1585	01ot_apihjB	[142,16,112,114]	sold
2025-12-09 01:40:17.411577	cam1	Beaches	Cerveza 330ml	0.8164	1586	32beachescK	[32,192,175,248]	added
2025-03-29 11:39:29.411577	cam1	Smirnoff	Vodka 700ml	0.8411	1587	45smirnoffB	[165,45,248,41]	sold
2025-09-13 18:18:53.411577	cam1	Kura Kura	IPA 330ml	0.8428	1588	05kura_ipaK	[87,264,170,90]	added
2025-06-10 01:21:35.411577	cam1	Vibe	Exotic Lychee 700ml	0.9483	1589	11vibe_elB	[129,123,151,42]	added
2025-07-08 00:39:50.411577	cam1	Extra Joss	Ultimate 250ml	0.9876	1590	53extrajK	[251,139,143,65]	sold
2025-04-06 16:55:55.411577	cam1	Wija	Lychee 360ml	0.9289	1591	15wija_lS	[328,358,131,59]	added
2025-04-18 03:54:23.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.9202	1592	10kawa_merahB	[66,366,79,142]	sold
2025-07-02 12:19:44.411577	cam1	New City	1L	0.9301	1593	24newcityB	[267,283,221,134]	restock
2026-02-24 14:01:32.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.8335	1594	01ot_amergoldB	[29,359,246,203]	added
2025-06-24 19:44:49.411577	cam1	Wija	Soju 360ml	0.8738	1595	15wijaS	[276,114,126,81]	sold
2025-10-04 03:07:53.411577	cam1	Orang Tua	Intisari Blackcurrant 620ml	0.8738	1596	01ot_bcintB	[183,18,117,34]	sold
2025-10-21 00:50:01.411577	cam1	Bacardi	Carta Blanca 750ml	0.7355	1597	36bacardi_cbB	[301,93,55,229]	sold
2025-04-19 06:03:43.411577	cam1	Albens	Apple Lychee Cider 330ml	0.7033	1598	07albens_alcS	[28,84,180,99]	added
2025-09-23 17:16:57.411577	cam1	Bullsit	Whisky 500ml	0.9263	1599	16bullsit_wS	[369,176,205,30]	added
2025-03-24 11:44:33.411577	cam1	Orang Tua	Anggur Putih 620ml	0.7539	1600	01ot_aputB	[238,44,75,199]	sold
2026-01-12 03:11:13.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.8388	1601	23palapaB	[156,307,46,109]	added
2025-10-29 07:28:57.411577	cam1	Bullsit	Vodka 500ml	0.8924	1602	16bullsit_vS	[306,189,40,146]	added
2025-09-16 23:53:02.411577	cam1	Bacardi	Spiced Rum 750ml	0.9705	1603	36bacardi_srB	[158,185,208,215]	restock
2025-08-03 10:17:29.411577	cam1	Bintang	Radler 330ml	0.9777	1604	06bintang_radlerS	[115,240,232,234]	added
2025-03-27 06:55:27.411577	cam1	Orang Tua	Arak Obat 620ml	0.6828	1605	01ot_aoB	[61,308,136,136]	sold
2025-06-18 23:06:06.411577	cam1	Orang Tua	Anggur Merah 620ml	0.7637	1606	01ot_amerB	[321,382,242,196]	added
2025-10-14 13:23:29.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.7965	1607	01ot_apiptB	[101,21,176,50]	sold
2025-11-23 15:47:38.411577	cam1	Smirnoff	Vodka 700ml	0.8381	1608	45smirnoffB	[238,243,34,103]	added
2025-03-30 00:06:22.411577	cam1	Kulturale	Amarillo 330ml	0.822	1609	09kulturale_aK	[105,178,237,137]	sold
2025-04-23 06:32:33.411577	cam1	Gilbey's	Whisky 350ml	0.8259	1610	37gilbeys_wS	[350,166,194,34]	sold
2025-12-28 01:47:05.411577	cam1	Sprite	390ml	0.7695	1611	59spriteK	[50,95,56,222]	sold
2025-05-23 21:32:16.411577	cam1	Three Peaks	Dry Gin 700ml	0.9734	1612	33threep_dgB	[290,296,213,135]	added
2025-09-13 15:25:27.411577	cam1	Iceland	Lychee Martini 275ml	0.7294	1613	03iceland_lmS	[230,170,39,85]	added
2025-11-21 12:49:27.411577	cam1	Sprite	390ml	0.8562	1614	59spriteK	[86,191,145,36]	sold
2025-12-17 00:30:12.411577	cam1	Chum Churum	Yogurt 360ml	0.7118	1615	12chum_yS	[106,34,104,200]	added
2025-08-22 14:56:38.411577	cam1	Sababay	Black Velvet 750ml	0.8494	1616	02sababay_bvB	[399,368,79,63]	added
2025-03-24 19:13:30.411577	cam1	Pu Tao Chee Chiew	330ml	0.8472	1617	31putaoccS	[249,169,80,99]	sold
2025-12-08 14:49:27.411577	cam1	Sababay	Mascetti 750ml	0.8394	1618	02sababay_masB	[306,121,133,247]	restock
2025-03-14 19:18:50.411577	cam1	Bacardi	Carta Blanca 750ml	0.7734	1619	36bacardi_cbB	[131,386,46,222]	added
2025-05-08 14:40:40.411577	cam1	Suntory Roku	Gin 700ml	0.8374	1620	43rokuB	[323,193,33,133]	sold
2025-06-15 00:30:33.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.7695	1621	01ot_amergoldB	[77,19,238,48]	restock
2025-12-22 02:35:31.411577	cam1	Albens	Apple Cier 330ml	0.8825	1622	07albensS	[315,189,73,163]	sold
2025-06-17 00:53:21.411577	cam1	Kura Kura	Island Ale 330ml	0.6833	1623	05kura_iaK	[38,359,113,122]	sold
2025-04-17 16:53:49.411577	cam1	Vibe	Exotic Lychee 700ml	0.6549	1624	11vibe_elB	[67,14,69,114]	restock
2025-10-29 00:55:12.411577	cam1	Rajawali	Prost 620ml	0.9765	1625	19rajawali_prostB	[192,93,194,110]	sold
2025-11-14 03:03:42.411577	cam1	Asahi	Super Dry 334ml	0.8947	1626	48asahiK	[274,340,146,154]	restock
2025-10-06 10:18:41.411577	cam1	Gilbey's	Whisky 350ml	0.9591	1627	37gilbeys_wS	[22,146,131,190]	sold
2025-08-31 03:31:38.411577	cam1	Yakult	1 pack 325ml	0.7947	1628	60yakultK	[396,250,121,104]	sold
2025-04-17 00:39:14.411577	cam1	Baileys	Irish Cream 750ml	0.9418	1629	51baileys_icB	[359,293,59,177]	restock
2025-03-22 16:25:17.411577	cam1	Gilbey's	Whisky 350ml	0.6887	1630	37gilbeys_wS	[377,299,37,136]	added
2026-03-08 09:26:37.411577	cam1	Kulturale	L. L. Stout 330ml	0.8498	1631	09kulturale_llsK	[161,252,37,89]	sold
2025-12-14 09:50:47.411577	cam1	Bintang	Pilsener 330ml	0.688	1632	06bintangK	[212,45,104,219]	sold
2025-07-02 23:40:46.411577	cam1	Polaris	Soda Water 330ml	0.8728	1633	54polarisK	[282,144,150,53]	sold
2025-12-22 04:57:22.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.897	1634	23palapaB	[214,138,208,98]	restock
2025-10-21 21:35:58.411577	cam1	Kulturale	Naganini 330ml	0.922	1635	09kulturale_nbwK	[118,191,111,77]	sold
2026-02-01 10:46:21.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.6872	1636	01ot_apiptB	[90,172,75,152]	restock
2025-06-30 20:49:14.411577	cam1	Crystalline	330ml	0.768	1637	55crystalinK	[41,301,72,216]	restock
2026-01-19 12:20:00.411577	cam1	Corona	Extra 355ml	0.945	1638	47corona_eS	[373,68,37,191]	sold
2025-05-22 19:04:00.411577	cam1	Kulturale	Naganini 330ml	0.9385	1639	09kulturale_nbwK	[274,162,117,190]	added
2026-01-09 08:51:22.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.8675	1640	14santai_agaK	[359,147,106,35]	sold
2025-11-24 22:51:14.411577	cam1	Rajawali	Prost 620ml	0.7264	1641	19rajawali_prostB	[125,120,162,152]	sold
2025-12-01 07:53:20.411577	cam1	Iceland	Original 700ml	0.8925	1642	03icelandB	[229,148,237,103]	added
2025-12-09 06:33:07.411577	cam1	Iceland	Orange 700ml	0.8633	1643	03iceland_oB	[204,22,228,56]	added
2025-04-27 02:10:35.411577	cam1	Kulturale	Naganini 330ml	0.9884	1644	09kulturale_nbwK	[89,300,189,135]	sold
2026-03-10 17:37:17.411577	cam1	Polaris	Soda Water 330ml	0.9419	1645	54polarisK	[28,279,128,190]	restock
2025-05-01 02:15:57.411577	cam1	Baileys	Irish Cream 750ml	0.7171	1646	51baileys_icB	[160,227,74,31]	sold
2025-07-01 03:52:20.411577	cam1	Kura Kura	Session Hazy 330ml	0.9834	1647	05kura_shK	[150,101,80,171]	restock
2025-03-17 03:40:27.411577	cam1	Captain Morgan	Spice Gold 750ml	0.7041	1648	35cm_sgB	[39,254,78,123]	sold
2025-08-25 01:22:56.411577	cam1	Baliwein	Semara 750ml	0.9308	1649	08baliwein_semB	[315,176,91,168]	sold
2025-11-15 17:09:00.411577	cam1	Iceland	Original 700ml	0.9873	1650	03icelandB	[206,371,230,109]	sold
2025-10-09 21:29:46.411577	cam1	Kura Kura	Easy Ale 330ml	0.6988	1651	05kura_eaK	[16,333,113,136]	restock
2025-08-21 00:22:44.411577	cam1	New City	1L	0.8369	1652	24newcityB	[99,339,96,48]	restock
2025-09-06 20:31:56.411577	cam1	Gilbey's	Whisky 350ml	0.7965	1653	37gilbeys_wS	[392,265,115,65]	added
2026-02-01 22:15:45.411577	cam1	Captain Morgan	Silver Rum 750ml	0.7353	1654	35cm_ssB	[126,219,80,88]	restock
2025-08-29 03:50:50.411577	cam1	Orang Tua	Anggur Putih 620ml	0.7978	1655	01ot_aputB	[278,308,132,195]	added
2025-11-26 11:16:20.411577	cam1	Wija	Soju 360ml	0.8579	1656	15wijaS	[46,291,244,187]	sold
2025-07-09 09:24:37.411577	cam1	Cham Joeun	Lychee 360ml	0.8359	1657	40chamj_lS	[277,247,219,182]	sold
2025-08-30 20:53:33.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.7288	1658	23palapaB	[197,364,86,228]	sold
2025-11-27 15:02:45.411577	cam1	Albens	Apple Mango Cider 330ml	0.7639	1659	07albens_amcS	[363,58,91,120]	added
2026-02-18 08:45:11.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.9659	1660	10kawa_merahB	[73,130,35,204]	sold
2025-11-26 11:36:54.411577	cam1	Wija	Lychee 360ml	0.8507	1661	15wija_lS	[286,104,189,141]	restock
2025-08-30 02:58:32.411577	cam1	New City	1L	0.8682	1662	24newcityB	[106,10,227,165]	added
2025-12-29 09:56:04.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.8781	1663	10kawa_hijauB	[301,189,87,211]	restock
2025-10-21 19:05:55.411577	cam1	Orang Tua	Anggur Merah 620ml	0.6616	1664	01ot_amerB	[368,346,223,36]	restock
2025-08-21 23:24:24.411577	cam1	Bacardi	Carta Blanca 750ml	0.9211	1665	36bacardi_cbB	[60,21,162,182]	restock
2025-06-03 14:23:55.411577	cam1	New City	1L	0.8607	1666	24newcityB	[192,274,87,211]	sold
2025-12-14 21:28:39.411577	cam1	Gilbey's	Whisky 350ml	0.9614	1667	37gilbeys_wS	[278,272,240,241]	added
2025-03-22 07:02:35.411577	cam1	Orang Tua	Intisari Anggur Hijau 620ml	0.8821	1668	01ot_hijauintB	[305,163,210,202]	added
2025-09-15 05:19:54.411577	cam1	Captain Morgan	Silver Rum 750ml	0.9618	1669	35cm_ssB	[34,345,90,133]	added
2025-10-25 03:07:40.411577	cam1	Captain Morgan	Silver Rum 750ml	0.7367	1670	35cm_ssB	[304,168,207,244]	restock
2026-01-03 11:36:10.411577	cam1	Iceland	Original 250ml	0.9213	1671	03icelandK	[11,380,120,84]	sold
2025-07-30 01:34:48.411577	cam1	Bullsit	Vodka 500ml	0.9001	1672	16bullsit_vS	[358,56,196,152]	restock
2026-01-17 00:51:46.411577	cam1	Albens	Apple Cier 330ml	0.8699	1673	07albensS	[135,78,92,39]	added
2026-02-05 05:34:40.411577	cam1	Cham Joeun	Soju 360ml	0.8917	1674	40chamjS	[28,352,220,221]	sold
2025-08-18 12:45:35.411577	cam1	Batavia	Whisky 700ml	0.7087	1675	21bataviaB	[77,142,108,78]	sold
2025-05-04 09:08:17.411577	cam1	Santai	Lemon & Lime 330ml	0.7996	1676	14santai_llK	[250,298,202,163]	sold
2025-12-26 05:08:47.411577	cam1	Royal Brewhouse	Gold Royale 350ml	0.9331	1677	18rb_grS	[348,368,76,113]	added
2026-01-21 10:42:37.411577	cam1	Orang Tua	Anggur Merah 620ml	0.7505	1678	01ot_amerB	[254,204,170,72]	added
2025-05-05 06:49:52.411577	cam1	Kura Kura	Lager 330ml	0.9806	1679	05kura_lK	[383,86,84,213]	sold
2025-10-19 11:37:08.411577	cam1	Canard	Porter 330ml	0.8218	1680	04canard_pK	[279,235,229,71]	restock
2025-05-26 01:46:01.411577	cam1	Gordon's	PinkPremium 750ml	0.8028	1681	44gordon_ppB	[20,10,127,76]	added
2025-03-22 05:47:41.411577	cam1	Santai	Passionfruit & Guava 330ml	0.6501	1682	14santai_pgK	[10,88,116,162]	sold
2025-09-09 17:12:40.411577	cam1	Three Peaks	Dry Gin 700ml	0.9736	1683	33threep_dgB	[205,191,131,167]	added
2025-03-21 05:57:20.411577	cam1	Santai	Lemon & Lime 330ml	0.9703	1684	14santai_llK	[40,231,205,126]	sold
2026-01-28 23:40:17.411577	cam1	Albens	Apple Mango Cider 330ml	0.9395	1685	07albens_amcS	[280,99,164,119]	sold
2025-07-20 19:07:16.411577	cam1	Batavia	Whisky 700ml	0.7672	1686	21bataviaB	[54,343,175,163]	sold
2026-02-04 03:55:07.411577	cam1	Albens	Apple Lychee Cider 330ml	0.9833	1687	07albens_alcS	[372,196,179,168]	restock
2025-12-31 19:22:35.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.9578	1688	19rajawali_prostalK	[30,93,222,210]	restock
2025-12-14 17:28:24.411577	cam1	Sapporo	330ml	0.8958	1689	49sapporoK	[257,309,208,92]	restock
2025-03-23 17:18:53.411577	cam1	Canard	Witbier 330ml	0.8565	1690	04canard_wK	[165,391,205,185]	restock
2025-10-30 16:30:20.411577	cam1	Suntory Roku	Gin 700ml	0.8098	1691	43rokuB	[263,28,79,110]	added
2026-01-08 22:39:21.411577	cam1	Pokka	Green Tea 300ml	0.8744	1692	57pokkaK	[333,36,171,191]	added
2025-07-05 07:37:23.411577	cam1	Canard	Kolsch 330ml	0.8848	1693	04canard_kK	[75,141,144,124]	sold
2025-12-19 03:20:01.411577	cam1	Beaches	Cerveza 330ml	0.9313	1694	32beachescK	[345,151,113,32]	added
2025-09-20 16:19:56.411577	cam1	Canard	Session IPA 330ml	0.8678	1695	04canard_siK	[233,177,79,159]	sold
2025-08-28 02:37:14.411577	cam1	Kura Kura	Lager 330ml	0.6726	1696	05kura_lK	[147,360,70,173]	added
2025-05-10 21:51:27.411577	cam1	Kulturale	Amarillo 330ml	0.788	1697	09kulturale_aK	[94,186,125,189]	restock
2025-07-04 06:15:56.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.9002	1698	08baliwein_abjmB	[117,239,200,91]	restock
2025-04-05 19:11:34.411577	cam1	Orang Tua	Intisari Anggur Hijau 620ml	0.6819	1699	01ot_hijauintB	[148,43,34,45]	sold
2025-05-25 00:03:49.411577	cam1	Canard	Porter 330ml	0.9492	1700	04canard_pK	[193,390,220,103]	restock
2025-10-16 13:52:26.411577	cam1	Iceland	Berry Lemonade 275ml	0.9364	1701	03iceland_beleS	[57,249,155,151]	sold
2025-03-30 17:47:14.411577	cam1	Kura Kura	IPA 330ml	0.7773	1702	05kura_ipaK	[384,152,135,131]	sold
2025-05-25 02:35:18.411577	cam1	Bullsit	Vodka 500ml	0.7685	1703	16bullsit_vS	[40,257,175,161]	added
2025-05-11 13:16:07.411577	cam1	Suntory Roku	Gin 700ml	0.8324	1704	43rokuB	[99,211,151,151]	sold
2025-06-05 15:51:31.411577	cam1	Albens	Apple Mango Cider 330ml	0.9436	1705	07albens_amcS	[242,38,151,41]	sold
2025-05-09 22:17:41.411577	cam1	Orang Tua	Anggur Merah 620ml	0.86	1706	01ot_amerB	[91,365,244,168]	added
2025-09-28 12:28:22.411577	cam1	Three Peaks	Dry Gin 700ml	0.8756	1707	33threep_dgB	[201,189,45,196]	added
2025-09-23 08:49:00.411577	cam1	Captain Morgan	Spice Gold 750ml	0.9455	1708	35cm_sgB	[315,38,83,246]	restock
2025-08-12 15:45:11.411577	cam1	Kura Kura	Easy Ale 330ml	0.6914	1709	05kura_eaK	[165,198,154,204]	sold
2025-04-26 11:25:35.411577	cam1	Batavia	Whisky 700ml	0.6576	1710	21bataviaB	[168,250,220,245]	added
2025-03-26 13:33:33.411577	cam1	Yakult	1 pack 325ml	0.7632	1711	60yakultK	[374,207,206,46]	sold
2025-12-16 03:26:21.411577	cam1	Kulturale	L. L. Stout 330ml	0.9656	1712	09kulturale_llsK	[278,182,102,59]	restock
2025-08-31 17:05:41.411577	cam1	Kulturale	Amarillo 330ml	0.7452	1713	09kulturale_aK	[77,345,33,71]	added
2025-12-07 03:05:03.411577	cam1	Three Peaks	Dry Gin 700ml	0.8785	1714	33threep_dgB	[33,50,223,243]	sold
2025-05-07 20:23:09.411577	cam1	Kura Kura	IPA 330ml	0.7263	1715	05kura_ipaK	[220,69,63,180]	restock
2026-03-09 20:21:13.411577	cam1	Jagermeister	700ml	0.9166	1716	42jagermeisterB	[193,177,147,52]	restock
2025-08-23 00:47:25.411577	cam1	Polaris	Soda Water 330ml	0.8849	1717	54polarisK	[399,170,194,200]	sold
2026-02-04 06:42:22.411577	cam1	Sapporo	330ml	0.7334	1718	49sapporoK	[228,73,94,78]	sold
2025-05-15 07:12:01.411577	cam1	Orang Tua	Anggur Putih 620ml	0.8494	1719	01ot_aputB	[205,352,44,30]	restock
2025-10-30 16:25:08.411577	cam1	Kulturale	Amarillo 330ml	0.8398	1720	09kulturale_aK	[397,379,84,72]	sold
2025-08-19 18:22:54.411577	cam1	Chum Churum	Peach 360ml	0.8007	1721	12chum_pS	[146,117,227,237]	restock
2026-01-22 09:08:38.411577	cam1	Corona	Extra 355ml	0.8577	1722	47corona_eS	[189,72,177,156]	added
2026-01-12 16:45:20.411577	cam1	Orang Tua	Anggur Merah 275ml	0.8157	1723	01ot_amerS	[86,304,34,237]	added
2025-10-12 20:53:08.411577	cam1	Royal Brewhouse	Gold Royale 350ml	0.8736	1724	18rb_grS	[328,76,122,81]	sold
2026-02-13 00:34:38.411577	cam1	Baliwein	Sekala 750ml	0.7153	1725	08baliwein_sekB	[74,385,178,97]	restock
2025-03-28 22:20:43.411577	cam1	Kura Kura	Session Hazy 330ml	0.9419	1726	05kura_shK	[27,235,80,183]	added
2026-02-28 19:02:22.411577	cam1	Sprite	390ml	0.9233	1727	59spriteK	[93,250,99,201]	added
2025-04-08 02:07:39.411577	cam1	Orang Tua	Atlas Lychee 620ml	0.6767	1728	01ot_atlaslB	[38,165,155,87]	restock
2025-03-31 15:21:23.411577	cam1	Royal Brewhouse	Gold Royale 350ml	0.7378	1729	18rb_grS	[34,177,215,161]	sold
2025-09-11 19:18:10.411577	cam1	Bacardi	Carta Blanca 750ml	0.6784	1730	36bacardi_cbB	[306,260,170,238]	restock
2025-10-27 05:37:38.411577	cam1	Albens	Apple Mango Cider 330ml	0.6866	1731	07albens_amcS	[33,356,183,62]	restock
2025-12-04 03:34:58.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.984	1732	08baliwein_abjmB	[160,134,187,190]	added
2025-12-03 18:37:38.411577	cam1	Wija	Soju 360ml	0.8212	1733	15wijaS	[356,120,152,224]	restock
2025-09-10 23:21:33.411577	cam1	Canard	Witbier 330ml	0.7095	1734	04canard_wK	[93,61,160,77]	sold
2025-03-18 07:31:29.411577	cam1	Chum Churum	Yogurt 360ml	0.8912	1735	12chum_yS	[360,119,95,214]	restock
2025-10-04 13:59:03.411577	cam1	Smirnoff	Vodka 700ml	0.9856	1736	45smirnoffB	[339,215,237,63]	restock
2025-09-02 19:25:18.411577	cam1	Wija	Blueberry 360ml	0.8626	1737	15wija_bS	[362,62,119,36]	added
2025-10-18 05:25:40.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.9851	1738	01ot_amergoldB	[155,114,140,201]	added
2026-01-27 04:09:16.411577	cam1	Bullsit	Vodka 500ml	0.738	1739	16bullsit_vS	[256,148,37,45]	sold
2025-03-14 10:00:05.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.896	1740	10kawa_bcB	[326,17,157,38]	added
2025-05-02 07:05:41.411577	cam1	Cham Joeun	Soju 360ml	0.6816	1741	40chamjS	[258,46,245,131]	restock
2025-04-19 06:48:51.411577	cam1	Kulturale	N. R. K. DIPA 330ml	0.8772	1742	09kulturale_nrkK	[342,83,194,118]	sold
2025-12-04 14:01:18.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.8605	1743	08baliwein_abjmB	[361,345,68,246]	added
2025-10-17 03:49:14.411577	cam1	Sababay	Black Velvet 750ml	0.7531	1744	02sababay_bvB	[288,90,132,176]	sold
2025-07-06 07:18:00.411577	cam1	Chum Churum	Soju 360ml	0.9623	1745	12chumS	[294,117,72,63]	restock
2025-03-18 14:18:11.411577	cam1	Royal Brewhouse	Black Royale 350ml	0.6975	1746	18rb_brS	[298,255,157,134]	sold
2025-12-24 02:10:45.411577	cam1	Bintang	Pilsener 330ml	0.817	1747	06bintangK	[100,87,164,83]	sold
2025-03-18 13:49:47.411577	cam1	Cham Joeun	Lychee 360ml	0.9313	1748	40chamj_lS	[128,162,199,248]	sold
2025-12-16 07:48:30.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.7052	1749	08baliwein_abjmB	[391,250,223,205]	restock
2025-07-30 02:40:09.411577	cam1	New City	1L	0.8787	1750	24newcityB	[292,129,208,202]	sold
2025-04-01 19:33:16.411577	cam1	Gilbey's	Whisky 350ml	0.6545	1751	37gilbeys_wS	[200,239,249,205]	sold
2025-12-28 07:19:08.411577	cam1	Wija	Lychee 360ml	0.884	1752	15wija_lS	[76,24,80,36]	sold
2025-11-12 23:55:20.411577	cam1	Smirnoff	Vodka 700ml	0.8164	1753	45smirnoffB	[194,308,217,72]	restock
2026-01-11 07:37:36.411577	cam1	Chum Churum	Yogurt 360ml	0.8243	1754	12chum_yS	[399,19,66,102]	restock
2025-04-17 23:59:18.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.8911	1755	10kawa_merahB	[251,201,209,178]	sold
2025-08-16 11:07:17.411577	cam1	Beaches	Cerveza 330ml	0.8201	1756	32beachescK	[61,263,57,35]	sold
2025-10-16 23:30:39.411577	cam1	Kura Kura	Lager 330ml	0.8469	1757	05kura_lK	[344,225,186,205]	added
2025-08-02 00:33:42.411577	cam1	Sababay	Pink Blossom 750ml	0.9896	1758	02sababay_pbB	[102,261,54,217]	added
2025-06-23 09:49:17.411577	cam1	Albens	Apple Mango Cider 330ml	0.8901	1759	07albens_amcS	[75,351,31,143]	added
2025-12-23 22:55:15.411577	cam1	Sababay	Ludisia 750ml	0.9777	1760	02sababay_lB	[349,128,66,127]	restock
2026-01-16 14:06:32.411577	cam1	Orang Tua	Atlas Lychee 620ml	0.9036	1761	01ot_atlaslB	[98,40,147,69]	sold
2025-12-23 21:58:24.411577	cam1	Iceland	Blue Lagoon 275ml	0.7729	1762	03iceland_blS	[65,300,140,115]	sold
2025-12-03 02:24:31.411577	cam1	Iceland	Lychee Martini 275ml	0.7219	1763	03iceland_lmS	[349,79,69,38]	added
2025-05-03 17:01:42.411577	cam1	Royal Brewhouse	Gold Royale 350ml	0.6966	1764	18rb_grS	[61,284,117,174]	restock
2025-05-20 18:43:15.411577	cam1	Bintang	Pilsener 500ml	0.8217	1765	06bintangBC	[348,318,208,162]	restock
2026-01-25 11:30:33.411577	cam1	Canard	Weizenbock 330ml	0.9694	1766	04canard_weK	[107,138,53,125]	sold
2026-02-18 22:39:22.411577	cam1	Iceland	Orange 700ml	0.7233	1767	03iceland_oB	[197,257,249,238]	restock
2025-10-14 09:22:43.411577	cam1	Wija	Lychee 360ml	0.9743	1768	15wija_lS	[69,200,178,214]	added
2026-02-07 16:21:42.411577	cam1	Sababay	Black Velvet 750ml	0.8918	1769	02sababay_bvB	[278,288,160,182]	restock
2025-09-24 09:29:07.411577	cam1	Bullsit	Whisky 500ml	0.8823	1770	16bullsit_wS	[105,42,51,211]	added
2025-08-27 11:56:33.411577	cam1	Chum Churum	Peach 360ml	0.8608	1771	12chum_pS	[255,292,231,208]	added
2025-04-15 21:42:42.411577	cam1	Extra Joss	Ultimate 250ml	0.678	1772	53extrajK	[250,225,153,122]	restock
2025-12-15 12:48:59.411577	cam1	Batavia	Whisky 700ml	0.7053	1773	21bataviaB	[84,14,105,245]	sold
2026-02-12 20:48:52.411577	cam1	Gilbey's	Gin 350ml	0.8955	1774	37gilbeys_gS	[71,251,163,167]	sold
2025-07-09 21:13:51.411577	cam1	Baliwein	Anggur Salak 750ml	0.8726	1775	08baliwein_absB	[336,154,152,95]	added
2026-01-07 14:23:09.411577	cam1	Santai	Lemon & Lime 330ml	0.7327	1776	14santai_llK	[336,290,116,149]	added
2025-11-26 06:46:15.411577	cam1	Canard	Weizenbock 330ml	0.9728	1777	04canard_weK	[51,46,176,42]	added
2025-11-18 05:25:24.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.6986	1778	19rajawali_prostalK	[341,57,130,192]	sold
2026-02-06 13:37:49.411577	cam1	Kura Kura	Lager 330ml	0.8461	1779	05kura_lK	[104,52,249,101]	added
2025-04-19 06:55:00.411577	cam1	Orang Tua	Atlas Lychee 620ml	0.6925	1780	01ot_atlaslB	[80,75,97,242]	sold
2025-08-24 15:03:56.411577	cam1	Santai	Lemon & Lime 330ml	0.7331	1781	14santai_llK	[389,270,54,219]	sold
2025-09-25 17:08:35.411577	cam1	Orang Tua	Anggur Merah 275ml	0.9116	1782	01ot_amerS	[85,154,187,224]	restock
2025-07-07 19:01:21.411577	cam1	Baliwein	Semara 750ml	0.8788	1783	08baliwein_semB	[363,96,241,175]	added
2025-05-19 05:09:38.411577	cam1	Royal Brewhouse	Gold Royale 350ml	0.6891	1784	18rb_grS	[32,86,31,232]	sold
2025-05-16 23:14:15.411577	cam1	Canard	Kolsch 330ml	0.8559	1785	04canard_kK	[342,118,217,80]	restock
2025-07-12 05:46:42.411577	cam1	Three Peaks	Dry Gin 700ml	0.8587	1786	33threep_dgB	[303,394,130,170]	sold
2025-12-03 06:04:30.411577	cam1	Extra Joss	Ultimate 250ml	0.9663	1787	53extrajK	[238,383,219,193]	added
2025-10-31 06:28:02.411577	cam1	Albens	Apple Cier 330ml	0.9743	1788	07albensS	[338,150,197,212]	restock
2025-07-15 02:25:13.411577	cam1	Bacardi	Spiced Rum 750ml	0.989	1789	36bacardi_srB	[373,128,239,207]	sold
2025-10-27 18:57:32.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.7869	1790	01ot_apiptB	[28,167,200,179]	sold
2026-01-07 14:21:24.411577	cam1	Captain Morgan	Silver Rum 750ml	0.9787	1791	35cm_ssB	[181,71,142,91]	added
2026-02-19 17:24:06.411577	cam1	Kulturale	L. L. Stout 330ml	0.9236	1792	09kulturale_llsK	[109,288,72,67]	added
2025-07-26 22:14:54.411577	cam1	Canard	Weizenbock 330ml	0.7008	1793	04canard_weK	[239,50,190,218]	restock
2025-10-07 01:47:39.411577	cam1	Canard	Weizenbock 330ml	0.9165	1794	04canard_weK	[162,393,103,212]	sold
2025-09-11 12:17:47.411577	cam1	Orang Tua	Anggur Putih 620ml	0.7061	1795	01ot_aputB	[251,212,80,108]	added
2025-03-17 02:13:40.411577	cam1	Iceland	Lychee Martini 275ml	0.9302	1796	03iceland_lmS	[21,312,78,114]	added
2025-12-30 19:47:03.411577	cam1	New City	1L	0.7172	1797	24newcityB	[384,190,86,239]	sold
2025-12-02 18:35:51.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.6604	1798	10kawa_merahB	[351,333,158,150]	sold
2025-05-18 18:02:12.411577	cam1	Iceland	Orange 700ml	0.754	1799	03iceland_oB	[349,121,123,216]	added
2025-08-24 13:45:41.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.9178	1800	08baliwein_abjmB	[238,152,61,154]	sold
2025-08-26 01:43:21.411577	cam1	Kulturale	Bravo 330ml	0.7438	1801	09kulturale_bK	[56,391,121,56]	sold
2025-09-11 21:52:16.411577	cam1	Beaches	Cerveza 330ml	0.8705	1802	32beachescK	[110,385,203,34]	added
2025-05-03 21:26:54.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.7507	1803	10kawa_bcB	[28,370,81,224]	sold
2025-04-17 16:11:34.411577	cam1	Baliwein	Sekala 750ml	0.8902	1804	08baliwein_sekB	[338,63,92,248]	sold
2025-06-07 12:06:21.411577	cam1	Iceland	Berry Lemonade 275ml	0.8843	1805	03iceland_beleS	[371,118,190,116]	sold
2025-08-13 16:36:11.411577	cam1	Guiness	Draught Stout 500ml	0.8893	1806	34guiness_dsBC	[218,71,187,187]	sold
2025-11-24 03:38:02.411577	cam1	Baliwein	Semara 750ml	0.8338	1807	08baliwein_semB	[311,123,76,241]	added
2026-02-16 11:24:46.411577	cam1	Drum	Whisky Black 700ml	0.7282	1808	22drum_wbB	[143,216,236,147]	added
2026-01-30 12:42:10.411577	cam1	Baileys	Irish Cream 750ml	0.7526	1809	51baileys_icB	[21,231,205,71]	restock
2025-06-14 20:42:17.411577	cam1	Kulturale	Amarillo 330ml	0.8049	1810	09kulturale_aK	[147,376,97,128]	sold
2025-07-18 05:08:29.411577	cam1	Orang Tua	Atlas Lychee 620ml	0.7424	1811	01ot_atlaslB	[127,145,96,178]	sold
2025-03-30 14:35:13.411577	cam1	Jameson	Irish Whiskey 700ml	0.8021	1812	41jamesonB	[130,187,243,238]	sold
2026-03-11 02:04:50.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.9068	1813	10kawa_hijauB	[241,155,52,102]	added
2025-12-04 08:03:49.411577	cam1	Polaris	Soda Water 330ml	0.7963	1814	54polarisK	[28,399,106,62]	sold
2025-11-22 19:05:46.411577	cam1	Kulturale	Bravo 330ml	0.927	1815	09kulturale_bK	[49,197,80,151]	added
2025-08-18 15:53:53.411577	cam1	Canard	Porter 330ml	0.7135	1816	04canard_pK	[271,354,222,233]	restock
2025-05-30 11:36:42.411577	cam1	Baileys	Irish Cream 750ml	0.9632	1817	51baileys_icB	[82,134,244,156]	added
2026-01-23 13:16:07.411577	cam1	Polaris	Soda Water 330ml	0.8798	1818	54polarisK	[177,177,222,77]	sold
2026-01-11 13:01:14.411577	cam1	Baliwein	Semara 750ml	0.7978	1819	08baliwein_semB	[56,40,74,102]	added
2025-07-17 07:27:35.411577	cam1	Extra Joss	Ultimate 250ml	0.8924	1820	53extrajK	[255,102,93,230]	restock
2025-09-19 10:05:45.411577	cam1	Sapporo	330ml	0.8982	1821	49sapporoK	[280,357,187,81]	sold
2025-07-03 11:27:43.411577	cam1	Heineken	330ml	0.9851	1822	46heinekenS	[139,189,137,31]	added
2025-06-11 00:05:06.411577	cam1	Santai	Passionfruit & Guava 330ml	0.7138	1823	14santai_pgK	[183,148,230,148]	added
2026-01-18 03:35:30.411577	cam1	Cham Joeun	Lychee 360ml	0.8008	1824	40chamj_lS	[146,160,42,192]	restock
2025-12-12 14:09:02.411577	cam1	Kulturale	N. R. K. DIPA 330ml	0.9248	1825	09kulturale_nrkK	[129,302,100,229]	added
2025-11-27 23:26:26.411577	cam1	Baliwein	Anggur Salak 750ml	0.8739	1826	08baliwein_absB	[298,26,39,106]	added
2026-01-09 21:33:25.411577	cam1	Rajawali	Prost 620ml	0.7376	1827	19rajawali_prostB	[213,177,101,130]	added
2025-11-12 03:28:01.411577	cam1	Orang Tua	Anggur Putih 620ml	0.8528	1828	01ot_aputB	[281,232,175,64]	sold
2025-10-06 20:20:59.411577	cam1	Orang Tua	Atlas Lychee 620ml	0.8079	1829	01ot_atlaslB	[289,160,239,175]	sold
2025-08-02 10:49:57.411577	cam1	Orang Tua	Anggur Merah 275ml	0.7282	1830	01ot_amerS	[206,186,238,194]	added
2025-03-28 22:05:08.411577	cam1	Kura Kura	Island Ale 330ml	0.7976	1831	05kura_iaK	[156,334,181,118]	restock
2025-11-22 22:06:10.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.7841	1832	10kawa_bcB	[83,366,197,198]	sold
2025-12-31 10:17:32.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.6863	1833	08baliwein_abjmB	[126,136,65,42]	sold
2025-11-21 22:34:51.411577	cam1	Smirnoff	Vodka 700ml	0.9265	1834	45smirnoffB	[255,320,45,201]	sold
2025-09-05 20:09:15.411577	cam1	Santai	Passionfruit & Guava 330ml	0.9711	1835	14santai_pgK	[302,182,38,116]	added
2025-12-25 13:42:47.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.9851	1836	10kawa_hijauB	[56,391,97,210]	sold
2025-04-15 22:09:30.411577	cam1	Bintang	Pilsener 500ml	0.8372	1837	06bintangBC	[232,327,140,155]	restock
2026-01-28 13:29:52.411577	cam1	Kulturale	N. R. K. DIPA 330ml	0.8688	1838	09kulturale_nrkK	[72,34,94,111]	sold
2025-12-11 23:31:46.411577	cam1	Orang Tua	Intisari Anggur Hijau 620ml	0.7809	1839	01ot_hijauintB	[208,222,112,189]	sold
2025-08-28 02:24:07.411577	cam1	Kura Kura	Session Hazy 330ml	0.8695	1840	05kura_shK	[317,62,219,53]	added
2025-07-17 13:12:29.411577	cam1	New City	1L	0.7626	1841	24newcityB	[396,187,127,106]	restock
2025-08-27 22:55:39.411577	cam1	Sababay	Ludisia 750ml	0.8927	1842	02sababay_lB	[334,305,52,205]	restock
2025-12-09 22:47:34.411577	cam1	Kura Kura	Lager 330ml	0.8117	1843	05kura_lK	[349,127,152,79]	added
2026-02-19 11:38:46.411577	cam1	New City	1L	0.7529	1844	24newcityB	[248,15,173,212]	restock
2026-02-10 15:26:52.411577	cam1	Cham Joeun	Lychee 360ml	0.6801	1845	40chamj_lS	[201,151,82,242]	added
2025-09-25 08:03:43.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.9229	1846	01ot_atlasrpB	[70,167,178,237]	added
2026-01-03 04:00:12.411577	cam1	Chum Churum	Peach 360ml	0.8942	1847	12chum_pS	[370,181,40,143]	restock
2025-12-20 13:49:20.411577	cam1	Orang Tua	Anggur Merah 620ml	0.7295	1848	01ot_amerB	[170,53,143,218]	added
2025-05-08 06:27:59.411577	cam1	Jameson	Irish Whiskey 700ml	0.8863	1849	41jamesonB	[323,80,147,144]	sold
2026-01-16 23:11:16.411577	cam1	Bullsit	Vodka 500ml	0.7157	1850	16bullsit_vS	[156,148,172,80]	restock
2025-07-10 02:03:43.411577	cam1	Vibe	Exotic Lychee 700ml	0.6996	1851	11vibe_elB	[298,84,110,67]	added
2025-05-22 05:09:27.411577	cam1	Sapporo	330ml	0.911	1852	49sapporoK	[331,142,167,137]	sold
2026-02-06 02:03:42.411577	cam1	Sababay	Ludisia 750ml	0.7781	1853	02sababay_lB	[159,318,203,174]	sold
2025-05-18 10:17:03.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.6676	1854	10kawa_bcB	[225,199,193,184]	added
2025-10-08 02:27:29.411577	cam1	Rajawali	Prost 620ml	0.7232	1855	19rajawali_prostB	[25,235,41,42]	added
2025-10-16 05:47:17.411577	cam1	Suntory Roku	Gin 700ml	0.8524	1856	43rokuB	[219,128,249,180]	sold
2025-09-28 18:28:12.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.9196	1857	23palapaB	[337,381,36,39]	restock
2025-06-09 17:38:17.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.9713	1858	19rajawali_prostalK	[310,275,214,207]	added
2025-07-26 01:04:37.411577	cam1	Cham Joeun	Soju 360ml	0.657	1859	40chamjS	[310,386,120,48]	restock
2025-08-26 07:17:46.411577	cam1	Sababay	Mascetti 750ml	0.8671	1860	02sababay_masB	[285,153,75,138]	added
2025-04-24 08:21:28.411577	cam1	Sababay	Ludisia 750ml	0.8141	1861	02sababay_lB	[279,187,143,85]	restock
2025-11-22 00:05:52.411577	cam1	Rajawali	Prost 620ml	0.8111	1862	19rajawali_prostB	[197,69,75,246]	added
2025-07-06 15:04:25.411577	cam1	Baliwein	Anggur Salak 750ml	0.8137	1863	08baliwein_absB	[316,369,152,183]	restock
2025-09-26 18:54:18.411577	cam1	Wija	Lychee 360ml	0.6579	1864	15wija_lS	[209,96,96,213]	sold
2025-05-03 14:17:25.411577	cam1	Orang Tua	Intisari Anggur Hijau 620ml	0.8944	1865	01ot_hijauintB	[349,353,233,187]	restock
2025-11-02 05:54:35.411577	cam1	Kura Kura	IPA 330ml	0.7232	1866	05kura_ipaK	[63,75,140,148]	sold
2025-06-11 02:59:53.411577	cam1	Vibe	Exotic Lychee 700ml	0.8853	1867	11vibe_elB	[355,112,222,229]	sold
2026-03-01 11:01:45.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.9547	1868	01ot_apihjB	[120,60,199,45]	added
2025-07-14 02:52:32.411577	cam1	Smirnoff	Vodka 700ml	0.8556	1869	45smirnoffB	[394,338,158,36]	added
2025-08-23 19:12:24.411577	cam1	Kura Kura	Session Hazy 330ml	0.87	1870	05kura_shK	[109,322,226,125]	added
2026-02-11 08:45:13.411577	cam1	Corona	Extra 355ml	0.7753	1871	47corona_eS	[79,355,151,160]	sold
2025-11-20 13:56:28.411577	cam1	Sababay	Pink Blossom 750ml	0.8164	1872	02sababay_pbB	[385,139,235,151]	sold
2025-11-06 08:13:25.411577	cam1	Kulturale	L. L. Stout 330ml	0.8396	1873	09kulturale_llsK	[314,374,218,152]	added
2025-06-11 22:19:13.411577	cam1	Baliwein	Anggur Salak 750ml	0.7598	1874	08baliwein_absB	[163,224,238,61]	added
2025-10-20 13:12:00.411577	cam1	Kura Kura	IPA 330ml	0.7207	1875	05kura_ipaK	[198,160,78,211]	added
2025-05-20 09:11:39.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.7186	1876	10kawa_bcB	[15,172,156,70]	restock
2025-09-11 17:22:23.411577	cam1	Gilbey's	Gin 350ml	0.7204	1877	37gilbeys_gS	[290,289,154,192]	added
2025-07-04 21:46:19.411577	cam1	Canard	Strawberry Gose 330ml	0.8855	1878	04canard_sgK	[227,207,72,125]	added
2025-06-13 00:32:45.411577	cam1	Bullsit	Whisky 500ml	0.7845	1879	16bullsit_wS	[195,107,210,140]	added
2025-06-26 16:52:28.411577	cam1	Sababay	Mascetti 750ml	0.9803	1880	02sababay_masB	[195,337,238,84]	sold
2025-03-21 04:42:41.411577	cam1	Chum Churum	Peach 360ml	0.8416	1881	12chum_pS	[271,171,36,215]	sold
2025-04-26 01:51:58.411577	cam1	Orang Tua	Arak Obat 620ml	0.7874	1882	01ot_aoB	[389,237,175,190]	added
2025-05-08 03:20:24.411577	cam1	Orang Tua	Intisari Anggur Hijau 620ml	0.6565	1883	01ot_hijauintB	[316,270,39,208]	added
2025-04-03 09:17:44.411577	cam1	Bacardi	Carta Blanca 750ml	0.9058	1884	36bacardi_cbB	[248,176,144,202]	sold
2026-01-11 20:51:08.411577	cam1	Royal Brewhouse	Black Royale 350ml	0.7986	1885	18rb_brS	[389,385,138,98]	restock
2025-03-15 21:35:12.411577	cam1	Beaches	Cerveza 330ml	0.8344	1886	32beachescK	[317,251,227,202]	sold
2025-10-04 04:10:33.411577	cam1	Bacardi	Spiced Rum 750ml	0.9894	1887	36bacardi_srB	[194,78,89,142]	sold
2025-11-15 13:35:04.411577	cam1	New City	1L	0.9365	1888	24newcityB	[353,373,190,210]	added
2025-04-25 13:01:19.411577	cam1	Gilbey's	Gin 350ml	0.7723	1889	37gilbeys_gS	[62,374,65,210]	added
2026-01-04 07:34:04.411577	cam1	Sprite	390ml	0.8186	1890	59spriteK	[180,102,208,171]	added
2025-12-04 10:22:07.411577	cam1	Kura Kura	IPA 330ml	0.8485	1891	05kura_ipaK	[305,265,239,121]	added
2025-11-27 06:32:50.411577	cam1	Jagermeister	700ml	0.6739	1892	42jagermeisterB	[218,259,187,244]	added
2025-11-01 06:40:58.411577	cam1	Orang Tua	Anggur Merah 275ml	0.8405	1893	01ot_amerS	[23,86,60,234]	sold
2025-09-26 16:34:15.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.8765	1894	10kawa_bcB	[51,234,193,60]	added
2026-01-19 17:47:55.411577	cam1	Canard	Session IPA 330ml	0.7532	1895	04canard_siK	[112,101,65,122]	sold
2025-05-22 11:01:26.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.7493	1896	08baliwein_abjmB	[360,334,73,192]	added
2025-12-22 22:53:31.411577	cam1	Cham Joeun	Soju 360ml	0.7016	1897	40chamjS	[345,324,44,34]	restock
2025-03-21 00:00:12.411577	cam1	Pokka	Green Tea 300ml	0.8083	1898	57pokkaK	[21,393,244,245]	added
2025-12-13 19:30:20.411577	cam1	Rajawali	Prost 620ml	0.9538	1899	19rajawali_prostB	[314,317,96,200]	sold
2025-05-08 02:30:46.411577	cam1	Kulturale	Bravo 330ml	0.6947	1900	09kulturale_bK	[48,72,160,62]	sold
2025-09-15 02:46:41.411577	cam1	Yakult	1 pack 325ml	0.7473	1901	60yakultK	[246,130,229,154]	sold
2025-04-21 00:13:45.411577	cam1	Yakult	1 pack 325ml	0.9369	1902	60yakultK	[114,41,54,179]	added
2025-11-06 11:23:01.411577	cam1	Smirnoff	Vodka 700ml	0.7992	1903	45smirnoffB	[46,86,228,142]	added
2025-12-15 01:08:17.411577	cam1	Orang Tua	Anggur Putih 620ml	0.7988	1904	01ot_aputB	[393,342,149,49]	restock
2025-09-22 01:51:40.411577	cam1	Canard	Kolsch 330ml	0.6948	1905	04canard_kK	[181,283,190,158]	sold
2026-02-25 22:21:58.411577	cam1	Orang Tua	Anggur Merah 620ml	0.9877	1906	01ot_amerB	[87,254,178,78]	restock
2025-08-19 18:00:45.411577	cam1	Canard	Strawberry Gose 330ml	0.9161	1907	04canard_sgK	[267,83,170,221]	restock
2026-01-02 06:41:07.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.9358	1908	14santai_agaK	[397,178,161,233]	added
2025-04-01 20:01:34.411577	cam1	Bintang	Pilsener 620ml	0.6994	1909	06bintangB	[234,380,241,173]	added
2026-03-03 04:12:48.411577	cam1	Guiness	Foreign Extra Stout 320ml	0.9607	1910	34guinessK_fesKC	[111,374,55,37]	sold
2026-01-28 02:57:39.411577	cam1	Canard	Porter 330ml	0.8226	1911	04canard_pK	[236,128,234,43]	added
2025-03-31 09:58:20.411577	cam1	Canard	Porter 330ml	0.9108	1912	04canard_pK	[83,219,81,60]	sold
2025-05-05 00:06:06.411577	cam1	Bacardi	Carta Blanca 750ml	0.8574	1913	36bacardi_cbB	[55,71,146,150]	sold
2025-08-05 15:36:50.411577	cam1	Kura Kura	IPA 330ml	0.8504	1914	05kura_ipaK	[378,263,152,98]	added
2025-04-08 05:59:24.411577	cam1	Sababay	Black Velvet 750ml	0.6943	1915	02sababay_bvB	[310,336,38,235]	sold
2025-03-15 17:42:42.411577	cam1	Sapporo	330ml	0.6848	1916	49sapporoK	[391,160,218,212]	restock
2025-03-21 15:47:01.411577	cam1	Bullsit	Gin 500ml	0.9369	1917	16bullsit_gS	[164,54,241,234]	restock
2025-03-29 15:04:14.411577	cam1	Bacardi	Spiced Rum 750ml	0.8131	1918	36bacardi_srB	[298,315,159,126]	sold
2026-02-28 00:56:30.411577	cam1	Beaches	Cerveza 330ml	0.9751	1919	32beachescK	[172,358,177,192]	sold
2026-03-04 22:40:27.411577	cam1	Kura Kura	Island Ale 330ml	0.9055	1920	05kura_iaK	[307,205,46,85]	added
2025-09-05 13:13:48.411577	cam1	Bintang	Radler 330ml	0.7036	1921	06bintang_radlerS	[310,92,222,87]	restock
2025-06-24 22:11:18.411577	cam1	Orang Tua	Intisari Blackcurrant 620ml	0.9007	1922	01ot_bcintB	[335,315,33,44]	added
2025-07-30 04:28:34.411577	cam1	Suntory Roku	Gin 700ml	0.902	1923	43rokuB	[109,277,100,250]	added
2025-10-24 03:16:52.411577	cam1	Kura Kura	Lager 330ml	0.7499	1924	05kura_lK	[341,75,247,186]	added
2025-07-31 12:50:47.411577	cam1	Wija	Lychee 360ml	0.88	1925	15wija_lS	[339,40,69,110]	restock
2025-08-05 05:56:45.411577	cam1	Bintang	Pilsener 620ml	0.8824	1926	06bintangB	[353,271,174,217]	added
2025-08-03 08:02:30.411577	cam1	Kura Kura	Session Hazy 330ml	0.7021	1927	05kura_shK	[72,328,58,171]	sold
2025-05-01 08:37:17.411577	cam1	Wija	Lychee 360ml	0.9557	1928	15wija_lS	[78,237,185,162]	sold
2026-01-14 08:28:36.411577	cam1	New City	1L	0.8704	1929	24newcityB	[174,272,106,39]	restock
2025-11-23 00:25:45.411577	cam1	Bullsit	Whisky 500ml	0.8491	1930	16bullsit_wS	[273,285,73,109]	added
2025-08-04 02:41:41.411577	cam1	Bintang	Pilsener 620ml	0.7672	1931	06bintangB	[38,300,207,202]	sold
2025-07-06 00:55:09.411577	cam1	Pu Tao Chee Chiew	330ml	0.9617	1932	31putaoccS	[192,325,86,41]	restock
2025-07-04 18:45:13.411577	cam1	Suntory Roku	Gin 700ml	0.9753	1933	43rokuB	[218,287,50,217]	added
2025-08-19 05:39:25.411577	cam1	Bullsit	Gin 500ml	0.6921	1934	16bullsit_gS	[324,19,203,82]	sold
2025-12-08 21:41:28.411577	cam1	Guiness	Foreign Extra Stout 620ml	0.8666	1935	34guiness_fesB	[113,35,129,158]	added
2025-07-23 02:06:39.411577	cam1	Orang Tua	Anggur Merah 275ml	0.8347	1936	01ot_amerS	[151,102,89,61]	sold
2025-12-06 19:54:23.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.811	1937	14santai_agaK	[388,320,200,215]	sold
2025-06-26 08:07:50.411577	cam1	Cham Joeun	Lychee 360ml	0.6785	1938	40chamj_lS	[47,138,205,59]	sold
2025-08-09 19:02:16.411577	cam1	Canard	Witbier 330ml	0.6995	1939	04canard_wK	[264,316,168,68]	added
2025-11-07 03:31:06.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.8386	1940	01ot_apihjB	[368,19,163,205]	sold
2025-12-14 00:25:15.411577	cam1	Wija	Lychee 360ml	0.9166	1941	15wija_lS	[24,384,57,48]	restock
2026-01-23 05:42:02.411577	cam1	Vibe	Black Tea 700ml	0.8989	1942	11vibe_btB	[292,173,177,116]	sold
2025-06-13 01:14:03.411577	cam1	Bullsit	Vodka 500ml	0.7567	1943	16bullsit_vS	[38,298,157,192]	sold
2025-09-17 13:44:57.411577	cam1	Kura Kura	IPA 330ml	0.7721	1944	05kura_ipaK	[223,80,51,159]	sold
2025-11-26 02:41:09.411577	cam1	Canard	Session IPA 330ml	0.7169	1945	04canard_siK	[333,347,161,59]	added
2025-03-14 17:47:36.411577	cam1	Crystalline	330ml	0.7636	1946	55crystalinK	[230,118,229,111]	restock
2025-08-06 02:46:08.411577	cam1	Sababay	Black Velvet 750ml	0.7446	1947	02sababay_bvB	[119,118,58,60]	added
2026-01-03 01:40:54.411577	cam1	New City	1L	0.7811	1948	24newcityB	[84,14,106,96]	sold
2025-11-27 10:14:12.411577	cam1	Canard	Strawberry Gose 330ml	0.904	1949	04canard_sgK	[92,199,155,71]	sold
2025-05-18 03:47:54.411577	cam1	Kulturale	Amarillo 330ml	0.7588	1950	09kulturale_aK	[30,272,127,112]	restock
2025-06-24 01:09:17.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.7612	1951	10kawa_merahB	[63,105,173,64]	added
2025-09-12 18:21:40.411577	cam1	Jameson	Irish Whiskey 700ml	0.7353	1952	41jamesonB	[93,148,32,129]	restock
2026-02-22 15:05:40.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.9386	1953	10kawa_bcB	[63,302,232,66]	added
2025-06-25 12:27:56.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.8132	1954	01ot_amergoldB	[63,202,34,235]	added
2025-08-07 14:24:52.411577	cam1	Polaris	Soda Water 330ml	0.7702	1955	54polarisK	[381,45,80,54]	sold
2025-04-14 18:48:54.411577	cam1	Iceland	Lychee Martini 275ml	0.8513	1956	03iceland_lmS	[49,298,97,244]	restock
2025-08-15 19:43:20.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.8943	1957	14santai_agaK	[20,130,126,140]	sold
2026-01-23 16:32:01.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.7246	1958	01ot_apiptB	[11,250,196,109]	sold
2025-09-05 15:20:12.411577	cam1	Beaches	Cerveza 330ml	0.9494	1959	32beachescK	[165,213,177,181]	sold
2025-06-28 08:16:00.411577	cam1	Chum Churum	Peach 360ml	0.803	1960	12chum_pS	[382,83,180,59]	sold
2025-07-25 01:55:54.411577	cam1	Cham Joeun	Soju 360ml	0.7841	1961	40chamjS	[172,333,154,154]	sold
2025-11-14 19:52:40.411577	cam1	Iceland	Berry Lemonade 275ml	0.6793	1962	03iceland_beleS	[338,201,148,78]	sold
2026-02-27 01:10:24.411577	cam1	Bullsit	Whisky 500ml	0.9211	1963	16bullsit_wS	[28,311,121,98]	restock
2026-01-28 05:54:02.411577	cam1	Iceland	Original 250ml	0.8688	1964	03icelandK	[392,69,150,94]	added
2025-07-07 07:39:33.411577	cam1	Iceland	Berry Lemonade 275ml	0.7653	1965	03iceland_beleS	[385,261,250,176]	sold
2025-07-25 08:39:26.411577	cam1	Sababay	Mascetti 750ml	0.8663	1966	02sababay_masB	[325,331,232,64]	added
2026-03-09 19:05:55.411577	cam1	Jameson	Irish Whiskey 700ml	0.7531	1967	41jamesonB	[94,46,37,85]	restock
2025-04-20 09:39:56.411577	cam1	Bintang	Radler 330ml	0.722	1968	06bintang_radlerS	[144,88,127,192]	restock
2026-01-16 17:00:06.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.8254	1969	14santai_agaK	[229,127,124,166]	sold
2026-02-19 17:51:56.411577	cam1	Bintang	Pilsener 500ml	0.9617	1970	06bintangBC	[251,75,172,200]	added
2025-11-16 14:38:29.411577	cam1	Baliwein	Sekala 750ml	0.6795	1971	08baliwein_sekB	[185,391,76,51]	restock
2025-12-06 04:47:55.411577	cam1	Sapporo	330ml	0.8195	1972	49sapporoK	[76,12,93,158]	restock
2026-02-18 09:16:58.411577	cam1	Crystalline	330ml	0.9425	1973	55crystalinK	[112,83,128,180]	sold
2025-03-20 09:47:08.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.8035	1974	01ot_atlasrpB	[376,284,30,181]	restock
2025-12-11 11:24:32.411577	cam1	Chum Churum	Yogurt 360ml	0.9449	1975	12chum_yS	[228,225,118,206]	added
2025-03-18 23:57:43.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.7836	1976	19rajawali_prostalK	[115,122,143,44]	added
2025-11-19 02:17:45.411577	cam1	Cham Joeun	Lychee 360ml	0.8341	1977	40chamj_lS	[284,103,36,202]	sold
2025-06-21 02:23:09.411577	cam1	Baliwein	Sekala 750ml	0.9351	1978	08baliwein_sekB	[334,391,219,152]	added
2026-01-01 08:22:07.411577	cam1	Sababay	Ludisia 750ml	0.7672	1979	02sababay_lB	[96,140,152,183]	sold
2025-09-18 03:25:16.411577	cam1	Kulturale	Bravo 330ml	0.9643	1980	09kulturale_bK	[314,93,230,142]	restock
2025-09-10 19:02:18.411577	cam1	Smirnoff	Vodka 700ml	0.9856	1981	45smirnoffB	[334,111,157,43]	restock
2026-03-01 10:39:48.411577	cam1	Canard	Kolsch 330ml	0.9621	1982	04canard_kK	[136,58,217,145]	restock
2025-10-10 05:32:37.411577	cam1	Guiness	Foreign Extra Stout 320ml	0.9301	1983	34guinessK_fesKC	[388,300,224,199]	restock
2025-08-24 05:36:39.411577	cam1	Bullsit	Gin 500ml	0.7836	1984	16bullsit_gS	[69,217,100,129]	sold
2026-02-02 22:47:47.411577	cam1	Gordon's	PinkPremium 750ml	0.8845	1985	44gordon_ppB	[168,178,186,49]	sold
2025-07-24 08:58:43.411577	cam1	Wija	Lychee 360ml	0.8813	1986	15wija_lS	[337,144,163,34]	sold
2025-10-26 19:41:28.411577	cam1	Orang Tua	Atlas Lychee 620ml	0.8006	1987	01ot_atlaslB	[41,120,173,59]	added
2025-07-02 08:44:59.411577	cam1	Canard	Porter 330ml	0.6569	1988	04canard_pK	[322,347,69,224]	added
2025-08-17 17:31:36.411577	cam1	Orang Tua	Anggur Putih 620ml	0.6586	1989	01ot_aputB	[28,253,193,61]	added
2025-04-21 10:06:29.411577	cam1	Kulturale	Amarillo 330ml	0.9583	1990	09kulturale_aK	[56,336,143,215]	sold
2025-06-18 14:19:11.411577	cam1	Iceland	Berry Lemonade 275ml	0.7928	1991	03iceland_beleS	[142,124,226,111]	sold
2025-07-04 05:30:10.411577	cam1	Jose Cuervo	750ml	0.9478	1992	50josecuervoB	[394,397,178,35]	sold
2025-08-02 10:18:50.411577	cam1	Rajawali	Prost 620ml	0.8446	1993	19rajawali_prostB	[376,220,169,236]	added
2025-08-09 18:59:52.411577	cam1	Iceland	Berry Lemonade 275ml	0.8132	1994	03iceland_beleS	[229,231,189,116]	restock
2025-07-03 02:29:07.411577	cam1	Jameson	Irish Whiskey 700ml	0.7479	1995	41jamesonB	[168,262,216,235]	added
2025-06-28 19:28:05.411577	cam1	Orang Tua	Atlas Lychee 620ml	0.7182	1996	01ot_atlaslB	[252,100,229,67]	added
2025-11-17 21:52:03.411577	cam1	Chum Churum	Yogurt 360ml	0.8804	1997	12chum_yS	[12,271,139,127]	sold
2025-05-20 10:29:13.411577	cam1	Santai	Passionfruit & Guava 330ml	0.8036	1998	14santai_pgK	[300,98,153,93]	added
2025-08-10 09:22:26.411577	cam1	Crystalline	330ml	0.917	1999	55crystalinK	[127,285,248,172]	sold
2025-06-20 09:13:10.411577	cam1	Yakult	1 pack 325ml	0.9695	2000	60yakultK	[159,95,71,176]	added
2025-06-26 20:38:21.411577	cam1	Bintang	Pilsener 620ml	0.941	2001	06bintangB	[205,78,178,241]	added
2025-03-13 01:57:35.411577	cam1	Pu Tao Chee Chiew	330ml	0.8842	2002	31putaoccS	[363,238,223,200]	added
2025-09-10 20:58:59.411577	cam1	Batavia	Whisky 700ml	0.9437	2003	21bataviaB	[15,121,50,122]	sold
2025-06-19 11:31:45.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.7906	2004	10kawa_merahB	[106,279,170,71]	sold
2025-10-11 18:31:43.411577	cam1	Wija	Lychee 360ml	0.7566	2005	15wija_lS	[173,224,248,56]	added
2026-03-03 16:17:56.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.7493	2006	01ot_apihjB	[40,74,83,45]	added
2025-10-31 06:35:25.411577	cam1	Wija	Lychee 360ml	0.6681	2007	15wija_lS	[174,266,204,165]	restock
2025-06-21 13:42:48.411577	cam1	Yakult	1 pack 325ml	0.7573	2008	60yakultK	[206,45,171,150]	added
2025-08-21 10:18:30.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.7563	2009	10kawa_hijauB	[386,302,154,214]	added
2026-01-23 05:34:50.411577	cam1	Baliwein	Anggur Salak 750ml	0.7264	2010	08baliwein_absB	[294,191,81,184]	added
2025-04-28 12:18:36.411577	cam1	Royal Brewhouse	Black Royale 350ml	0.9699	2011	18rb_brS	[20,216,80,45]	added
2025-10-21 06:02:19.411577	cam1	Cham Joeun	Lychee 360ml	0.9471	2012	40chamj_lS	[141,221,112,156]	sold
2025-07-15 10:18:34.411577	cam1	Jameson	Irish Whiskey 700ml	0.7944	2013	41jamesonB	[332,218,234,164]	added
2025-08-15 13:02:21.411577	cam1	Orang Tua	Intisari Anggur Hijau 620ml	0.6645	2014	01ot_hijauintB	[313,54,86,98]	sold
2025-05-12 12:32:00.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.7125	2015	10kawa_hijauB	[70,54,160,139]	sold
2025-08-30 05:47:46.411577	cam1	Kulturale	L. L. Stout 330ml	0.9362	2016	09kulturale_llsK	[323,31,104,214]	sold
2025-11-26 03:06:49.411577	cam1	Santai	Lemon & Lime 330ml	0.701	2017	14santai_llK	[276,22,224,240]	sold
2025-03-12 06:50:22.411577	cam1	New City	1L	0.8629	2018	24newcityB	[298,326,189,184]	added
2025-12-20 11:12:52.411577	cam1	Polaris	Soda Water 330ml	0.8691	2019	54polarisK	[110,313,148,219]	sold
2025-12-24 09:29:21.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.7375	2020	01ot_amergoldB	[54,35,142,176]	restock
2025-11-03 22:31:48.411577	cam1	Santai	Lemon & Lime 330ml	0.7278	2021	14santai_llK	[176,398,67,215]	added
2025-05-28 04:06:09.411577	cam1	Iceland	Orange 700ml	0.7133	2022	03iceland_oB	[124,219,102,212]	sold
2025-04-24 22:24:21.411577	cam1	Orang Tua	Anggur Putih 620ml	0.6911	2023	01ot_aputB	[378,260,142,246]	sold
2025-08-24 18:18:44.411577	cam1	Kulturale	N. R. K. DIPA 330ml	0.803	2024	09kulturale_nrkK	[238,305,201,220]	sold
2026-01-06 10:46:33.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.9415	2025	01ot_apiptB	[96,371,224,129]	sold
2025-07-22 15:25:08.411577	cam1	Baliwein	Semara 750ml	0.9589	2026	08baliwein_semB	[206,22,42,181]	sold
2025-07-22 14:02:14.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.6694	2027	14santai_agaK	[346,62,47,198]	restock
2025-10-09 22:24:26.411577	cam1	Three Peaks	Dry Gin 700ml	0.7396	2028	33threep_dgB	[379,330,48,94]	added
2025-11-12 17:36:37.411577	cam1	Kulturale	Bravo 330ml	0.8238	2029	09kulturale_bK	[207,231,103,176]	restock
2025-11-24 16:20:47.411577	cam1	Kura Kura	Island Ale 330ml	0.9366	2030	05kura_iaK	[132,318,175,166]	restock
2025-08-04 20:15:05.411577	cam1	Wija	Soju 360ml	0.6501	2031	15wijaS	[156,179,235,241]	added
2026-02-03 00:03:32.411577	cam1	Gordon's	PinkPremium 750ml	0.6836	2032	44gordon_ppB	[51,328,149,81]	sold
2025-04-02 22:49:29.411577	cam1	Orang Tua	Arak Obat 620ml	0.8423	2033	01ot_aoB	[284,71,33,124]	sold
2025-04-04 00:44:15.411577	cam1	Albens	Apple Cier 330ml	0.9322	2034	07albensS	[34,293,129,42]	sold
2025-03-16 06:47:26.411577	cam1	Kulturale	L. L. Stout 330ml	0.9286	2035	09kulturale_llsK	[114,89,107,31]	sold
2025-06-02 02:13:57.411577	cam1	Bullsit	Gin 500ml	0.7574	2036	16bullsit_gS	[55,26,141,172]	added
2025-11-14 09:40:11.411577	cam1	Baliwein	Anggur Salak 750ml	0.8173	2037	08baliwein_absB	[260,145,124,92]	added
2025-04-05 02:40:42.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.7468	2038	01ot_amergoldB	[45,27,207,85]	added
2025-05-05 21:48:39.411577	cam1	Wija	Blueberry 360ml	0.9307	2039	15wija_bS	[318,78,128,53]	sold
2025-07-17 01:58:24.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.6659	2040	01ot_apihjB	[217,27,38,249]	sold
2025-03-20 20:08:02.411577	cam1	Bintang	Pilsener 330ml	0.7511	2041	06bintangK	[55,99,224,214]	sold
2025-05-03 11:45:01.411577	cam1	Sapporo	330ml	0.7962	2042	49sapporoK	[59,174,119,111]	added
2026-02-28 19:31:03.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.7371	2043	10kawa_hijauB	[389,145,237,170]	sold
2026-02-11 00:19:28.411577	cam1	Albens	Apple Lychee Cider 330ml	0.9463	2044	07albens_alcS	[359,157,153,102]	added
2025-07-08 07:50:42.411577	cam1	Kulturale	Amarillo 330ml	0.8136	2045	09kulturale_aK	[148,342,76,209]	sold
2025-12-10 20:25:54.411577	cam1	Canard	Witbier 330ml	0.757	2046	04canard_wK	[304,282,72,82]	added
2025-04-08 05:34:09.411577	cam1	Sababay	Mascetti 750ml	0.9743	2047	02sababay_masB	[142,263,124,174]	sold
2025-07-17 05:02:38.411577	cam1	Iceland	Blue Lagoon 275ml	0.7745	2048	03iceland_blS	[124,85,33,180]	sold
2025-07-31 01:16:09.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.8166	2049	08baliwein_abjmB	[98,34,210,210]	sold
2026-02-23 23:13:30.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.8067	2050	01ot_atlasrpB	[330,286,189,178]	sold
2026-02-28 01:24:54.411577	cam1	New City	1L	0.7469	2051	24newcityB	[137,159,217,163]	restock
2025-06-07 07:02:25.411577	cam1	Gilbey's	Gin 350ml	0.6583	2052	37gilbeys_gS	[332,14,131,227]	added
2025-05-31 20:55:54.411577	cam1	Kulturale	Amarillo 330ml	0.7678	2053	09kulturale_aK	[177,188,191,53]	added
2025-10-18 03:20:42.411577	cam1	Orang Tua	Arak Obat 620ml	0.8053	2054	01ot_aoB	[388,72,153,102]	added
2025-09-01 02:40:36.411577	cam1	Chum Churum	Soju 360ml	0.8534	2055	12chumS	[190,191,107,143]	restock
2025-10-09 17:03:38.411577	cam1	Canard	Strawberry Gose 330ml	0.8934	2056	04canard_sgK	[224,226,41,94]	restock
2025-09-21 04:25:20.411577	cam1	Bintang	Pilsener 620ml	0.7815	2057	06bintangB	[75,332,183,136]	sold
2025-05-02 04:24:45.411577	cam1	Wija	Soju 360ml	0.6858	2058	15wijaS	[382,129,150,147]	added
2025-04-18 19:31:54.411577	cam1	Bullsit	Whisky 500ml	0.861	2059	16bullsit_wS	[252,36,77,37]	sold
2025-09-04 21:33:53.411577	cam1	Wija	Blueberry 360ml	0.9517	2060	15wija_bS	[395,199,68,44]	sold
2025-04-01 23:50:26.411577	cam1	Bintang	Radler 330ml	0.8187	2061	06bintang_radlerS	[57,184,50,69]	sold
2025-04-08 17:27:04.411577	cam1	Kura Kura	Easy Ale 330ml	0.9029	2062	05kura_eaK	[14,324,51,217]	restock
2025-10-14 13:19:42.411577	cam1	Canard	Kolsch 330ml	0.8004	2063	04canard_kK	[351,100,188,72]	sold
2025-08-17 00:55:30.411577	cam1	Albens	Apple Lychee Cider 330ml	0.9753	2064	07albens_alcS	[382,291,140,201]	added
2026-01-06 17:57:26.411577	cam1	Orang Tua	Anggur Putih 620ml	0.8042	2065	01ot_aputB	[354,376,162,31]	sold
2025-07-03 13:28:08.411577	cam1	Asahi	Super Dry 334ml	0.8426	2066	48asahiK	[72,246,106,245]	added
2026-02-17 19:40:28.411577	cam1	Canard	Porter 330ml	0.6539	2067	04canard_pK	[178,253,241,40]	restock
2025-05-03 22:59:04.411577	cam1	Royal Brewhouse	Gold Royale 350ml	0.6628	2068	18rb_grS	[210,132,151,60]	sold
2025-12-21 05:59:31.411577	cam1	Orang Tua	Intisari Blackcurrant 620ml	0.969	2069	01ot_bcintB	[68,393,165,94]	sold
2025-09-23 12:11:39.411577	cam1	Extra Joss	Ultimate 250ml	0.8364	2070	53extrajK	[379,343,218,188]	sold
2025-10-26 10:43:20.411577	cam1	Iceland	Lychee Martini 275ml	0.9858	2071	03iceland_lmS	[249,24,220,105]	sold
2026-02-17 18:13:05.411577	cam1	Polaris	Soda Water 330ml	0.9637	2072	54polarisK	[337,120,94,54]	restock
2025-07-12 06:58:07.411577	cam1	Gilbey's	Whisky 350ml	0.8585	2073	37gilbeys_wS	[55,255,143,236]	sold
2025-12-06 03:02:52.411577	cam1	Three Peaks	Dry Gin 700ml	0.8521	2074	33threep_dgB	[122,218,170,235]	restock
2026-03-04 09:39:28.411577	cam1	Gordon's	PinkPremium 750ml	0.8092	2075	44gordon_ppB	[40,345,77,140]	sold
2025-08-13 20:21:25.411577	cam1	Vibe	Exotic Lychee 700ml	0.6718	2076	11vibe_elB	[211,110,115,140]	sold
2025-07-12 10:57:26.411577	cam1	Polaris	Soda Water 330ml	0.836	2077	54polarisK	[149,167,83,182]	restock
2025-10-17 06:13:39.411577	cam1	Kura Kura	Lager 330ml	0.9286	2078	05kura_lK	[177,218,249,186]	sold
2026-01-29 13:58:30.411577	cam1	Bacardi	Spiced Rum 750ml	0.7232	2079	36bacardi_srB	[324,184,45,92]	added
2025-10-04 07:55:30.411577	cam1	Bullsit	Gin 500ml	0.7439	2080	16bullsit_gS	[247,195,150,107]	restock
2025-04-10 19:08:22.411577	cam1	Kulturale	Naganini 330ml	0.7384	2081	09kulturale_nbwK	[22,95,237,213]	added
2026-01-06 10:54:54.411577	cam1	Baliwein	Anggur Salak 750ml	0.8157	2082	08baliwein_absB	[300,345,145,250]	sold
2026-01-25 19:48:28.411577	cam1	Iceland	Berry Lemonade 275ml	0.8626	2083	03iceland_beleS	[351,90,110,137]	added
2025-04-12 04:01:05.411577	cam1	New City	1L	0.6505	2084	24newcityB	[80,52,64,234]	added
2025-04-11 10:37:58.411577	cam1	Sababay	Pink Blossom 750ml	0.6686	2085	02sababay_pbB	[10,250,112,211]	added
2026-01-04 16:30:46.411577	cam1	Bacardi	Carta Blanca 750ml	0.7257	2086	36bacardi_cbB	[349,78,146,52]	sold
2026-03-05 06:25:07.411577	cam1	Cham Joeun	Lychee 360ml	0.7288	2087	40chamj_lS	[184,109,168,186]	added
2025-06-24 06:26:32.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.9708	2088	01ot_apiptB	[325,206,167,202]	sold
2025-05-21 14:33:07.411577	cam1	Baliwein	Sekala 750ml	0.9067	2089	08baliwein_sekB	[37,74,158,97]	restock
2025-07-21 17:59:44.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.8942	2090	10kawa_merahB	[364,70,183,98]	restock
2025-09-25 04:08:32.411577	cam1	Sapporo	330ml	0.7573	2091	49sapporoK	[71,319,238,54]	sold
2025-09-11 20:42:05.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.9402	2092	10kawa_merahB	[351,157,179,215]	added
2025-05-21 01:31:50.411577	cam1	Baliwein	Anggur Salak 750ml	0.9448	2093	08baliwein_absB	[150,104,34,146]	restock
2026-02-19 17:47:50.411577	cam1	Kura Kura	Easy Ale 330ml	0.6544	2094	05kura_eaK	[387,188,33,121]	restock
2025-06-10 10:22:13.411577	cam1	Sababay	Black Velvet 750ml	0.866	2095	02sababay_bvB	[367,286,250,77]	added
2025-04-19 01:24:30.411577	cam1	Kura Kura	IPA 330ml	0.7448	2096	05kura_ipaK	[67,321,174,108]	sold
2025-08-09 01:33:39.411577	cam1	Kura Kura	Lager 330ml	0.835	2097	05kura_lK	[290,69,177,101]	sold
2025-12-06 06:02:11.411577	cam1	Orang Tua	Arak Obat 620ml	0.9412	2098	01ot_aoB	[75,379,249,150]	sold
2025-06-05 10:28:21.411577	cam1	Sababay	Ludisia 750ml	0.9334	2099	02sababay_lB	[293,340,203,114]	restock
2025-10-23 12:08:42.411577	cam1	Extra Joss	Ultimate 250ml	0.7708	2100	53extrajK	[71,33,48,139]	added
2025-07-03 03:15:27.411577	cam1	Chum Churum	Peach 360ml	0.9464	2101	12chum_pS	[156,311,91,181]	sold
2025-04-06 09:01:47.411577	cam1	Orang Tua	Anggur Merah 275ml	0.8585	2102	01ot_amerS	[30,369,226,95]	restock
2025-06-29 01:58:01.411577	cam1	Cham Joeun	Soju 360ml	0.7581	2103	40chamjS	[244,185,216,240]	added
2025-07-26 11:05:58.411577	cam1	Guiness	Draught Stout 500ml	0.8747	2104	34guiness_dsBC	[208,186,90,115]	restock
2025-09-18 21:12:04.411577	cam1	Orang Tua	Atlas Lychee 620ml	0.7752	2105	01ot_atlaslB	[69,219,116,56]	restock
2026-03-01 14:40:00.411577	cam1	Sababay	Ludisia 750ml	0.8772	2106	02sababay_lB	[296,163,72,226]	sold
2025-09-25 13:11:04.411577	cam1	Bacardi	Spiced Rum 750ml	0.9079	2107	36bacardi_srB	[347,111,101,32]	added
2026-03-06 21:17:52.411577	cam1	Baliwein	Anggur Salak 750ml	0.7035	2108	08baliwein_absB	[91,202,235,207]	restock
2025-04-02 01:36:52.411577	cam1	Albens	Apple Mango Cider 330ml	0.7807	2109	07albens_amcS	[98,137,202,206]	sold
2025-12-15 19:05:23.411577	cam1	Santai	Lemon & Lime 330ml	0.9553	2110	14santai_llK	[149,174,134,32]	added
2025-07-18 02:54:24.411577	cam1	Albens	Apple Cier 330ml	0.9116	2111	07albensS	[283,182,205,141]	restock
2025-04-20 08:30:27.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.6791	2112	10kawa_merahB	[373,160,56,233]	restock
2025-09-09 15:06:56.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.9102	2113	10kawa_bcB	[93,296,83,112]	sold
2026-02-08 18:15:45.411577	cam1	Beaches	Cerveza 330ml	0.8414	2114	32beachescK	[278,210,70,244]	restock
2025-08-22 20:08:32.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.7372	2115	10kawa_bcB	[393,96,42,86]	sold
2025-10-23 16:44:14.411577	cam1	Kura Kura	Lager 330ml	0.685	2116	05kura_lK	[55,280,247,248]	added
2025-05-28 05:22:13.411577	cam1	Santai	Lemon & Lime 330ml	0.9746	2117	14santai_llK	[225,82,195,76]	sold
2025-09-21 10:08:35.411577	cam1	Sapporo	330ml	0.7722	2118	49sapporoK	[64,32,158,226]	added
2025-05-03 18:04:54.411577	cam1	Iceland	Original 700ml	0.8294	2119	03icelandB	[349,285,80,208]	sold
2025-12-20 01:03:11.411577	cam1	Canard	Kolsch 330ml	0.7197	2120	04canard_kK	[395,395,192,106]	sold
2025-04-08 00:06:49.411577	cam1	Kulturale	L. L. Stout 330ml	0.9785	2121	09kulturale_llsK	[268,335,249,110]	sold
2025-09-09 21:14:57.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.7001	2122	01ot_apiptB	[267,233,228,68]	added
2025-04-22 13:13:53.411577	cam1	Sprite	390ml	0.9	2123	59spriteK	[109,48,196,88]	added
2026-03-09 11:09:22.411577	cam1	Santai	Lemon & Lime 330ml	0.6509	2124	14santai_llK	[291,333,94,123]	sold
2025-03-15 10:08:21.411577	cam1	Iceland	Lychee Martini 275ml	0.7008	2125	03iceland_lmS	[345,106,173,107]	restock
2026-01-28 23:04:48.411577	cam1	Baliwein	Anggur Salak 750ml	0.7701	2126	08baliwein_absB	[386,314,237,127]	sold
2026-01-21 16:31:29.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.8906	2127	10kawa_merahB	[94,123,64,127]	sold
2025-03-24 01:49:55.411577	cam1	Baliwein	Semara 750ml	0.6772	2128	08baliwein_semB	[354,259,34,192]	added
2025-06-19 09:38:28.411577	cam1	Suntory Roku	Gin 700ml	0.9339	2129	43rokuB	[293,245,78,136]	restock
2025-08-15 18:20:59.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.9714	2130	08baliwein_abjmB	[88,127,154,166]	added
2025-05-17 22:54:51.411577	cam1	Extra Joss	Ultimate 250ml	0.6791	2131	53extrajK	[300,325,115,209]	added
2026-01-11 12:11:32.411577	cam1	Bacardi	Carta Blanca 750ml	0.6647	2132	36bacardi_cbB	[74,229,104,87]	added
2025-07-05 09:47:40.411577	cam1	Vibe	Exotic Lychee 700ml	0.8073	2133	11vibe_elB	[103,242,226,227]	sold
2025-11-06 09:51:11.411577	cam1	Drum	Whisky Black 700ml	0.7714	2134	22drum_wbB	[201,215,217,102]	added
2025-08-21 07:22:11.411577	cam1	Orang Tua	Arak Obat 620ml	0.8924	2135	01ot_aoB	[206,86,87,105]	restock
2025-07-09 01:51:31.411577	cam1	Kura Kura	Easy Ale 330ml	0.7012	2136	05kura_eaK	[55,388,237,219]	sold
2025-08-17 14:00:27.411577	cam1	Bintang	Pilsener 620ml	0.8755	2137	06bintangB	[80,200,154,52]	restock
2025-04-13 04:21:20.411577	cam1	Bullsit	Gin 500ml	0.9102	2138	16bullsit_gS	[387,356,163,240]	added
2025-05-04 19:10:24.411577	cam1	Canard	Kolsch 330ml	0.7791	2139	04canard_kK	[181,300,92,69]	sold
2025-10-20 18:54:47.411577	cam1	Iceland	Berry Lemonade 275ml	0.834	2140	03iceland_beleS	[342,159,216,162]	sold
2025-05-30 20:16:17.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.6775	2141	01ot_atlasrpB	[321,286,244,201]	added
2026-01-30 05:43:54.411577	cam1	Orang Tua	Intisari Anggur Hijau 620ml	0.8256	2142	01ot_hijauintB	[353,171,126,175]	sold
2025-07-08 13:09:39.411577	cam1	Albens	Apple Lychee Cider 330ml	0.735	2143	07albens_alcS	[147,272,237,230]	added
2025-04-26 12:37:41.411577	cam1	Iceland	Blue Lagoon 275ml	0.6673	2144	03iceland_blS	[29,151,206,158]	restock
2026-01-24 14:27:34.411577	cam1	Cham Joeun	Soju 360ml	0.735	2145	40chamjS	[159,309,216,178]	restock
2025-04-20 09:18:47.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.9588	2146	01ot_apiptB	[152,223,91,109]	restock
2025-05-26 21:39:15.411577	cam1	Santai	Lemon & Lime 330ml	0.7171	2147	14santai_llK	[303,248,44,68]	sold
2025-03-29 00:03:44.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.7554	2148	23palapaB	[173,364,82,154]	sold
2025-03-15 00:12:57.411577	cam1	Iceland	Original 700ml	0.9206	2149	03icelandB	[237,382,66,145]	sold
2025-07-22 22:39:47.411577	cam1	Chum Churum	Peach 360ml	0.8242	2150	12chum_pS	[175,13,179,143]	sold
2025-06-02 20:26:41.411577	cam1	Kulturale	Amarillo 330ml	0.806	2151	09kulturale_aK	[146,367,219,104]	added
2025-07-23 23:42:50.411577	cam1	Canard	Kolsch 330ml	0.8184	2152	04canard_kK	[249,85,111,151]	restock
2026-01-27 06:52:11.411577	cam1	Bintang	Pilsener 620ml	0.9033	2153	06bintangB	[284,294,138,82]	sold
2025-03-21 09:25:11.411577	cam1	Jose Cuervo	750ml	0.8929	2154	50josecuervoB	[217,272,124,210]	sold
2025-07-29 07:32:43.411577	cam1	Rajawali	Prost 620ml	0.986	2155	19rajawali_prostB	[320,227,226,164]	restock
2025-08-18 03:28:38.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.8138	2156	01ot_atlasrpB	[99,217,89,61]	added
2026-01-14 05:57:18.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.9391	2157	01ot_apihjB	[146,40,149,83]	restock
2025-06-11 04:55:37.411577	cam1	Iceland	Berry Lemonade 275ml	0.9603	2158	03iceland_beleS	[284,75,58,49]	added
2025-05-21 17:38:59.411577	cam1	Canard	Kolsch 330ml	0.7335	2159	04canard_kK	[390,201,87,125]	restock
2025-12-24 06:05:56.411577	cam1	Bullsit	Whisky 500ml	0.7298	2160	16bullsit_wS	[89,22,141,97]	sold
2025-09-30 15:03:35.411577	cam1	Orang Tua	Arak Obat 620ml	0.7394	2161	01ot_aoB	[174,75,90,85]	sold
2025-03-30 12:25:22.411577	cam1	Orang Tua	Anggur Merah 275ml	0.8525	2162	01ot_amerS	[261,35,180,72]	sold
2025-06-24 22:12:47.411577	cam1	Jameson	Irish Whiskey 700ml	0.8509	2163	41jamesonB	[77,379,109,195]	added
2026-02-07 07:06:11.411577	cam1	Canard	Strawberry Gose 330ml	0.858	2164	04canard_sgK	[164,211,36,48]	added
2025-06-22 10:37:20.411577	cam1	Vibe	Black Tea 700ml	0.6826	2165	11vibe_btB	[273,196,44,245]	added
2025-05-17 10:08:42.411577	cam1	Jameson	Irish Whiskey 700ml	0.7358	2166	41jamesonB	[319,396,240,164]	sold
2026-02-11 02:04:45.411577	cam1	Polaris	Soda Water 330ml	0.659	2167	54polarisK	[64,258,231,115]	sold
2025-09-29 18:41:42.411577	cam1	Orang Tua	Arak Obat 620ml	0.8192	2168	01ot_aoB	[40,314,201,30]	sold
2026-02-04 19:49:23.411577	cam1	Extra Joss	Ultimate 250ml	0.773	2169	53extrajK	[98,302,72,110]	sold
2025-07-31 03:45:33.411577	cam1	Sababay	Mascetti 750ml	0.861	2170	02sababay_masB	[284,112,145,105]	restock
2025-12-12 15:09:54.411577	cam1	Captain Morgan	Silver Rum 750ml	0.8268	2171	35cm_ssB	[283,110,105,250]	sold
2026-01-02 11:41:09.411577	cam1	Wija	Soju 360ml	0.7655	2172	15wijaS	[214,160,32,203]	added
2025-10-06 09:09:48.411577	cam1	Canard	Weizenbock 330ml	0.7381	2173	04canard_weK	[357,129,142,123]	sold
2025-09-12 05:02:11.411577	cam1	Kura Kura	Lager 330ml	0.7688	2174	05kura_lK	[366,135,187,187]	sold
2025-08-31 22:34:26.411577	cam1	Gilbey's	Gin 350ml	0.7589	2175	37gilbeys_gS	[400,310,153,78]	sold
2025-09-01 09:32:50.411577	cam1	Kulturale	Naganini 330ml	0.9563	2176	09kulturale_nbwK	[37,267,65,226]	sold
2025-11-22 05:34:24.411577	cam1	Jameson	Irish Whiskey 700ml	0.7633	2177	41jamesonB	[28,320,220,194]	added
2026-01-11 16:53:07.411577	cam1	Wija	Soju 360ml	0.975	2178	15wijaS	[310,19,80,37]	sold
2025-07-04 02:17:10.411577	cam1	Iceland	Original 250ml	0.6843	2179	03icelandK	[247,28,226,180]	sold
2025-06-28 00:30:26.411577	cam1	Iceland	Lychee Martini 275ml	0.8019	2180	03iceland_lmS	[389,364,158,37]	added
2025-05-16 00:16:25.411577	cam1	Iceland	Lychee Martini 275ml	0.8838	2181	03iceland_lmS	[61,68,170,118]	sold
2025-10-03 23:54:47.411577	cam1	Bintang	Pilsener 620ml	0.6663	2182	06bintangB	[192,14,250,80]	sold
2025-04-12 05:35:56.411577	cam1	Rajawali	Prost 620ml	0.7544	2183	19rajawali_prostB	[333,212,64,59]	restock
2026-02-27 15:22:32.411577	cam1	Iceland	Original 250ml	0.695	2184	03icelandK	[387,151,204,200]	sold
2025-03-12 06:48:01.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.787	2185	01ot_apihjB	[121,389,237,216]	restock
2025-03-21 15:35:49.411577	cam1	Wija	Blueberry 360ml	0.8596	2186	15wija_bS	[220,391,148,113]	sold
2025-05-27 02:24:43.411577	cam1	Royal Brewhouse	Black Royale 350ml	0.6692	2187	18rb_brS	[258,62,152,121]	sold
2026-01-09 04:50:14.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.9405	2188	23palapaB	[334,382,31,206]	sold
2025-11-05 07:04:22.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.8146	2189	19rajawali_prostalK	[205,270,100,123]	restock
2025-06-26 22:00:35.411577	cam1	Orang Tua	Anggur Merah 275ml	0.7318	2190	01ot_amerS	[200,104,183,124]	sold
2025-09-20 06:14:57.411577	cam1	Smirnoff	Vodka 700ml	0.7589	2191	45smirnoffB	[52,314,58,119]	restock
2026-02-20 18:21:08.411577	cam1	Bullsit	Gin 500ml	0.8854	2192	16bullsit_gS	[245,328,131,129]	added
2025-05-23 16:20:24.411577	cam1	Canard	Strawberry Gose 330ml	0.6672	2193	04canard_sgK	[282,119,191,235]	added
2025-06-09 21:42:27.411577	cam1	Kura Kura	Island Ale 330ml	0.7299	2194	05kura_iaK	[283,71,184,163]	sold
2025-08-10 13:33:33.411577	cam1	Orang Tua	Anggur Merah 620ml	0.9763	2195	01ot_amerB	[348,328,240,113]	added
2025-05-30 06:48:22.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.7863	2196	10kawa_bcB	[15,121,177,240]	restock
2025-04-11 12:57:17.411577	cam1	Santai	Lemon & Lime 330ml	0.7565	2197	14santai_llK	[29,194,184,234]	restock
2025-11-17 07:04:16.411577	cam1	Baliwein	Sekala 750ml	0.9051	2198	08baliwein_sekB	[355,13,62,186]	sold
2025-08-16 11:05:05.411577	cam1	Guiness	Foreign Extra Stout 320ml	0.8857	2199	34guinessK_fesKC	[284,155,230,128]	sold
2025-12-02 01:51:27.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.7434	2200	08baliwein_abjmB	[319,162,167,173]	restock
2026-01-28 16:13:12.411577	cam1	Gilbey's	Whisky 350ml	0.9536	2201	37gilbeys_wS	[297,247,128,133]	sold
2025-12-31 06:50:23.411577	cam1	Extra Joss	Ultimate 250ml	0.9816	2202	53extrajK	[194,268,154,173]	restock
2025-07-03 22:10:51.411577	cam1	Iceland	Berry Lemonade 275ml	0.7899	2203	03iceland_beleS	[95,23,193,133]	restock
2025-07-16 21:38:49.411577	cam1	Kulturale	L. L. Stout 330ml	0.9754	2204	09kulturale_llsK	[176,229,236,243]	added
2025-08-15 01:07:57.411577	cam1	Captain Morgan	Spice Gold 750ml	0.6567	2205	35cm_sgB	[314,330,137,72]	sold
2025-08-21 15:20:44.411577	cam1	Pokka	Green Tea 300ml	0.7419	2206	57pokkaK	[136,276,190,97]	added
2026-02-10 13:43:28.411577	cam1	Suntory Roku	Gin 700ml	0.7788	2207	43rokuB	[376,183,54,165]	sold
2025-04-22 05:31:48.411577	cam1	Royal Brewhouse	Black Royale 350ml	0.7708	2208	18rb_brS	[199,218,70,220]	sold
2025-07-03 07:03:12.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.6955	2209	23palapaB	[46,343,192,66]	sold
2026-02-08 07:17:02.411577	cam1	Wija	Lychee 360ml	0.8013	2210	15wija_lS	[67,211,40,119]	sold
2025-12-31 13:51:09.411577	cam1	Bintang	Pilsener 330ml	0.9405	2211	06bintangK	[262,137,48,195]	sold
2025-07-02 00:46:11.411577	cam1	Bacardi	Carta Blanca 750ml	0.7396	2212	36bacardi_cbB	[14,186,207,48]	restock
2026-03-03 03:22:55.411577	cam1	Bacardi	Carta Blanca 750ml	0.8929	2213	36bacardi_cbB	[181,399,177,210]	added
2025-08-29 17:39:30.411577	cam1	Crystalline	330ml	0.9048	2214	55crystalinK	[268,347,190,186]	added
2025-04-01 13:38:42.411577	cam1	Orang Tua	Intisari Anggur Hijau 620ml	0.7035	2215	01ot_hijauintB	[229,146,73,78]	sold
2025-05-17 22:25:39.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.8825	2216	08baliwein_abjmB	[125,144,193,46]	sold
2025-04-22 04:08:13.411577	cam1	Captain Morgan	Silver Rum 750ml	0.715	2217	35cm_ssB	[100,208,180,167]	added
2025-05-10 11:57:28.411577	cam1	Bullsit	Gin 500ml	0.9036	2218	16bullsit_gS	[105,66,221,210]	added
2026-01-12 11:50:10.411577	cam1	Bintang	Radler 330ml	0.9239	2219	06bintang_radlerS	[14,217,202,190]	added
2026-03-07 05:50:08.411577	cam1	Canard	Weizenbock 330ml	0.7613	2220	04canard_weK	[356,25,102,144]	added
2025-10-30 20:50:01.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.7067	2221	23palapaB	[194,47,104,121]	restock
2025-05-23 00:48:19.411577	cam1	Orang Tua	Anggur Merah 620ml	0.9289	2222	01ot_amerB	[176,127,48,121]	added
2025-09-02 00:52:44.411577	cam1	Sapporo	330ml	0.9305	2223	49sapporoK	[34,371,213,38]	restock
2025-12-03 19:17:59.411577	cam1	Drum	Whisky Black 700ml	0.6651	2224	22drum_wbB	[46,386,84,150]	sold
2025-05-06 08:42:44.411577	cam1	Yakult	1 pack 325ml	0.8877	2225	60yakultK	[319,116,185,209]	sold
2025-05-04 10:16:42.411577	cam1	Sprite	390ml	0.9708	2226	59spriteK	[176,149,53,128]	added
2026-01-15 02:54:51.411577	cam1	Canard	Kolsch 330ml	0.6536	2227	04canard_kK	[174,173,31,226]	added
2025-12-10 20:41:00.411577	cam1	Vibe	Exotic Lychee 700ml	0.6615	2228	11vibe_elB	[242,219,217,225]	added
2026-02-08 16:06:18.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.8888	2229	23palapaB	[89,360,38,206]	sold
2025-08-17 10:30:35.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.7225	2230	08baliwein_abjmB	[167,392,80,100]	added
2025-06-14 22:59:30.411577	cam1	Wija	Soju 360ml	0.9022	2231	15wijaS	[265,389,190,109]	restock
2025-08-19 17:28:55.411577	cam1	Royal Brewhouse	Black Royale 350ml	0.9163	2232	18rb_brS	[371,378,153,148]	added
2025-05-17 23:06:24.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.791	2233	14santai_agaK	[13,350,152,179]	sold
2025-07-16 06:54:18.411577	cam1	Canard	Session IPA 330ml	0.8602	2234	04canard_siK	[217,200,72,206]	added
2025-05-17 04:56:55.411577	cam1	Canard	Witbier 330ml	0.6593	2235	04canard_wK	[136,278,41,212]	sold
2025-07-25 19:41:41.411577	cam1	Iceland	Blue Lagoon 275ml	0.8965	2236	03iceland_blS	[349,21,181,199]	sold
2025-06-20 03:41:40.411577	cam1	Wija	Blueberry 360ml	0.807	2237	15wija_bS	[28,140,166,114]	added
2025-10-06 02:24:35.411577	cam1	Bintang	Radler 330ml	0.7862	2238	06bintang_radlerS	[138,240,111,48]	sold
2025-03-30 04:51:27.411577	cam1	Batavia	Whisky 700ml	0.8768	2239	21bataviaB	[45,94,136,117]	sold
2025-06-01 17:21:29.411577	cam1	New City	1L	0.8335	2240	24newcityB	[362,394,84,235]	restock
2025-09-26 21:50:07.411577	cam1	Royal Brewhouse	Black Royale 350ml	0.8378	2241	18rb_brS	[364,251,45,92]	sold
2025-12-29 20:05:46.411577	cam1	Cham Joeun	Soju 360ml	0.8484	2242	40chamjS	[400,135,204,196]	added
2026-02-13 17:09:53.411577	cam1	Batavia	Whisky 700ml	0.9359	2243	21bataviaB	[361,236,70,107]	sold
2025-12-27 23:24:16.411577	cam1	Gilbey's	Gin 350ml	0.9805	2244	37gilbeys_gS	[103,110,104,155]	restock
2025-09-01 09:26:55.411577	cam1	Iceland	Berry Lemonade 275ml	0.6925	2245	03iceland_beleS	[145,207,68,231]	sold
2025-11-05 17:11:45.411577	cam1	Gordon's	PinkPremium 750ml	0.8965	2246	44gordon_ppB	[360,13,171,143]	sold
2025-11-16 21:48:27.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.9875	2247	01ot_atlasrpB	[339,398,123,128]	added
2025-11-09 05:41:41.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.7121	2248	01ot_apiptB	[14,96,127,201]	sold
2025-12-24 18:49:11.411577	cam1	Pokka	Green Tea 300ml	0.8585	2249	57pokkaK	[314,238,212,35]	added
2025-11-09 00:59:41.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.7328	2250	10kawa_bcB	[113,87,60,44]	sold
2026-01-22 14:58:27.411577	cam1	Canard	Kolsch 330ml	0.8866	2251	04canard_kK	[40,340,120,61]	added
2026-03-01 04:22:25.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.9229	2252	10kawa_merahB	[360,119,40,163]	sold
2025-07-09 06:37:05.411577	cam1	Bintang	Pilsener 620ml	0.6936	2253	06bintangB	[160,153,50,187]	sold
2026-02-06 21:30:30.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.8858	2254	10kawa_bcB	[372,189,31,104]	sold
2025-10-30 13:14:46.411577	cam1	Heineken	330ml	0.8297	2255	46heinekenS	[206,179,218,67]	sold
2025-05-17 19:16:09.411577	cam1	Three Peaks	Dry Gin 700ml	0.6977	2256	33threep_dgB	[119,248,192,187]	sold
2025-12-06 02:27:34.411577	cam1	Asahi	Super Dry 334ml	0.7999	2257	48asahiK	[119,125,84,35]	added
2025-08-04 17:33:40.411577	cam1	Captain Morgan	Silver Rum 750ml	0.6865	2258	35cm_ssB	[41,184,171,101]	added
2025-08-17 21:09:43.411577	cam1	Kura Kura	IPA 330ml	0.6833	2259	05kura_ipaK	[385,53,183,40]	sold
2025-09-01 09:29:05.411577	cam1	Iceland	Original 700ml	0.7169	2260	03icelandB	[252,298,62,241]	sold
2025-07-12 01:30:22.411577	cam1	Baliwein	Anggur Salak 750ml	0.7314	2261	08baliwein_absB	[76,169,222,191]	restock
2025-06-10 10:51:44.411577	cam1	Kura Kura	Lager 330ml	0.8656	2262	05kura_lK	[161,114,82,106]	sold
2026-02-26 08:05:10.411577	cam1	Iceland	Original 700ml	0.9872	2263	03icelandB	[54,43,209,65]	sold
2025-11-16 13:17:47.411577	cam1	Kulturale	Amarillo 330ml	0.9414	2264	09kulturale_aK	[398,27,232,204]	restock
2025-06-07 12:56:38.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.957	2265	01ot_amergoldB	[371,231,36,140]	sold
2025-08-23 14:08:47.411577	cam1	Bintang	Pilsener 500ml	0.7699	2266	06bintangBC	[240,245,63,101]	sold
2025-06-15 11:19:33.411577	cam1	Iceland	Lychee Martini 275ml	0.9448	2267	03iceland_lmS	[42,56,74,240]	restock
2025-09-15 06:34:08.411577	cam1	Jagermeister	700ml	0.9317	2268	42jagermeisterB	[168,353,155,187]	restock
2026-01-02 06:10:46.411577	cam1	New City	1L	0.8221	2269	24newcityB	[188,291,60,250]	sold
2025-06-11 11:01:11.411577	cam1	Iceland	Lychee Martini 275ml	0.7512	2270	03iceland_lmS	[224,344,125,56]	sold
2025-07-04 03:57:12.411577	cam1	Smirnoff	Vodka 700ml	0.9242	2271	45smirnoffB	[268,174,246,241]	sold
2025-07-23 03:18:32.411577	cam1	Captain Morgan	Silver Rum 750ml	0.9355	2272	35cm_ssB	[129,186,212,138]	added
2025-10-30 01:09:22.411577	cam1	Wija	Lychee 360ml	0.8041	2273	15wija_lS	[386,229,146,97]	added
2025-05-05 10:40:04.411577	cam1	Canard	Strawberry Gose 330ml	0.9481	2274	04canard_sgK	[375,56,98,141]	restock
2025-06-19 08:06:34.411577	cam1	Bintang	Pilsener 500ml	0.9808	2275	06bintangBC	[183,274,52,212]	sold
2025-09-17 09:44:07.411577	cam1	Sababay	Mascetti 750ml	0.8512	2276	02sababay_masB	[197,67,173,216]	sold
2025-07-14 15:14:16.411577	cam1	Iceland	Berry Lemonade 275ml	0.6951	2277	03iceland_beleS	[35,318,218,192]	added
2025-10-24 00:29:39.411577	cam1	Kulturale	L. L. Stout 330ml	0.8803	2278	09kulturale_llsK	[363,169,89,122]	added
2026-01-19 09:41:10.411577	cam1	Bacardi	Spiced Rum 750ml	0.9522	2279	36bacardi_srB	[233,47,67,42]	restock
2025-03-20 20:55:20.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.6563	2280	01ot_apihjB	[19,35,127,103]	added
2025-11-25 15:26:26.411577	cam1	Heineken	330ml	0.9439	2281	46heinekenS	[149,136,152,117]	added
2025-11-04 03:10:48.411577	cam1	Iceland	Berry Lemonade 275ml	0.8749	2282	03iceland_beleS	[331,386,105,151]	sold
2025-10-04 11:25:43.411577	cam1	Kura Kura	Island Ale 330ml	0.7129	2283	05kura_iaK	[318,296,91,108]	added
2025-11-01 12:43:32.411577	cam1	Canard	Weizenbock 330ml	0.853	2284	04canard_weK	[89,210,38,201]	sold
2026-01-04 01:35:57.411577	cam1	Wija	Blueberry 360ml	0.7805	2285	15wija_bS	[154,165,180,149]	added
2025-07-28 19:45:20.411577	cam1	Canard	Session IPA 330ml	0.6576	2286	04canard_siK	[358,115,67,68]	restock
2025-05-24 09:30:00.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.6896	2287	14santai_agaK	[186,377,118,147]	sold
2026-02-23 10:48:13.411577	cam1	Drum	Whisky Black 700ml	0.8213	2288	22drum_wbB	[193,21,65,105]	restock
2025-06-18 13:37:03.411577	cam1	Royal Brewhouse	Gold Royale 350ml	0.8108	2289	18rb_grS	[322,141,232,215]	added
2026-01-26 13:31:31.411577	cam1	Canard	Kolsch 330ml	0.7077	2290	04canard_kK	[218,240,65,52]	sold
2025-10-20 22:27:27.411577	cam1	Sababay	Black Velvet 750ml	0.8922	2291	02sababay_bvB	[199,266,77,181]	sold
2025-08-15 04:06:11.411577	cam1	Rajawali	Prost 620ml	0.7454	2292	19rajawali_prostB	[306,98,35,66]	added
2025-11-12 20:00:17.411577	cam1	Batavia	Whisky 700ml	0.9354	2293	21bataviaB	[241,79,203,66]	restock
2026-03-10 23:30:55.411577	cam1	Iceland	Berry Lemonade 275ml	0.679	2294	03iceland_beleS	[146,223,77,97]	sold
2025-05-21 19:49:09.411577	cam1	Albens	Apple Cier 330ml	0.7509	2295	07albensS	[49,148,83,34]	sold
2026-02-07 07:59:21.411577	cam1	Guiness	Foreign Extra Stout 620ml	0.7872	2296	34guiness_fesB	[50,236,139,88]	sold
2025-09-25 22:44:26.411577	cam1	Drum	Whisky Black 700ml	0.7684	2297	22drum_wbB	[69,274,153,66]	restock
2025-10-01 04:13:52.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.9289	2298	01ot_apihjB	[253,68,192,125]	sold
2025-09-18 10:28:56.411577	cam1	Kura Kura	IPA 330ml	0.9116	2299	05kura_ipaK	[298,166,91,34]	sold
2025-06-11 21:45:06.411577	cam1	Captain Morgan	Spice Gold 750ml	0.6563	2300	35cm_sgB	[201,123,119,97]	added
2025-07-12 07:22:43.411577	cam1	Bintang	Radler 330ml	0.693	2301	06bintang_radlerS	[275,120,184,92]	sold
2025-08-25 18:11:07.411577	cam1	Canard	Weizenbock 330ml	0.7425	2302	04canard_weK	[202,161,214,111]	restock
2025-08-17 20:54:16.411577	cam1	Bullsit	Gin 500ml	0.8045	2303	16bullsit_gS	[365,109,124,160]	sold
2026-02-18 15:03:27.411577	cam1	Baliwein	Semara 750ml	0.9204	2304	08baliwein_semB	[380,181,232,108]	sold
2025-06-08 17:54:21.411577	cam1	Wija	Lychee 360ml	0.8574	2305	15wija_lS	[138,266,125,31]	added
2025-06-18 16:01:27.411577	cam1	Bintang	Pilsener 500ml	0.7039	2306	06bintangBC	[142,248,139,217]	sold
2025-11-01 12:28:46.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.8628	2307	23palapaB	[332,324,98,82]	restock
2025-06-08 11:54:12.411577	cam1	Corona	Extra 355ml	0.923	2308	47corona_eS	[150,35,160,101]	added
2025-11-23 08:48:01.411577	cam1	Albens	Apple Cier 330ml	0.7407	2309	07albensS	[140,192,192,147]	sold
2025-09-15 19:25:18.411577	cam1	Asahi	Super Dry 334ml	0.8012	2310	48asahiK	[292,299,221,142]	added
2025-07-14 13:24:18.411577	cam1	Guiness	Foreign Extra Stout 620ml	0.9714	2311	34guiness_fesB	[179,184,185,124]	sold
2025-08-13 06:03:32.411577	cam1	Royal Brewhouse	Gold Royale 350ml	0.8934	2312	18rb_grS	[63,66,95,154]	restock
2025-12-29 01:43:42.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.7003	2313	19rajawali_prostalK	[63,365,207,87]	sold
2025-08-09 00:28:42.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.8926	2314	10kawa_bcB	[111,187,199,144]	added
2025-03-27 15:18:26.411577	cam1	Orang Tua	Arak Obat 620ml	0.9871	2315	01ot_aoB	[149,118,235,49]	restock
2025-11-23 14:26:29.411577	cam1	Pu Tao Chee Chiew	330ml	0.929	2316	31putaoccS	[196,51,48,32]	restock
2026-01-22 15:54:59.411577	cam1	Pu Tao Chee Chiew	330ml	0.6733	2317	31putaoccS	[19,29,147,208]	sold
2025-09-06 23:20:58.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.8987	2318	01ot_apihjB	[174,335,177,127]	added
2025-07-14 07:56:56.411577	cam1	Orang Tua	Intisari Anggur Hijau 620ml	0.8936	2319	01ot_hijauintB	[304,233,123,237]	added
2025-09-08 17:55:43.411577	cam1	Crystalline	330ml	0.7123	2320	55crystalinK	[147,21,90,198]	restock
2025-08-24 16:35:12.411577	cam1	Iceland	Orange 700ml	0.8642	2321	03iceland_oB	[147,319,234,219]	added
2025-04-09 20:36:05.411577	cam1	Heineken	330ml	0.6671	2322	46heinekenS	[95,100,218,153]	restock
2025-04-18 10:46:02.411577	cam1	Sababay	Ludisia 750ml	0.9303	2323	02sababay_lB	[226,283,81,244]	sold
2025-07-03 14:16:19.411577	cam1	Cham Joeun	Soju 360ml	0.8322	2324	40chamjS	[317,385,104,198]	sold
2025-09-02 23:27:57.411577	cam1	Kulturale	N. R. K. DIPA 330ml	0.9524	2325	09kulturale_nrkK	[154,361,199,33]	sold
2026-02-16 19:49:57.411577	cam1	Orang Tua	Intisari Anggur Hijau 620ml	0.7115	2326	01ot_hijauintB	[327,397,225,209]	added
2025-12-03 06:59:24.411577	cam1	Bullsit	Gin 500ml	0.8855	2327	16bullsit_gS	[12,141,51,57]	sold
2025-03-16 00:38:51.411577	cam1	Orang Tua	Singaraja 620ml	0.7518	2328	01ot_singarajaB	[13,355,63,160]	sold
2025-04-19 16:33:49.411577	cam1	Baliwein	Semara 750ml	0.8801	2329	08baliwein_semB	[146,53,120,183]	sold
2025-09-26 07:28:45.411577	cam1	Bullsit	Vodka 500ml	0.7191	2330	16bullsit_vS	[216,268,234,227]	added
2025-06-19 16:51:03.411577	cam1	Royal Brewhouse	Black Royale 350ml	0.6657	2331	18rb_brS	[242,287,101,227]	added
2025-12-02 23:45:02.411577	cam1	Guiness	Foreign Extra Stout 620ml	0.759	2332	34guiness_fesB	[39,352,240,49]	added
2025-03-24 03:55:43.411577	cam1	Jameson	Irish Whiskey 700ml	0.677	2333	41jamesonB	[131,270,117,232]	added
2025-07-07 04:32:02.411577	cam1	Sababay	Ludisia 750ml	0.8251	2334	02sababay_lB	[251,108,153,143]	restock
2025-12-23 02:13:24.411577	cam1	Sababay	Black Velvet 750ml	0.7482	2335	02sababay_bvB	[126,328,192,179]	added
2025-09-08 11:55:26.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.6648	2336	01ot_apiptB	[224,359,64,134]	added
2025-12-23 21:32:35.411577	cam1	Canard	Porter 330ml	0.9456	2337	04canard_pK	[193,218,98,45]	added
2025-06-24 21:52:15.411577	cam1	Bullsit	Vodka 500ml	0.7517	2338	16bullsit_vS	[289,55,121,139]	added
2025-04-11 17:37:34.411577	cam1	Pokka	Green Tea 300ml	0.8299	2339	57pokkaK	[36,170,53,90]	added
2025-05-01 10:17:38.411577	cam1	Wija	Lychee 360ml	0.8258	2340	15wija_lS	[64,130,194,196]	added
2025-11-24 13:12:29.411577	cam1	Gilbey's	Gin 350ml	0.7024	2341	37gilbeys_gS	[373,74,145,164]	sold
2025-12-25 05:39:13.411577	cam1	Gilbey's	Whisky 350ml	0.7194	2342	37gilbeys_wS	[268,311,227,212]	added
2025-04-23 22:07:48.411577	cam1	Gilbey's	Gin 350ml	0.963	2343	37gilbeys_gS	[139,170,103,129]	restock
2025-06-20 18:51:02.411577	cam1	Kulturale	L. L. Stout 330ml	0.7824	2344	09kulturale_llsK	[267,186,151,126]	sold
2025-05-22 07:52:48.411577	cam1	Iceland	Original 250ml	0.8732	2345	03icelandK	[33,166,81,156]	added
2025-07-28 13:38:03.411577	cam1	Canard	Kolsch 330ml	0.6815	2346	04canard_kK	[106,76,173,101]	sold
2025-07-07 21:16:39.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.9588	2347	10kawa_bcB	[113,215,60,63]	added
2026-02-06 16:36:43.411577	cam1	Kura Kura	Session Hazy 330ml	0.6975	2348	05kura_shK	[235,211,174,82]	added
2025-08-14 18:10:34.411577	cam1	Canard	Session IPA 330ml	0.712	2349	04canard_siK	[160,178,105,246]	restock
2026-02-01 21:42:53.411577	cam1	Drum	Whisky Black 700ml	0.943	2350	22drum_wbB	[45,216,61,244]	restock
2025-07-08 02:18:43.411577	cam1	Jameson	Irish Whiskey 700ml	0.8548	2351	41jamesonB	[106,248,58,136]	added
2025-11-01 03:22:46.411577	cam1	Baliwein	Semara 750ml	0.7434	2352	08baliwein_semB	[138,353,104,107]	added
2025-04-02 11:56:06.411577	cam1	Guiness	Draught Stout 500ml	0.9074	2353	34guiness_dsBC	[339,283,85,51]	restock
2025-06-24 20:30:56.411577	cam1	Bullsit	Gin 500ml	0.9455	2354	16bullsit_gS	[296,150,200,164]	added
2026-02-11 17:47:43.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.7799	2355	10kawa_hijauB	[58,67,30,137]	sold
2025-11-15 08:47:54.411577	cam1	Bintang	Pilsener 620ml	0.777	2356	06bintangB	[251,310,220,178]	sold
2025-09-15 08:02:50.411577	cam1	Jagermeister	700ml	0.8262	2357	42jagermeisterB	[30,110,187,212]	added
2026-01-06 11:39:11.411577	cam1	Drum	Whisky Black 700ml	0.7831	2358	22drum_wbB	[167,178,160,31]	restock
2025-08-01 11:50:21.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.8727	2359	01ot_apihjB	[193,79,98,224]	restock
2026-02-09 18:07:54.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.9394	2360	10kawa_merahB	[92,251,71,93]	sold
2025-10-05 16:03:21.411577	cam1	Jose Cuervo	750ml	0.8765	2361	50josecuervoB	[187,394,65,196]	restock
2025-10-01 17:12:55.411577	cam1	Pokka	Green Tea 300ml	0.7027	2362	57pokkaK	[81,55,174,61]	added
2025-04-03 01:40:42.411577	cam1	Bullsit	Whisky 500ml	0.8046	2363	16bullsit_wS	[330,367,114,67]	restock
2025-11-05 06:33:58.411577	cam1	Kulturale	Bravo 330ml	0.7972	2364	09kulturale_bK	[380,392,235,188]	sold
2026-01-08 01:06:07.411577	cam1	Bacardi	Carta Blanca 750ml	0.7222	2365	36bacardi_cbB	[258,133,196,138]	added
2025-06-25 14:36:48.411577	cam1	Three Peaks	Dry Gin 700ml	0.8655	2366	33threep_dgB	[57,249,146,75]	sold
2025-09-19 19:48:23.411577	cam1	Bintang	Pilsener 330ml	0.6904	2367	06bintangK	[197,163,232,129]	sold
2025-09-24 10:14:07.411577	cam1	Kura Kura	Easy Ale 330ml	0.8549	2368	05kura_eaK	[287,136,144,67]	sold
2025-10-28 19:00:46.411577	cam1	Yakult	1 pack 325ml	0.6629	2369	60yakultK	[249,109,179,150]	added
2026-02-09 15:15:55.411577	cam1	Drum	Whisky Black 700ml	0.8416	2370	22drum_wbB	[167,252,56,248]	sold
2026-01-10 14:06:28.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.9291	2371	01ot_atlasrpB	[369,358,225,86]	restock
2026-02-19 19:30:57.411577	cam1	Kura Kura	Lager 330ml	0.8861	2372	05kura_lK	[80,209,169,97]	added
2026-02-08 19:14:17.411577	cam1	Rajawali	Prost 620ml	0.9279	2373	19rajawali_prostB	[150,384,167,151]	added
2026-02-14 00:26:12.411577	cam1	Iceland	Lychee Martini 275ml	0.7662	2374	03iceland_lmS	[171,225,89,105]	restock
2025-09-27 17:52:34.411577	cam1	Kura Kura	Island Ale 330ml	0.8927	2375	05kura_iaK	[223,143,102,144]	sold
2025-06-28 09:51:25.411577	cam1	Jameson	Irish Whiskey 700ml	0.7577	2376	41jamesonB	[46,379,110,57]	sold
2025-04-02 20:48:53.411577	cam1	Jose Cuervo	750ml	0.9243	2377	50josecuervoB	[234,149,230,215]	restock
2025-11-07 07:33:57.411577	cam1	Wija	Blueberry 360ml	0.7708	2378	15wija_bS	[62,98,142,217]	added
2025-08-11 01:37:07.411577	cam1	Canard	Session IPA 330ml	0.723	2379	04canard_siK	[391,206,87,205]	sold
2025-04-29 07:28:25.411577	cam1	Kura Kura	Lager 330ml	0.9586	2380	05kura_lK	[382,71,193,98]	added
2026-03-08 20:35:07.411577	cam1	Polaris	Soda Water 330ml	0.8076	2381	54polarisK	[187,190,73,228]	sold
2026-01-25 23:38:17.411577	cam1	Chum Churum	Peach 360ml	0.9868	2382	12chum_pS	[171,238,189,178]	sold
2025-08-13 20:45:40.411577	cam1	Orang Tua	Arak Obat 620ml	0.7965	2383	01ot_aoB	[144,26,178,230]	restock
2025-12-11 23:25:49.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.8848	2384	10kawa_hijauB	[335,179,218,217]	added
2026-01-17 16:05:51.411577	cam1	Smirnoff	Vodka 700ml	0.6975	2385	45smirnoffB	[260,64,154,147]	added
2025-04-15 11:11:38.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.8248	2386	10kawa_bcB	[44,314,49,79]	sold
2025-05-09 16:33:22.411577	cam1	Baliwein	Anggur Salak 750ml	0.9134	2387	08baliwein_absB	[307,114,182,74]	restock
2025-12-28 03:03:08.411577	cam1	Captain Morgan	Silver Rum 750ml	0.7998	2388	35cm_ssB	[373,283,244,86]	added
2026-01-19 12:55:41.411577	cam1	Three Peaks	Dry Gin 700ml	0.8951	2389	33threep_dgB	[347,303,64,159]	sold
2025-08-16 08:32:13.411577	cam1	Santai	Passionfruit & Guava 330ml	0.7003	2390	14santai_pgK	[58,393,219,231]	sold
2025-07-03 18:49:53.411577	cam1	Orang Tua	Singaraja 620ml	0.6522	2391	01ot_singarajaB	[164,355,121,45]	sold
2025-11-20 09:43:04.411577	cam1	Kulturale	Amarillo 330ml	0.7184	2392	09kulturale_aK	[130,380,229,56]	added
2025-06-01 05:05:47.411577	cam1	Three Peaks	Dry Gin 700ml	0.683	2393	33threep_dgB	[46,69,183,56]	added
2025-11-24 20:25:59.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.7638	2394	01ot_atlasrpB	[56,112,79,98]	sold
2025-10-22 04:07:17.411577	cam1	Vibe	Black Tea 700ml	0.8728	2395	11vibe_btB	[161,218,207,241]	restock
2026-01-02 12:20:57.411577	cam1	Canard	Kolsch 330ml	0.6935	2396	04canard_kK	[240,232,84,106]	sold
2025-05-08 02:50:49.411577	cam1	Canard	Witbier 330ml	0.94	2397	04canard_wK	[290,248,215,64]	sold
2025-09-22 03:55:05.411577	cam1	Captain Morgan	Silver Rum 750ml	0.8553	2398	35cm_ssB	[74,233,159,151]	added
2025-08-28 14:33:06.411577	cam1	Gordon's	PinkPremium 750ml	0.9562	2399	44gordon_ppB	[38,18,242,129]	sold
2025-06-27 17:15:28.411577	cam1	Guiness	Foreign Extra Stout 320ml	0.6988	2400	34guinessK_fesKC	[15,290,206,61]	sold
2025-08-02 08:22:25.411577	cam1	Heineken	330ml	0.8368	2401	46heinekenS	[364,215,140,120]	added
2025-04-20 03:22:28.411577	cam1	Wija	Lychee 360ml	0.7193	2402	15wija_lS	[137,290,223,224]	added
2025-12-28 18:10:38.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.8822	2403	01ot_amergoldB	[137,188,100,103]	added
2025-03-30 12:12:12.411577	cam1	Bullsit	Gin 500ml	0.8842	2404	16bullsit_gS	[253,255,203,134]	added
2025-11-03 14:31:09.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.7368	2405	08baliwein_abjmB	[392,158,213,64]	sold
2026-03-10 19:26:59.411577	cam1	Wija	Blueberry 360ml	0.7971	2406	15wija_bS	[284,285,157,141]	restock
2026-01-10 10:06:28.411577	cam1	Santai	Passionfruit & Guava 330ml	0.7112	2407	14santai_pgK	[45,229,137,110]	restock
2025-12-20 02:33:15.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.9834	2408	01ot_atlasrpB	[198,145,72,148]	sold
2025-09-26 05:32:06.411577	cam1	Batavia	Whisky 700ml	0.768	2409	21bataviaB	[364,212,175,51]	sold
2025-11-29 12:31:14.411577	cam1	Cham Joeun	Lychee 360ml	0.8803	2410	40chamj_lS	[118,304,60,80]	sold
2025-09-27 21:37:19.411577	cam1	Kura Kura	Island Ale 330ml	0.8668	2411	05kura_iaK	[91,277,45,62]	sold
2025-08-29 06:53:25.411577	cam1	Yakult	1 pack 325ml	0.8791	2412	60yakultK	[57,391,101,80]	added
2025-09-08 13:14:04.411577	cam1	Vibe	Exotic Lychee 700ml	0.8238	2413	11vibe_elB	[108,29,197,222]	sold
2025-04-12 19:04:29.411577	cam1	Jameson	Irish Whiskey 700ml	0.8446	2414	41jamesonB	[223,158,57,170]	added
2025-07-03 08:56:40.411577	cam1	Chum Churum	Soju 360ml	0.8179	2415	12chumS	[359,63,133,114]	sold
2025-06-08 06:21:31.411577	cam1	Kura Kura	Easy Ale 330ml	0.836	2416	05kura_eaK	[144,204,235,40]	sold
2025-03-14 06:33:41.411577	cam1	Yakult	1 pack 325ml	0.8281	2417	60yakultK	[300,145,90,192]	sold
2025-07-19 08:38:41.411577	cam1	Chum Churum	Peach 360ml	0.667	2418	12chum_pS	[328,296,101,243]	sold
2025-03-24 14:05:34.411577	cam1	Canard	Session IPA 330ml	0.76	2419	04canard_siK	[379,162,105,210]	added
2025-08-18 11:35:52.411577	cam1	Orang Tua	Intisari Anggur Hijau 620ml	0.922	2420	01ot_hijauintB	[248,221,149,211]	added
2025-05-23 11:31:01.411577	cam1	Corona	Extra 355ml	0.9312	2421	47corona_eS	[112,305,101,219]	sold
2025-07-19 02:17:12.411577	cam1	Wija	Blueberry 360ml	0.9768	2422	15wija_bS	[170,259,242,142]	added
2025-09-15 16:02:32.411577	cam1	Kura Kura	Easy Ale 330ml	0.7206	2423	05kura_eaK	[114,182,37,226]	added
2025-11-12 22:31:39.411577	cam1	Royal Brewhouse	Black Royale 350ml	0.9299	2424	18rb_brS	[118,14,88,181]	added
2025-12-09 15:25:34.411577	cam1	Three Peaks	Dry Gin 700ml	0.9315	2425	33threep_dgB	[18,277,77,198]	sold
2025-06-29 00:07:51.411577	cam1	Rajawali	Prost 620ml	0.6532	2426	19rajawali_prostB	[173,183,124,209]	added
2025-03-16 18:45:24.411577	cam1	Sababay	Black Velvet 750ml	0.7818	2427	02sababay_bvB	[75,163,181,42]	sold
2025-03-18 15:38:49.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.692	2428	23palapaB	[313,224,109,100]	restock
2025-04-10 17:24:13.411577	cam1	Canard	Porter 330ml	0.6595	2429	04canard_pK	[166,68,45,211]	restock
2025-06-03 00:37:13.411577	cam1	Sababay	Mascetti 750ml	0.7105	2430	02sababay_masB	[397,83,208,202]	added
2026-01-11 10:41:20.411577	cam1	Vibe	Exotic Lychee 700ml	0.7627	2431	11vibe_elB	[380,230,242,200]	restock
2025-12-27 07:54:31.411577	cam1	Sababay	Black Velvet 750ml	0.7892	2432	02sababay_bvB	[377,190,90,250]	restock
2025-05-10 21:27:10.411577	cam1	Royal Brewhouse	Black Royale 350ml	0.9437	2433	18rb_brS	[129,37,246,162]	restock
2026-01-03 05:46:42.411577	cam1	Captain Morgan	Spice Gold 750ml	0.7671	2434	35cm_sgB	[373,127,103,149]	sold
2026-01-02 00:42:14.411577	cam1	Iceland	Orange 700ml	0.7887	2435	03iceland_oB	[62,207,42,73]	added
2026-02-10 16:11:53.411577	cam1	Iceland	Original 250ml	0.8678	2436	03icelandK	[32,204,245,47]	added
2025-04-18 14:46:06.411577	cam1	Santai	Lemon & Lime 330ml	0.9141	2437	14santai_llK	[193,213,202,93]	restock
2025-07-04 01:10:01.411577	cam1	Rajawali	Prost 620ml	0.6962	2438	19rajawali_prostB	[145,54,168,114]	added
2026-02-27 21:45:50.411577	cam1	Kura Kura	IPA 330ml	0.9669	2439	05kura_ipaK	[32,121,235,127]	added
2026-02-11 22:15:49.411577	cam1	Kura Kura	IPA 330ml	0.6771	2440	05kura_ipaK	[399,215,45,230]	restock
2026-01-19 18:41:08.411577	cam1	Iceland	Berry Lemonade 275ml	0.7861	2441	03iceland_beleS	[163,379,72,84]	added
2025-06-22 09:48:03.411577	cam1	Chum Churum	Yogurt 360ml	0.7506	2442	12chum_yS	[150,357,178,101]	sold
2025-04-02 23:58:38.411577	cam1	Bintang	Pilsener 330ml	0.6704	2443	06bintangK	[258,110,219,166]	restock
2025-11-19 07:21:16.411577	cam1	Canard	Weizenbock 330ml	0.7385	2444	04canard_weK	[215,111,138,30]	added
2025-04-04 12:44:48.411577	cam1	Canard	Session IPA 330ml	0.6886	2445	04canard_siK	[79,164,126,34]	sold
2025-04-19 05:45:34.411577	cam1	Wija	Soju 360ml	0.8528	2446	15wijaS	[15,39,180,198]	sold
2025-08-24 06:58:57.411577	cam1	Canard	Kolsch 330ml	0.8621	2447	04canard_kK	[100,46,84,227]	sold
2025-12-06 07:51:57.411577	cam1	Baileys	Irish Cream 750ml	0.7476	2448	51baileys_icB	[176,25,61,140]	sold
2025-04-22 15:13:09.411577	cam1	Orang Tua	Singaraja 620ml	0.9473	2449	01ot_singarajaB	[285,178,94,54]	restock
2025-06-13 10:13:43.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.8331	2450	01ot_apihjB	[331,90,33,78]	sold
2025-10-20 22:31:02.411577	cam1	Gordon's	PinkPremium 750ml	0.6744	2451	44gordon_ppB	[387,156,148,219]	added
2025-04-16 16:14:43.411577	cam1	Sprite	390ml	0.8407	2452	59spriteK	[122,182,97,69]	sold
2026-01-10 01:26:53.411577	cam1	Bintang	Pilsener 500ml	0.7924	2453	06bintangBC	[295,338,189,94]	restock
2026-01-10 18:33:14.411577	cam1	Jose Cuervo	750ml	0.8033	2454	50josecuervoB	[108,71,75,178]	sold
2025-10-19 14:19:18.411577	cam1	Vibe	Black Tea 700ml	0.8965	2455	11vibe_btB	[360,188,204,176]	sold
2026-02-20 17:24:00.411577	cam1	Crystalline	330ml	0.7464	2456	55crystalinK	[186,190,180,93]	added
2025-05-12 12:17:22.411577	cam1	Chum Churum	Yogurt 360ml	0.9797	2457	12chum_yS	[332,142,46,132]	added
2025-08-16 04:32:19.411577	cam1	Wija	Lychee 360ml	0.7366	2458	15wija_lS	[92,195,135,53]	added
2025-06-02 03:55:58.411577	cam1	Guiness	Foreign Extra Stout 320ml	0.6733	2459	34guinessK_fesKC	[135,345,118,224]	restock
2025-05-09 22:26:07.411577	cam1	Kura Kura	Easy Ale 330ml	0.786	2460	05kura_eaK	[62,267,223,63]	added
2025-08-05 03:13:22.411577	cam1	Iceland	Blue Lagoon 275ml	0.8906	2461	03iceland_blS	[292,286,79,206]	restock
2025-12-09 00:01:34.411577	cam1	Guiness	Foreign Extra Stout 620ml	0.6596	2462	34guiness_fesB	[252,137,123,199]	sold
2025-09-21 08:43:51.411577	cam1	Chum Churum	Soju 360ml	0.8564	2463	12chumS	[18,383,47,116]	added
2025-04-18 08:54:43.411577	cam1	Iceland	Orange 700ml	0.7008	2464	03iceland_oB	[212,25,239,113]	added
2025-03-13 19:55:09.411577	cam1	Albens	Apple Lychee Cider 330ml	0.6742	2465	07albens_alcS	[379,76,224,199]	restock
2026-01-26 04:53:07.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.808	2466	10kawa_merahB	[278,169,226,219]	sold
2025-04-19 05:32:10.411577	cam1	Bintang	Pilsener 330ml	0.7393	2467	06bintangK	[80,89,32,57]	restock
2025-09-12 11:22:14.411577	cam1	Sababay	Mascetti 750ml	0.8713	2468	02sababay_masB	[264,319,30,116]	sold
2025-04-22 01:19:31.411577	cam1	Bullsit	Whisky 500ml	0.9148	2469	16bullsit_wS	[216,166,151,114]	sold
2025-11-20 10:24:16.411577	cam1	Gilbey's	Gin 350ml	0.6887	2470	37gilbeys_gS	[392,106,78,150]	sold
2025-06-28 02:31:52.411577	cam1	Sprite	390ml	0.8928	2471	59spriteK	[388,244,86,172]	added
2025-11-25 20:42:06.411577	cam1	Orang Tua	Singaraja 620ml	0.7931	2472	01ot_singarajaB	[300,67,189,55]	added
2025-07-23 02:33:12.411577	cam1	Vibe	Black Tea 700ml	0.9749	2473	11vibe_btB	[61,342,74,156]	added
2025-09-21 22:40:21.411577	cam1	Guiness	Foreign Extra Stout 320ml	0.6859	2474	34guinessK_fesKC	[342,122,146,44]	sold
2025-09-11 17:04:33.411577	cam1	Asahi	Super Dry 334ml	0.8968	2475	48asahiK	[130,16,150,141]	added
2025-05-13 18:16:14.411577	cam1	Sababay	Mascetti 750ml	0.8622	2476	02sababay_masB	[220,308,111,243]	sold
2025-09-08 17:48:25.411577	cam1	Extra Joss	Ultimate 250ml	0.9101	2477	53extrajK	[73,368,58,163]	restock
2025-10-27 08:29:32.411577	cam1	Wija	Blueberry 360ml	0.9115	2478	15wija_bS	[271,382,161,225]	sold
2025-08-28 04:46:09.411577	cam1	Kulturale	Naganini 330ml	0.7107	2479	09kulturale_nbwK	[258,232,162,162]	restock
2026-02-15 22:34:11.411577	cam1	Orang Tua	Anggur Putih 620ml	0.6609	2480	01ot_aputB	[88,306,76,226]	restock
2025-08-30 21:24:16.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.8858	2481	01ot_amergoldB	[166,200,206,65]	sold
2025-08-02 17:24:48.411577	cam1	Vibe	Exotic Lychee 700ml	0.7454	2482	11vibe_elB	[33,331,217,155]	sold
2026-02-08 04:41:28.411577	cam1	Three Peaks	Dry Gin 700ml	0.8453	2483	33threep_dgB	[138,273,91,77]	sold
2026-02-24 03:35:24.411577	cam1	Captain Morgan	Spice Gold 750ml	0.8968	2484	35cm_sgB	[388,307,72,227]	added
2026-03-04 00:54:11.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.958	2485	14santai_agaK	[81,307,113,125]	sold
2025-03-22 06:39:54.411577	cam1	Bacardi	Spiced Rum 750ml	0.8423	2486	36bacardi_srB	[379,215,105,129]	added
2025-09-07 17:06:41.411577	cam1	Guiness	Foreign Extra Stout 620ml	0.9414	2487	34guiness_fesB	[290,46,43,79]	restock
2025-08-25 03:40:17.411577	cam1	Bacardi	Spiced Rum 750ml	0.7565	2488	36bacardi_srB	[266,259,142,143]	sold
2025-04-24 02:30:06.411577	cam1	Orang Tua	Intisari Blackcurrant 620ml	0.9865	2489	01ot_bcintB	[310,293,243,151]	added
2025-04-28 03:58:11.411577	cam1	Baileys	Irish Cream 750ml	0.888	2490	51baileys_icB	[88,113,100,235]	added
2025-07-28 12:03:20.411577	cam1	Orang Tua	Arak Obat 620ml	0.7362	2491	01ot_aoB	[74,153,156,183]	sold
2025-07-15 03:46:17.411577	cam1	Canard	Session IPA 330ml	0.6683	2492	04canard_siK	[350,77,45,117]	restock
2025-12-03 05:09:03.411577	cam1	Bintang	Pilsener 500ml	0.8998	2493	06bintangBC	[364,280,242,165]	sold
2025-03-21 05:26:47.411577	cam1	Sababay	Black Velvet 750ml	0.9561	2494	02sababay_bvB	[198,360,239,131]	sold
2025-11-19 03:17:02.411577	cam1	Orang Tua	Intisari Anggur Hijau 620ml	0.9673	2495	01ot_hijauintB	[51,278,56,33]	added
2026-01-18 11:22:20.411577	cam1	Baliwein	Anggur Salak 750ml	0.6935	2496	08baliwein_absB	[231,119,195,177]	sold
2025-07-09 21:36:56.411577	cam1	Albens	Apple Cier 330ml	0.7733	2497	07albensS	[238,195,117,98]	sold
2026-03-01 00:03:44.411577	cam1	Bacardi	Carta Blanca 750ml	0.9871	2498	36bacardi_cbB	[258,131,193,91]	added
2025-11-02 03:44:09.411577	cam1	Chum Churum	Yogurt 360ml	0.9841	2499	12chum_yS	[359,268,152,192]	added
2025-12-31 17:13:05.411577	cam1	Iceland	Original 700ml	0.9014	2500	03icelandB	[270,296,51,67]	added
2025-09-26 05:27:32.411577	cam1	Sababay	Ludisia 750ml	0.7007	2501	02sababay_lB	[140,281,136,69]	sold
2025-04-29 16:29:46.411577	cam1	Rajawali	Prost 620ml	0.8305	2502	19rajawali_prostB	[221,365,75,93]	sold
2025-12-31 06:52:23.411577	cam1	Captain Morgan	Spice Gold 750ml	0.882	2503	35cm_sgB	[172,297,229,177]	added
2025-12-24 00:57:44.411577	cam1	Cham Joeun	Lychee 360ml	0.7876	2504	40chamj_lS	[195,218,248,46]	added
2026-02-11 17:13:34.411577	cam1	Smirnoff	Vodka 700ml	0.7093	2505	45smirnoffB	[390,64,165,77]	restock
2025-03-13 23:10:51.411577	cam1	Bintang	Pilsener 620ml	0.7329	2506	06bintangB	[74,399,45,210]	restock
2025-04-09 18:29:57.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.8242	2507	10kawa_hijauB	[348,326,69,47]	added
2025-06-02 20:15:54.411577	cam1	Iceland	Blue Lagoon 275ml	0.6705	2508	03iceland_blS	[247,151,140,150]	added
2025-06-29 20:44:12.411577	cam1	Canard	Porter 330ml	0.8719	2509	04canard_pK	[175,54,206,213]	sold
2025-04-01 21:18:28.411577	cam1	Jagermeister	700ml	0.8837	2510	42jagermeisterB	[49,78,134,120]	sold
2025-06-05 15:50:22.411577	cam1	Extra Joss	Ultimate 250ml	0.877	2511	53extrajK	[288,237,44,166]	restock
2025-06-17 19:07:50.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.9442	2512	10kawa_merahB	[240,14,245,131]	added
2026-02-07 03:26:57.411577	cam1	Guiness	Foreign Extra Stout 320ml	0.6599	2513	34guinessK_fesKC	[305,141,40,73]	sold
2025-09-20 11:37:51.411577	cam1	Iceland	Lychee Martini 275ml	0.8148	2514	03iceland_lmS	[257,172,194,181]	added
2025-03-27 20:51:30.411577	cam1	Chum Churum	Yogurt 360ml	0.8106	2515	12chum_yS	[174,110,244,194]	added
2025-10-20 15:22:34.411577	cam1	Captain Morgan	Spice Gold 750ml	0.7503	2516	35cm_sgB	[197,381,203,176]	restock
2026-01-15 06:28:16.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.6717	2517	14santai_agaK	[377,375,37,106]	added
2025-04-03 23:00:09.411577	cam1	Sprite	390ml	0.9318	2518	59spriteK	[134,287,200,179]	sold
2025-07-27 07:09:37.411577	cam1	Vibe	Black Tea 700ml	0.7926	2519	11vibe_btB	[325,106,205,243]	sold
2025-03-14 01:57:30.411577	cam1	Canard	Weizenbock 330ml	0.7852	2520	04canard_weK	[348,89,158,53]	added
2025-03-14 20:50:07.411577	cam1	Vibe	Exotic Lychee 700ml	0.8753	2521	11vibe_elB	[351,34,145,172]	added
2025-10-03 20:06:37.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.7326	2522	01ot_apihjB	[124,326,183,183]	restock
2025-09-24 14:23:53.411577	cam1	Jagermeister	700ml	0.8478	2523	42jagermeisterB	[338,22,163,189]	sold
2025-12-27 13:27:05.411577	cam1	Jameson	Irish Whiskey 700ml	0.9472	2524	41jamesonB	[161,349,97,100]	sold
2025-05-07 07:28:30.411577	cam1	Bullsit	Whisky 500ml	0.7046	2525	16bullsit_wS	[394,128,241,103]	sold
2025-03-19 10:28:56.411577	cam1	Orang Tua	Anggur Merah 620ml	0.9219	2526	01ot_amerB	[364,80,169,100]	sold
2025-06-05 09:30:31.411577	cam1	Wija	Soju 360ml	0.7153	2527	15wijaS	[382,140,197,70]	added
2025-04-01 02:58:44.411577	cam1	Kulturale	N. R. K. DIPA 330ml	0.8737	2528	09kulturale_nrkK	[65,280,55,31]	restock
2025-12-15 14:11:54.411577	cam1	Canard	Kolsch 330ml	0.8525	2529	04canard_kK	[23,337,88,211]	restock
2026-01-13 13:19:33.411577	cam1	Bullsit	Whisky 500ml	0.8531	2530	16bullsit_wS	[46,354,207,142]	added
2025-04-22 13:15:44.411577	cam1	Sapporo	330ml	0.9201	2531	49sapporoK	[310,14,104,228]	sold
2026-02-02 18:02:42.411577	cam1	Iceland	Original 250ml	0.9277	2532	03icelandK	[251,209,240,207]	added
2025-07-01 08:54:16.411577	cam1	Rajawali	Prost 620ml	0.8617	2533	19rajawali_prostB	[220,103,147,113]	added
2026-01-17 17:57:08.411577	cam1	Vibe	Black Tea 700ml	0.8487	2534	11vibe_btB	[116,94,50,56]	restock
2026-02-02 18:11:44.411577	cam1	Pu Tao Chee Chiew	330ml	0.8582	2535	31putaoccS	[190,195,107,234]	sold
2025-10-30 17:01:51.411577	cam1	Kulturale	N. R. K. DIPA 330ml	0.7194	2536	09kulturale_nrkK	[143,162,71,200]	added
2026-03-04 00:24:49.411577	cam1	Orang Tua	Intisari Anggur Hijau 620ml	0.6746	2537	01ot_hijauintB	[395,321,232,227]	sold
2025-07-04 06:33:14.411577	cam1	Iceland	Blue Lagoon 275ml	0.7863	2538	03iceland_blS	[147,192,189,205]	sold
2025-11-19 14:49:06.411577	cam1	Orang Tua	Singaraja 620ml	0.8743	2539	01ot_singarajaB	[337,241,217,41]	added
2025-10-04 16:44:44.411577	cam1	Canard	Strawberry Gose 330ml	0.667	2540	04canard_sgK	[37,32,171,133]	sold
2025-11-16 12:17:11.411577	cam1	Cham Joeun	Soju 360ml	0.6953	2541	40chamjS	[112,191,226,180]	restock
2026-02-23 18:48:36.411577	cam1	Baileys	Irish Cream 750ml	0.6953	2542	51baileys_icB	[127,365,110,84]	restock
2025-06-17 17:56:16.411577	cam1	Drum	Whisky Black 700ml	0.7985	2543	22drum_wbB	[207,387,76,187]	added
2025-07-25 16:31:19.411577	cam1	Jose Cuervo	750ml	0.7167	2544	50josecuervoB	[291,152,91,109]	sold
2025-12-18 20:53:53.411577	cam1	Vibe	Exotic Lychee 700ml	0.7272	2545	11vibe_elB	[389,353,166,78]	sold
2025-03-13 21:41:50.411577	cam1	Baliwein	Semara 750ml	0.8672	2546	08baliwein_semB	[377,81,107,210]	sold
2025-09-07 01:02:45.411577	cam1	Orang Tua	Anggur Merah 275ml	0.7398	2547	01ot_amerS	[366,314,150,30]	added
2025-03-15 10:37:07.411577	cam1	Orang Tua	Anggur Merah 620ml	0.7625	2548	01ot_amerB	[336,179,84,71]	sold
2025-06-27 02:53:02.411577	cam1	Orang Tua	Arak Obat 620ml	0.7349	2549	01ot_aoB	[68,338,194,57]	sold
2025-10-11 01:54:00.411577	cam1	Orang Tua	Arak Obat 620ml	0.7015	2550	01ot_aoB	[73,383,41,57]	added
2025-09-18 15:07:10.411577	cam1	Rajawali	Prost 620ml	0.9853	2551	19rajawali_prostB	[121,261,92,54]	sold
2025-10-09 05:17:21.411577	cam1	Canard	Weizenbock 330ml	0.7293	2552	04canard_weK	[255,268,53,205]	restock
2025-08-21 12:54:15.411577	cam1	Kulturale	L. L. Stout 330ml	0.9114	2553	09kulturale_llsK	[354,298,113,53]	sold
2026-02-11 03:57:39.411577	cam1	Sprite	390ml	0.6662	2554	59spriteK	[27,175,60,242]	added
2025-06-25 15:02:27.411577	cam1	Pu Tao Chee Chiew	330ml	0.8047	2555	31putaoccS	[310,338,83,59]	sold
2026-02-07 07:13:43.411577	cam1	Beaches	Cerveza 330ml	0.9381	2556	32beachescK	[330,335,153,99]	restock
2025-05-12 18:43:51.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.9822	2557	10kawa_bcB	[135,69,132,174]	restock
2025-06-17 05:41:03.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.9771	2558	01ot_amergoldB	[395,155,133,194]	sold
2025-11-19 13:57:41.411577	cam1	Santai	Lemon & Lime 330ml	0.8754	2559	14santai_llK	[315,325,125,154]	added
2025-06-03 13:50:06.411577	cam1	Asahi	Super Dry 334ml	0.9711	2560	48asahiK	[181,325,105,53]	sold
2025-05-10 10:38:37.411577	cam1	Asahi	Super Dry 334ml	0.8312	2561	48asahiK	[365,13,93,195]	added
2025-11-27 05:09:02.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.7769	2562	01ot_amergoldB	[39,387,158,45]	restock
2025-12-23 03:27:31.411577	cam1	Kulturale	L. L. Stout 330ml	0.8661	2563	09kulturale_llsK	[68,140,107,109]	sold
2025-09-24 03:56:36.411577	cam1	Orang Tua	Intisari Blackcurrant 620ml	0.9033	2564	01ot_bcintB	[128,244,101,210]	restock
2025-04-21 13:27:04.411577	cam1	Captain Morgan	Silver Rum 750ml	0.9509	2565	35cm_ssB	[93,368,123,98]	sold
2025-10-04 17:52:54.411577	cam1	Sapporo	330ml	0.8029	2566	49sapporoK	[94,291,237,54]	restock
2025-12-21 08:18:05.411577	cam1	Heineken	330ml	0.7067	2567	46heinekenS	[269,171,103,202]	sold
2025-08-04 01:08:04.411577	cam1	Gilbey's	Whisky 350ml	0.789	2568	37gilbeys_wS	[68,34,44,232]	restock
2025-03-13 05:00:37.411577	cam1	Kulturale	L. L. Stout 330ml	0.9289	2569	09kulturale_llsK	[178,287,208,126]	restock
2025-06-04 07:45:51.411577	cam1	Sababay	Mascetti 750ml	0.8528	2570	02sababay_masB	[299,280,78,203]	sold
2025-08-12 22:50:55.411577	cam1	Albens	Apple Lychee Cider 330ml	0.8376	2571	07albens_alcS	[52,92,36,209]	sold
2025-07-04 22:02:39.411577	cam1	Orang Tua	Anggur Merah 620ml	0.6669	2572	01ot_amerB	[79,159,140,151]	added
2025-06-30 23:13:05.411577	cam1	Bacardi	Carta Blanca 750ml	0.6775	2573	36bacardi_cbB	[140,183,55,159]	added
2025-10-01 02:17:44.411577	cam1	Albens	Apple Mango Cider 330ml	0.8528	2574	07albens_amcS	[25,38,92,40]	sold
2025-12-24 18:01:12.411577	cam1	Royal Brewhouse	Gold Royale 350ml	0.919	2575	18rb_grS	[117,319,235,66]	sold
2025-06-19 15:26:05.411577	cam1	Bacardi	Carta Blanca 750ml	0.9376	2576	36bacardi_cbB	[137,225,200,58]	restock
2026-02-16 04:51:27.411577	cam1	Captain Morgan	Silver Rum 750ml	0.8455	2577	35cm_ssB	[93,331,108,56]	added
2026-01-31 05:14:32.411577	cam1	Suntory Roku	Gin 700ml	0.7523	2578	43rokuB	[132,192,163,164]	sold
2025-07-06 19:46:24.411577	cam1	Orang Tua	Intisari Anggur Hijau 620ml	0.7004	2579	01ot_hijauintB	[321,115,40,200]	restock
2025-10-22 23:09:26.411577	cam1	Bacardi	Carta Blanca 750ml	0.9522	2580	36bacardi_cbB	[185,99,210,211]	added
2025-10-14 09:55:46.411577	cam1	Canard	Weizenbock 330ml	0.8556	2581	04canard_weK	[163,389,188,92]	sold
2025-03-13 22:45:16.411577	cam1	Orang Tua	Arak Obat 620ml	0.7021	2582	01ot_aoB	[30,143,117,107]	sold
2025-03-13 02:49:03.411577	cam1	Bintang	Pilsener 620ml	0.71	2583	06bintangB	[394,118,61,184]	restock
2025-07-12 15:48:09.411577	cam1	Crystalline	330ml	0.7352	2584	55crystalinK	[35,234,170,168]	added
2025-04-03 06:19:23.411577	cam1	Kulturale	Amarillo 330ml	0.7913	2585	09kulturale_aK	[38,358,197,128]	sold
2026-02-11 01:04:52.411577	cam1	Albens	Apple Lychee Cider 330ml	0.9814	2586	07albens_alcS	[131,351,135,160]	sold
2025-12-31 03:43:06.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.9458	2587	23palapaB	[118,163,55,121]	sold
2025-11-20 15:45:32.411577	cam1	Kura Kura	Lager 330ml	0.8717	2588	05kura_lK	[273,81,178,53]	added
2025-11-22 00:47:12.411577	cam1	Guiness	Draught Stout 500ml	0.6887	2589	34guiness_dsBC	[340,360,65,216]	restock
2025-10-13 23:27:49.411577	cam1	Sapporo	330ml	0.659	2590	49sapporoK	[211,192,217,46]	restock
2025-12-17 03:32:57.411577	cam1	Pokka	Green Tea 300ml	0.9328	2591	57pokkaK	[230,55,104,92]	restock
2025-05-22 04:31:39.411577	cam1	Beaches	Cerveza 330ml	0.706	2592	32beachescK	[32,284,209,60]	added
2025-10-04 09:14:49.411577	cam1	New City	1L	0.7043	2593	24newcityB	[39,179,142,99]	restock
2025-07-30 08:26:28.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.919	2594	01ot_apihjB	[95,361,131,125]	restock
2025-10-13 08:40:35.411577	cam1	Albens	Apple Lychee Cider 330ml	0.6765	2595	07albens_alcS	[210,367,240,88]	added
2025-09-25 19:08:55.411577	cam1	Albens	Apple Mango Cider 330ml	0.7728	2596	07albens_amcS	[125,130,150,236]	sold
2025-06-23 04:09:35.411577	cam1	Bacardi	Carta Blanca 750ml	0.7364	2597	36bacardi_cbB	[255,86,82,41]	sold
2025-06-17 10:21:30.411577	cam1	Baliwein	Anggur Salak 750ml	0.9721	2598	08baliwein_absB	[18,132,81,233]	added
2025-04-13 00:30:00.411577	cam1	Wija	Soju 360ml	0.972	2599	15wijaS	[372,195,95,161]	restock
2026-01-13 11:51:35.411577	cam1	Asahi	Super Dry 334ml	0.7454	2600	48asahiK	[247,109,147,201]	sold
2025-08-11 11:24:37.411577	cam1	Gilbey's	Whisky 350ml	0.7998	2601	37gilbeys_wS	[324,360,155,48]	added
2025-10-11 17:19:47.411577	cam1	Orang Tua	Atlas Lychee 620ml	0.7834	2602	01ot_atlaslB	[43,275,176,121]	sold
2025-06-02 03:34:46.411577	cam1	Iceland	Original 700ml	0.7632	2603	03icelandB	[38,146,106,231]	restock
2026-01-23 02:25:54.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.7272	2604	19rajawali_prostalK	[105,147,49,54]	sold
2025-10-18 13:06:58.411577	cam1	Pu Tao Chee Chiew	330ml	0.7425	2605	31putaoccS	[387,215,204,155]	sold
2025-04-28 12:18:48.411577	cam1	Orang Tua	Intisari Blackcurrant 620ml	0.7107	2606	01ot_bcintB	[223,74,47,151]	sold
2025-08-02 22:55:32.411577	cam1	Sababay	Pink Blossom 750ml	0.8151	2607	02sababay_pbB	[55,245,232,239]	sold
2025-05-27 05:00:06.411577	cam1	Heineken	330ml	0.8263	2608	46heinekenS	[324,50,181,37]	added
2025-10-24 06:08:43.411577	cam1	Bintang	Radler 330ml	0.8017	2609	06bintang_radlerS	[320,364,167,63]	sold
2025-10-01 22:46:34.411577	cam1	Orang Tua	Anggur Putih 620ml	0.6617	2610	01ot_aputB	[204,306,245,240]	added
2025-05-23 04:45:26.411577	cam1	Crystalline	330ml	0.9817	2611	55crystalinK	[129,315,33,192]	sold
2026-03-07 21:44:54.411577	cam1	Asahi	Super Dry 334ml	0.9093	2612	48asahiK	[146,45,180,216]	added
2025-05-05 03:09:40.411577	cam1	Bacardi	Spiced Rum 750ml	0.6768	2613	36bacardi_srB	[12,31,60,65]	sold
2025-06-27 08:11:18.411577	cam1	Kura Kura	Session Hazy 330ml	0.8424	2614	05kura_shK	[286,271,101,59]	added
2025-05-30 07:33:17.411577	cam1	Canard	Weizenbock 330ml	0.6632	2615	04canard_weK	[74,393,118,134]	added
2025-07-21 15:32:23.411577	cam1	Gilbey's	Whisky 350ml	0.8243	2616	37gilbeys_wS	[141,90,183,128]	added
2026-01-26 07:06:44.411577	cam1	Canard	Kolsch 330ml	0.8094	2617	04canard_kK	[155,251,150,196]	added
2025-04-28 20:02:54.411577	cam1	Orang Tua	Arak Obat 620ml	0.6816	2618	01ot_aoB	[264,387,105,245]	restock
2025-11-01 21:30:02.411577	cam1	Kulturale	L. L. Stout 330ml	0.8507	2619	09kulturale_llsK	[231,244,140,120]	sold
2026-01-13 12:48:15.411577	cam1	Kulturale	L. L. Stout 330ml	0.6718	2620	09kulturale_llsK	[186,205,127,178]	restock
2025-10-14 01:06:48.411577	cam1	Batavia	Whisky 700ml	0.8286	2621	21bataviaB	[214,267,74,187]	added
2025-12-16 14:25:31.411577	cam1	Albens	Apple Cier 330ml	0.7391	2622	07albensS	[160,136,241,33]	sold
2025-07-10 20:45:01.411577	cam1	Beaches	Cerveza 330ml	0.6941	2623	32beachescK	[266,306,105,215]	sold
2025-07-21 10:36:28.411577	cam1	Chum Churum	Peach 360ml	0.9346	2624	12chum_pS	[231,392,135,214]	restock
2025-11-08 17:25:23.411577	cam1	Canard	Session IPA 330ml	0.8381	2625	04canard_siK	[82,146,39,229]	added
2025-05-27 23:24:49.411577	cam1	Albens	Apple Mango Cider 330ml	0.7931	2626	07albens_amcS	[34,235,142,215]	added
2025-06-05 22:45:49.411577	cam1	Bacardi	Carta Blanca 750ml	0.9051	2627	36bacardi_cbB	[47,29,250,59]	restock
2025-03-30 20:01:21.411577	cam1	Gordon's	PinkPremium 750ml	0.6951	2628	44gordon_ppB	[385,385,77,201]	sold
2025-10-12 18:47:31.411577	cam1	Orang Tua	Arak Obat 620ml	0.7781	2629	01ot_aoB	[71,177,81,76]	restock
2025-11-26 07:19:06.411577	cam1	Iceland	Berry Lemonade 275ml	0.9304	2630	03iceland_beleS	[176,210,250,82]	sold
2025-05-31 10:20:54.411577	cam1	Orang Tua	Anggur Merah 275ml	0.8482	2631	01ot_amerS	[94,164,155,115]	added
2026-01-14 16:15:33.411577	cam1	Sababay	Black Velvet 750ml	0.848	2632	02sababay_bvB	[97,140,106,184]	sold
2025-12-17 22:30:05.411577	cam1	Smirnoff	Vodka 700ml	0.8967	2633	45smirnoffB	[15,137,38,106]	added
2025-05-19 08:12:34.411577	cam1	Orang Tua	Anggur Putih 620ml	0.8212	2634	01ot_aputB	[347,52,101,210]	sold
2026-02-04 02:59:11.411577	cam1	Canard	Weizenbock 330ml	0.6842	2635	04canard_weK	[332,390,37,97]	sold
2025-08-30 14:54:53.411577	cam1	Iceland	Berry Lemonade 275ml	0.8986	2636	03iceland_beleS	[81,64,57,245]	added
2025-05-13 14:28:07.411577	cam1	Sababay	Black Velvet 750ml	0.7361	2637	02sababay_bvB	[97,350,93,169]	sold
2025-05-28 19:09:58.411577	cam1	Orang Tua	Anggur Putih 620ml	0.709	2638	01ot_aputB	[230,182,209,228]	added
2026-01-13 13:54:47.411577	cam1	Cham Joeun	Soju 360ml	0.7703	2639	40chamjS	[307,85,104,250]	added
2026-03-04 04:41:57.411577	cam1	Bintang	Radler 330ml	0.6644	2640	06bintang_radlerS	[120,383,168,118]	sold
2025-05-14 04:59:21.411577	cam1	Asahi	Super Dry 334ml	0.7287	2641	48asahiK	[33,392,206,49]	sold
2025-07-17 14:54:56.411577	cam1	Sababay	Ludisia 750ml	0.8989	2642	02sababay_lB	[322,28,86,80]	added
2026-01-22 08:41:17.411577	cam1	Kulturale	Naganini 330ml	0.6883	2643	09kulturale_nbwK	[105,271,228,190]	restock
2025-09-21 14:53:50.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.898	2644	10kawa_merahB	[152,162,176,177]	sold
2026-01-24 16:33:58.411577	cam1	Bullsit	Whisky 500ml	0.842	2645	16bullsit_wS	[45,77,212,71]	restock
2025-05-26 06:43:10.411577	cam1	Batavia	Whisky 700ml	0.6981	2646	21bataviaB	[38,152,190,120]	restock
2025-11-13 01:19:34.411577	cam1	Chum Churum	Peach 360ml	0.7407	2647	12chum_pS	[295,236,198,166]	sold
2025-12-29 23:02:31.411577	cam1	Gilbey's	Gin 350ml	0.9305	2648	37gilbeys_gS	[305,354,249,69]	restock
2025-11-30 04:20:32.411577	cam1	Extra Joss	Ultimate 250ml	0.7535	2649	53extrajK	[101,13,61,126]	restock
2025-11-18 23:37:26.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.8839	2650	19rajawali_prostalK	[19,17,30,99]	sold
2025-03-21 01:02:14.411577	cam1	Sababay	Pink Blossom 750ml	0.8054	2651	02sababay_pbB	[383,359,196,178]	sold
2025-03-19 00:15:17.411577	cam1	Kura Kura	Session Hazy 330ml	0.9456	2652	05kura_shK	[333,17,188,130]	added
2026-02-09 03:02:18.411577	cam1	Extra Joss	Ultimate 250ml	0.8486	2653	53extrajK	[380,182,180,73]	restock
2025-08-04 05:18:11.411577	cam1	Baliwein	Semara 750ml	0.9515	2654	08baliwein_semB	[351,97,31,146]	sold
2025-09-09 11:40:28.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.8835	2655	01ot_amergoldB	[123,398,173,51]	added
2026-02-27 05:33:51.411577	cam1	Kura Kura	Session Hazy 330ml	0.906	2656	05kura_shK	[10,155,241,183]	added
2025-10-01 00:37:13.411577	cam1	Bacardi	Carta Blanca 750ml	0.7756	2657	36bacardi_cbB	[178,299,34,238]	added
2025-09-05 13:30:06.411577	cam1	Wija	Soju 360ml	0.9734	2658	15wijaS	[107,253,154,226]	sold
2026-01-29 20:12:01.411577	cam1	Vibe	Black Tea 700ml	0.7526	2659	11vibe_btB	[35,375,222,242]	sold
2025-07-29 10:23:59.411577	cam1	Bacardi	Spiced Rum 750ml	0.7555	2660	36bacardi_srB	[376,260,42,222]	added
2025-12-30 23:49:02.411577	cam1	Captain Morgan	Silver Rum 750ml	0.8394	2661	35cm_ssB	[71,372,45,180]	sold
2025-10-25 04:10:54.411577	cam1	Sababay	Black Velvet 750ml	0.8224	2662	02sababay_bvB	[375,108,230,106]	sold
2025-05-07 10:45:12.411577	cam1	Sababay	Black Velvet 750ml	0.8414	2663	02sababay_bvB	[16,160,172,206]	added
2025-04-17 22:17:30.411577	cam1	Chum Churum	Peach 360ml	0.715	2664	12chum_pS	[312,305,240,94]	sold
2026-02-21 14:08:52.411577	cam1	Guiness	Foreign Extra Stout 320ml	0.9436	2665	34guinessK_fesKC	[334,343,40,97]	added
2025-11-07 13:28:08.411577	cam1	Wija	Lychee 360ml	0.8726	2666	15wija_lS	[71,363,35,237]	sold
2025-03-19 11:10:17.411577	cam1	Sprite	390ml	0.8845	2667	59spriteK	[65,190,216,114]	added
2025-11-14 15:06:50.411577	cam1	Sababay	Mascetti 750ml	0.9332	2668	02sababay_masB	[148,35,195,41]	sold
2025-03-25 01:12:03.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.7543	2669	01ot_apihjB	[58,385,153,156]	added
2025-07-08 00:00:14.411577	cam1	Orang Tua	Arak Obat 620ml	0.8124	2670	01ot_aoB	[372,375,148,249]	added
2025-09-29 18:25:22.411577	cam1	Crystalline	330ml	0.9531	2671	55crystalinK	[41,250,234,160]	added
2025-12-26 19:31:48.411577	cam1	Jagermeister	700ml	0.8587	2672	42jagermeisterB	[319,234,122,56]	restock
2025-06-27 14:41:34.411577	cam1	Iceland	Lychee Martini 275ml	0.7468	2673	03iceland_lmS	[22,74,102,180]	sold
2025-04-08 06:54:46.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.6796	2674	14santai_agaK	[385,252,65,150]	sold
2025-05-17 03:54:22.411577	cam1	Drum	Whisky Black 700ml	0.8945	2675	22drum_wbB	[27,356,72,38]	added
2025-09-11 16:18:06.411577	cam1	Iceland	Lychee Martini 275ml	0.7159	2676	03iceland_lmS	[115,278,235,165]	sold
2026-01-04 22:33:47.411577	cam1	Captain Morgan	Silver Rum 750ml	0.7263	2677	35cm_ssB	[119,127,154,61]	added
2025-09-10 01:55:27.411577	cam1	Santai	Lemon & Lime 330ml	0.6547	2678	14santai_llK	[200,379,182,209]	sold
2025-05-09 20:28:34.411577	cam1	Cham Joeun	Soju 360ml	0.7333	2679	40chamjS	[194,66,147,45]	sold
2026-01-16 20:11:25.411577	cam1	Kura Kura	Island Ale 330ml	0.6863	2680	05kura_iaK	[191,96,30,199]	sold
2025-08-06 10:13:27.411577	cam1	Kura Kura	IPA 330ml	0.6714	2681	05kura_ipaK	[162,76,232,197]	added
2025-09-23 12:36:33.411577	cam1	Yakult	1 pack 325ml	0.8752	2682	60yakultK	[94,185,133,89]	sold
2025-09-24 01:17:08.411577	cam1	Bintang	Pilsener 330ml	0.8414	2683	06bintangK	[115,192,157,48]	added
2025-12-25 20:29:08.411577	cam1	Guiness	Draught Stout 500ml	0.7053	2684	34guiness_dsBC	[168,25,206,134]	restock
2025-10-25 08:50:45.411577	cam1	Baileys	Irish Cream 750ml	0.936	2685	51baileys_icB	[262,214,181,241]	added
2025-12-30 16:22:42.411577	cam1	Chum Churum	Peach 360ml	0.9734	2686	12chum_pS	[201,232,238,170]	added
2025-12-26 08:40:38.411577	cam1	Smirnoff	Vodka 700ml	0.9092	2687	45smirnoffB	[358,340,124,174]	added
2025-11-26 16:59:51.411577	cam1	Cham Joeun	Soju 360ml	0.9016	2688	40chamjS	[325,317,146,148]	added
2025-03-30 14:34:18.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.6975	2689	19rajawali_prostalK	[137,34,88,141]	sold
2025-07-01 20:40:11.411577	cam1	Cham Joeun	Lychee 360ml	0.7092	2690	40chamj_lS	[75,339,153,192]	sold
2025-04-10 08:50:51.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.9016	2691	01ot_apihjB	[225,74,136,49]	restock
2025-12-03 15:59:28.411577	cam1	Kulturale	N. R. K. DIPA 330ml	0.9028	2692	09kulturale_nrkK	[174,21,152,107]	added
2026-01-27 16:46:11.411577	cam1	Suntory Roku	Gin 700ml	0.6678	2693	43rokuB	[239,295,102,62]	sold
2025-04-26 23:21:42.411577	cam1	Heineken	330ml	0.8605	2694	46heinekenS	[124,325,107,37]	sold
2025-10-14 23:57:36.411577	cam1	Guiness	Draught Stout 500ml	0.9471	2695	34guiness_dsBC	[67,122,202,77]	added
2025-07-03 16:03:42.411577	cam1	Bullsit	Gin 500ml	0.9834	2696	16bullsit_gS	[286,46,164,130]	restock
2025-12-11 07:12:42.411577	cam1	Bullsit	Vodka 500ml	0.7964	2697	16bullsit_vS	[33,44,172,184]	added
2025-04-25 11:59:22.411577	cam1	Bullsit	Vodka 500ml	0.6888	2698	16bullsit_vS	[110,291,129,187]	sold
2025-07-04 18:07:42.411577	cam1	Corona	Extra 355ml	0.8541	2699	47corona_eS	[157,272,94,131]	restock
2025-11-01 06:34:33.411577	cam1	Canard	Weizenbock 330ml	0.9546	2700	04canard_weK	[395,71,74,151]	sold
2025-03-27 00:57:10.411577	cam1	Canard	Witbier 330ml	0.9424	2701	04canard_wK	[66,137,51,124]	sold
2025-06-08 01:12:21.411577	cam1	Gilbey's	Whisky 350ml	0.8241	2702	37gilbeys_wS	[109,357,195,187]	added
2025-08-12 11:23:19.411577	cam1	Smirnoff	Vodka 700ml	0.9804	2703	45smirnoffB	[43,355,150,75]	sold
2026-02-21 06:03:20.411577	cam1	Orang Tua	Anggur Merah 620ml	0.7272	2704	01ot_amerB	[357,76,71,91]	sold
2025-04-03 15:15:41.411577	cam1	Canard	Kolsch 330ml	0.8194	2705	04canard_kK	[155,196,151,152]	added
2025-07-24 22:31:22.411577	cam1	Canard	Weizenbock 330ml	0.9143	2706	04canard_weK	[98,392,235,37]	added
2025-07-20 20:39:45.411577	cam1	Baliwein	Anggur Salak 750ml	0.7909	2707	08baliwein_absB	[189,209,103,78]	added
2026-01-26 08:05:03.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.7782	2708	23palapaB	[390,397,96,205]	restock
2025-11-27 15:11:10.411577	cam1	Kura Kura	Session Hazy 330ml	0.9391	2709	05kura_shK	[65,269,61,85]	restock
2025-07-28 10:52:22.411577	cam1	Sapporo	330ml	0.7888	2710	49sapporoK	[124,275,102,181]	restock
2025-05-01 12:37:56.411577	cam1	Gordon's	PinkPremium 750ml	0.911	2711	44gordon_ppB	[145,47,114,206]	added
2025-03-18 04:35:06.411577	cam1	Kura Kura	Session Hazy 330ml	0.6928	2712	05kura_shK	[326,100,105,81]	added
2025-04-06 14:45:38.411577	cam1	Orang Tua	Intisari Blackcurrant 620ml	0.6848	2713	01ot_bcintB	[364,67,245,170]	added
2025-06-25 17:15:51.411577	cam1	Crystalline	330ml	0.7229	2714	55crystalinK	[207,55,238,195]	restock
2025-10-15 05:07:24.411577	cam1	Wija	Lychee 360ml	0.8221	2715	15wija_lS	[393,51,198,56]	sold
2025-09-03 13:32:05.411577	cam1	Orang Tua	Anggur Merah 620ml	0.9698	2716	01ot_amerB	[197,233,218,93]	sold
2025-08-05 11:10:27.411577	cam1	Kulturale	Bravo 330ml	0.8506	2717	09kulturale_bK	[270,338,238,85]	restock
2026-01-30 03:47:51.411577	cam1	Bacardi	Spiced Rum 750ml	0.7164	2718	36bacardi_srB	[192,229,97,140]	sold
2025-07-04 18:17:10.411577	cam1	Vibe	Black Tea 700ml	0.6963	2719	11vibe_btB	[293,351,153,42]	added
2025-06-02 22:12:18.411577	cam1	Guiness	Draught Stout 500ml	0.8166	2720	34guiness_dsBC	[342,314,59,237]	restock
2025-10-04 23:03:32.411577	cam1	Three Peaks	Dry Gin 700ml	0.875	2721	33threep_dgB	[66,12,161,234]	restock
2025-12-01 13:21:00.411577	cam1	Canard	Weizenbock 330ml	0.6538	2722	04canard_weK	[89,241,107,74]	sold
2025-04-01 21:56:45.411577	cam1	Bintang	Pilsener 500ml	0.8382	2723	06bintangBC	[95,86,91,30]	added
2025-09-25 00:54:05.411577	cam1	Iceland	Original 250ml	0.8808	2724	03icelandK	[233,43,115,107]	added
2025-09-22 12:25:44.411577	cam1	Batavia	Whisky 700ml	0.775	2725	21bataviaB	[371,385,197,44]	restock
2025-06-16 08:46:03.411577	cam1	Gilbey's	Whisky 350ml	0.6594	2726	37gilbeys_wS	[162,116,246,92]	added
2026-02-05 10:26:55.411577	cam1	Cham Joeun	Lychee 360ml	0.8261	2727	40chamj_lS	[202,384,130,215]	sold
2025-12-24 15:13:42.411577	cam1	Albens	Apple Lychee Cider 330ml	0.8604	2728	07albens_alcS	[365,100,181,65]	sold
2025-09-12 13:17:52.411577	cam1	Crystalline	330ml	0.9561	2729	55crystalinK	[20,330,181,72]	sold
2025-09-16 22:16:53.411577	cam1	Albens	Apple Mango Cider 330ml	0.7676	2730	07albens_amcS	[391,249,132,31]	sold
2026-02-13 07:10:21.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.716	2731	01ot_atlasrpB	[293,310,49,158]	sold
2025-05-15 19:48:01.411577	cam1	Baliwein	Sekala 750ml	0.8833	2732	08baliwein_sekB	[220,23,94,87]	added
2025-06-09 19:11:16.411577	cam1	Gilbey's	Whisky 350ml	0.7156	2733	37gilbeys_wS	[271,262,77,123]	restock
2025-08-19 21:06:47.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.9617	2734	23palapaB	[41,161,89,78]	added
2025-07-16 03:30:32.411577	cam1	Three Peaks	Dry Gin 700ml	0.7522	2735	33threep_dgB	[221,237,94,141]	added
2025-05-26 12:28:22.411577	cam1	Guiness	Draught Stout 500ml	0.7089	2736	34guiness_dsBC	[27,388,52,125]	sold
2025-06-24 22:32:45.411577	cam1	Captain Morgan	Spice Gold 750ml	0.8674	2737	35cm_sgB	[188,266,129,59]	added
2025-09-30 05:09:27.411577	cam1	Baliwein	Semara 750ml	0.7525	2738	08baliwein_semB	[210,259,88,200]	added
2025-12-28 16:04:33.411577	cam1	Canard	Strawberry Gose 330ml	0.8034	2739	04canard_sgK	[220,67,57,204]	added
2025-08-23 00:06:58.411577	cam1	Captain Morgan	Silver Rum 750ml	0.8121	2740	35cm_ssB	[293,322,142,82]	sold
2025-04-16 21:38:58.411577	cam1	Chum Churum	Yogurt 360ml	0.6874	2741	12chum_yS	[206,95,63,243]	restock
2025-09-19 03:48:07.411577	cam1	Captain Morgan	Spice Gold 750ml	0.6744	2742	35cm_sgB	[395,303,169,145]	sold
2026-02-14 04:33:47.411577	cam1	Cham Joeun	Lychee 360ml	0.7562	2743	40chamj_lS	[278,375,85,154]	added
2025-05-27 17:54:53.411577	cam1	Orang Tua	Intisari Blackcurrant 620ml	0.7691	2744	01ot_bcintB	[250,75,156,180]	sold
2025-11-04 19:33:59.411577	cam1	Drum	Whisky Black 700ml	0.7919	2745	22drum_wbB	[339,157,198,179]	restock
2025-03-16 04:32:38.411577	cam1	Iceland	Original 700ml	0.7765	2746	03icelandB	[257,309,177,115]	added
2025-11-03 06:48:53.411577	cam1	Polaris	Soda Water 330ml	0.7118	2747	54polarisK	[36,343,159,188]	sold
2025-08-16 21:18:30.411577	cam1	Baliwein	Sekala 750ml	0.8344	2748	08baliwein_sekB	[227,122,52,232]	added
2026-02-11 02:07:01.411577	cam1	Bacardi	Spiced Rum 750ml	0.7322	2749	36bacardi_srB	[385,387,103,146]	added
2025-07-06 03:32:54.411577	cam1	Asahi	Super Dry 334ml	0.9144	2750	48asahiK	[353,162,121,137]	added
2025-10-23 03:12:36.411577	cam1	Bullsit	Vodka 500ml	0.7097	2751	16bullsit_vS	[329,74,246,50]	added
2025-10-10 03:40:45.411577	cam1	Cham Joeun	Soju 360ml	0.7448	2752	40chamjS	[281,125,124,243]	restock
2025-06-11 14:55:54.411577	cam1	Kura Kura	Easy Ale 330ml	0.8011	2753	05kura_eaK	[304,183,132,54]	added
2025-10-11 19:39:18.411577	cam1	Iceland	Orange 700ml	0.811	2754	03iceland_oB	[270,312,245,71]	added
2026-02-01 11:44:42.411577	cam1	Extra Joss	Ultimate 250ml	0.9223	2755	53extrajK	[167,256,234,226]	sold
2025-04-10 02:31:35.411577	cam1	Chum Churum	Yogurt 360ml	0.7765	2756	12chum_yS	[259,254,109,189]	restock
2026-02-26 20:04:07.411577	cam1	Wija	Blueberry 360ml	0.7021	2757	15wija_bS	[337,282,85,129]	sold
2026-01-03 05:22:12.411577	cam1	New City	1L	0.7709	2758	24newcityB	[250,105,146,160]	sold
2025-11-17 01:14:53.411577	cam1	Chum Churum	Peach 360ml	0.8938	2759	12chum_pS	[251,259,65,62]	added
2025-08-05 05:42:48.411577	cam1	Chum Churum	Peach 360ml	0.6689	2760	12chum_pS	[293,275,126,208]	restock
2025-09-25 14:16:45.411577	cam1	Bullsit	Whisky 500ml	0.9885	2761	16bullsit_wS	[276,397,200,131]	sold
2025-05-30 07:42:21.411577	cam1	Bacardi	Spiced Rum 750ml	0.7088	2762	36bacardi_srB	[280,296,131,50]	added
2025-05-16 23:46:05.411577	cam1	Cham Joeun	Soju 360ml	0.8928	2763	40chamjS	[200,136,215,166]	added
2025-04-21 07:52:59.411577	cam1	Bullsit	Gin 500ml	0.7714	2764	16bullsit_gS	[275,23,35,98]	restock
2025-05-10 10:55:54.411577	cam1	Sababay	Mascetti 750ml	0.9496	2765	02sababay_masB	[107,234,94,162]	restock
2025-06-12 20:52:12.411577	cam1	Albens	Apple Cier 330ml	0.8518	2766	07albensS	[75,180,105,170]	sold
2025-07-13 20:31:07.411577	cam1	Crystalline	330ml	0.9177	2767	55crystalinK	[184,319,86,93]	sold
2025-10-07 11:17:50.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.9433	2768	01ot_atlasrpB	[277,213,239,127]	restock
2026-01-12 21:59:26.411577	cam1	Sababay	Pink Blossom 750ml	0.7719	2769	02sababay_pbB	[206,185,249,110]	sold
2025-03-26 20:05:10.411577	cam1	Guiness	Foreign Extra Stout 620ml	0.9238	2770	34guiness_fesB	[315,332,248,246]	added
2025-06-05 18:32:42.411577	cam1	Rajawali	Prost 620ml	0.7203	2771	19rajawali_prostB	[63,66,106,162]	added
2025-08-31 05:15:35.411577	cam1	Bintang	Pilsener 500ml	0.7805	2772	06bintangBC	[252,374,182,59]	sold
2025-05-15 01:58:51.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.7655	2773	01ot_apiptB	[157,147,192,160]	restock
2025-09-22 13:30:24.411577	cam1	Kulturale	L. L. Stout 330ml	0.9328	2774	09kulturale_llsK	[354,46,64,54]	restock
2025-10-07 07:09:09.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.8238	2775	01ot_amergoldB	[165,154,122,163]	sold
2025-03-31 16:52:49.411577	cam1	Albens	Apple Cier 330ml	0.8356	2776	07albensS	[310,348,127,204]	added
2026-02-24 07:07:57.411577	cam1	Iceland	Original 250ml	0.8151	2777	03icelandK	[62,333,133,237]	restock
2025-12-19 22:53:47.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.8687	2778	19rajawali_prostalK	[385,246,169,33]	added
2025-08-10 18:41:52.411577	cam1	Canard	Strawberry Gose 330ml	0.652	2779	04canard_sgK	[161,46,213,102]	added
2025-08-17 11:20:49.411577	cam1	Iceland	Berry Lemonade 275ml	0.8762	2780	03iceland_beleS	[360,363,72,171]	sold
2026-01-10 18:02:23.411577	cam1	Pu Tao Chee Chiew	330ml	0.8908	2781	31putaoccS	[272,314,136,209]	sold
2025-04-17 02:03:48.411577	cam1	Baliwein	Sekala 750ml	0.9038	2782	08baliwein_sekB	[256,127,86,204]	sold
2025-09-24 11:13:33.411577	cam1	Orang Tua	Arak Obat 620ml	0.6686	2783	01ot_aoB	[157,383,49,183]	sold
2025-12-04 02:17:35.411577	cam1	Sababay	Pink Blossom 750ml	0.6528	2784	02sababay_pbB	[53,175,30,223]	sold
2025-12-04 19:36:02.411577	cam1	Bacardi	Spiced Rum 750ml	0.9886	2785	36bacardi_srB	[347,94,246,32]	sold
2025-06-02 06:49:15.411577	cam1	Baliwein	Anggur Salak 750ml	0.8676	2786	08baliwein_absB	[274,353,43,67]	sold
2025-08-02 05:41:17.411577	cam1	Drum	Whisky Black 700ml	0.9021	2787	22drum_wbB	[140,86,168,99]	sold
2025-06-01 07:33:30.411577	cam1	Iceland	Blue Lagoon 275ml	0.8553	2788	03iceland_blS	[386,187,138,48]	sold
2025-12-17 12:50:51.411577	cam1	Extra Joss	Ultimate 250ml	0.7803	2789	53extrajK	[101,400,175,54]	sold
2025-06-15 16:41:56.411577	cam1	Corona	Extra 355ml	0.8415	2790	47corona_eS	[246,293,190,119]	restock
2025-07-08 03:56:47.411577	cam1	Extra Joss	Ultimate 250ml	0.7087	2791	53extrajK	[283,336,121,170]	sold
2025-10-15 23:09:53.411577	cam1	Albens	Apple Cier 330ml	0.9827	2792	07albensS	[384,228,91,107]	sold
2025-10-05 20:23:23.411577	cam1	Wija	Soju 360ml	0.7665	2793	15wijaS	[101,108,79,145]	added
2026-03-10 23:19:55.411577	cam1	Canard	Weizenbock 330ml	0.956	2794	04canard_weK	[113,291,104,220]	sold
2025-11-23 12:52:31.411577	cam1	Iceland	Berry Lemonade 275ml	0.8076	2795	03iceland_beleS	[238,106,113,47]	added
2025-11-10 06:42:09.411577	cam1	Albens	Apple Lychee Cider 330ml	0.9344	2796	07albens_alcS	[220,61,69,225]	sold
2025-08-12 04:01:35.411577	cam1	Captain Morgan	Spice Gold 750ml	0.6595	2797	35cm_sgB	[110,58,229,99]	added
2025-09-18 04:33:03.411577	cam1	Captain Morgan	Silver Rum 750ml	0.88	2798	35cm_ssB	[49,345,35,231]	added
2025-05-28 03:03:15.411577	cam1	Three Peaks	Dry Gin 700ml	0.8139	2799	33threep_dgB	[241,301,230,85]	sold
2025-10-17 02:01:12.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.9591	2800	01ot_amergoldB	[278,190,104,131]	added
2025-10-15 04:09:11.411577	cam1	Baileys	Irish Cream 750ml	0.7216	2801	51baileys_icB	[139,283,86,116]	restock
2025-11-14 13:01:31.411577	cam1	Albens	Apple Lychee Cider 330ml	0.7797	2802	07albens_alcS	[43,347,110,233]	sold
2025-12-20 06:04:57.411577	cam1	Three Peaks	Dry Gin 700ml	0.7321	2803	33threep_dgB	[229,67,115,140]	restock
2025-12-06 04:06:01.411577	cam1	Orang Tua	Intisari Blackcurrant 620ml	0.9111	2804	01ot_bcintB	[61,204,157,124]	added
2026-01-11 07:05:07.411577	cam1	Guiness	Foreign Extra Stout 620ml	0.9707	2805	34guiness_fesB	[286,115,99,202]	restock
2025-09-15 05:23:41.411577	cam1	Guiness	Foreign Extra Stout 620ml	0.7169	2806	34guiness_fesB	[350,237,155,47]	added
2025-09-17 13:49:40.411577	cam1	Drum	Whisky Black 700ml	0.7308	2807	22drum_wbB	[121,143,82,68]	added
2026-01-05 20:19:38.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.7444	2808	08baliwein_abjmB	[205,272,181,223]	added
2025-09-03 08:25:33.411577	cam1	Captain Morgan	Spice Gold 750ml	0.6906	2809	35cm_sgB	[43,136,52,81]	added
2025-10-30 04:31:30.411577	cam1	Orang Tua	Arak Obat 620ml	0.9147	2810	01ot_aoB	[258,275,185,202]	sold
2025-07-22 04:29:56.411577	cam1	Kura Kura	Easy Ale 330ml	0.6563	2811	05kura_eaK	[61,55,62,32]	sold
2025-07-21 05:32:45.411577	cam1	Kulturale	Amarillo 330ml	0.911	2812	09kulturale_aK	[147,98,133,54]	restock
2025-05-13 21:05:05.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.6765	2813	01ot_amergoldB	[207,273,105,99]	sold
2025-10-05 18:52:08.411577	cam1	Albens	Apple Mango Cider 330ml	0.8644	2814	07albens_amcS	[354,331,151,200]	restock
2025-05-15 05:25:41.411577	cam1	Drum	Whisky Black 700ml	0.7466	2815	22drum_wbB	[37,135,73,92]	sold
2025-05-23 22:08:41.411577	cam1	New City	1L	0.9029	2816	24newcityB	[191,220,125,206]	added
2025-10-31 13:47:04.411577	cam1	Vibe	Exotic Lychee 700ml	0.8882	2817	11vibe_elB	[157,134,236,127]	sold
2025-06-28 11:18:08.411577	cam1	Yakult	1 pack 325ml	0.7282	2818	60yakultK	[285,117,188,110]	sold
2025-09-11 04:26:06.411577	cam1	Albens	Apple Mango Cider 330ml	0.654	2819	07albens_amcS	[140,32,211,91]	restock
2025-08-28 08:25:55.411577	cam1	Bintang	Pilsener 330ml	0.7089	2820	06bintangK	[178,116,93,65]	sold
2025-11-22 06:23:47.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.7129	2821	10kawa_merahB	[16,200,98,123]	sold
2025-10-28 01:34:43.411577	cam1	Extra Joss	Ultimate 250ml	0.7368	2822	53extrajK	[118,136,149,142]	added
2026-02-15 02:22:17.411577	cam1	Kulturale	Naganini 330ml	0.8506	2823	09kulturale_nbwK	[313,33,241,54]	sold
2025-07-08 06:18:02.411577	cam1	Bacardi	Spiced Rum 750ml	0.7113	2824	36bacardi_srB	[45,175,68,186]	added
2025-08-01 17:13:37.411577	cam1	Sababay	Ludisia 750ml	0.9221	2825	02sababay_lB	[397,162,189,46]	sold
2026-02-21 17:48:48.411577	cam1	Bullsit	Gin 500ml	0.7223	2826	16bullsit_gS	[287,127,218,195]	restock
2025-05-25 14:15:39.411577	cam1	Iceland	Original 250ml	0.7517	2827	03icelandK	[137,395,199,67]	added
2025-10-17 07:08:12.411577	cam1	Sababay	Pink Blossom 750ml	0.7996	2828	02sababay_pbB	[138,384,216,248]	sold
2025-12-18 12:01:20.411577	cam1	Royal Brewhouse	Black Royale 350ml	0.7006	2829	18rb_brS	[96,384,229,118]	added
2025-10-11 09:32:46.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.6958	2830	10kawa_hijauB	[65,332,35,44]	sold
2025-12-14 07:47:47.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.6631	2831	01ot_apihjB	[126,136,153,91]	sold
2025-10-01 01:32:23.411577	cam1	Chum Churum	Soju 360ml	0.7232	2832	12chumS	[345,152,48,178]	sold
2025-08-14 07:13:57.411577	cam1	Corona	Extra 355ml	0.8806	2833	47corona_eS	[226,357,33,62]	added
2025-07-07 03:48:01.411577	cam1	Smirnoff	Vodka 700ml	0.7017	2834	45smirnoffB	[250,251,180,105]	sold
2026-01-12 08:44:58.411577	cam1	Crystalline	330ml	0.8196	2835	55crystalinK	[173,71,175,189]	sold
2026-01-12 23:00:16.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.9626	2836	23palapaB	[252,277,66,85]	sold
2026-03-05 10:54:24.411577	cam1	Albens	Apple Mango Cider 330ml	0.724	2837	07albens_amcS	[152,370,175,79]	sold
2025-08-02 05:28:20.411577	cam1	Chum Churum	Peach 360ml	0.7118	2838	12chum_pS	[85,391,127,189]	restock
2025-12-01 05:25:20.411577	cam1	Bullsit	Whisky 500ml	0.8929	2839	16bullsit_wS	[340,248,67,109]	added
2025-05-06 09:52:32.411577	cam1	Santai	Apple Ginger & Acai 330ml	0.6584	2840	14santai_agaK	[212,211,200,70]	added
2025-11-21 18:26:24.411577	cam1	Bullsit	Whisky 500ml	0.6786	2841	16bullsit_wS	[264,151,49,244]	sold
2025-08-19 14:30:06.411577	cam1	Bintang	Pilsener 620ml	0.7912	2842	06bintangB	[200,207,100,135]	added
2026-01-05 06:11:02.411577	cam1	Iceland	Lychee Martini 275ml	0.8325	2843	03iceland_lmS	[301,387,96,162]	restock
2026-03-11 07:02:45.411577	cam1	Bullsit	Vodka 500ml	0.6532	2844	16bullsit_vS	[183,76,105,197]	added
2026-02-23 15:46:10.411577	cam1	Crystalline	330ml	0.8133	2845	55crystalinK	[314,230,62,161]	added
2025-07-31 04:59:49.411577	cam1	Kulturale	Amarillo 330ml	0.7835	2846	09kulturale_aK	[334,211,137,192]	sold
2025-12-18 11:43:36.411577	cam1	Chum Churum	Soju 360ml	0.6549	2847	12chumS	[38,286,63,138]	sold
2025-10-12 20:28:02.411577	cam1	Wija	Soju 360ml	0.9261	2848	15wijaS	[281,218,206,134]	sold
2025-07-31 14:46:15.411577	cam1	Sapporo	330ml	0.8297	2849	49sapporoK	[90,317,241,226]	restock
2026-01-10 23:16:50.411577	cam1	Kura Kura	Session Hazy 330ml	0.6788	2850	05kura_shK	[232,393,246,216]	added
2025-11-23 17:03:42.411577	cam1	Orang Tua	Anggur Putih 620ml	0.6814	2851	01ot_aputB	[61,381,113,106]	sold
2025-05-23 12:28:07.411577	cam1	Guiness	Foreign Extra Stout 620ml	0.8332	2852	34guiness_fesB	[211,74,38,116]	restock
2025-05-01 02:54:32.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.9487	2853	01ot_apiptB	[104,172,109,41]	added
2025-08-31 18:47:19.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.6951	2854	08baliwein_abjmB	[293,280,54,178]	restock
2025-06-22 11:48:39.411577	cam1	Baliwein	Sekala 750ml	0.9239	2855	08baliwein_sekB	[128,217,53,209]	added
2025-10-21 16:06:46.411577	cam1	Sapporo	330ml	0.7666	2856	49sapporoK	[323,47,132,125]	restock
2025-10-02 07:33:42.411577	cam1	Drum	Whisky Black 700ml	0.6861	2857	22drum_wbB	[152,371,238,150]	added
2025-11-27 18:45:01.411577	cam1	Rajawali	Prost 620ml	0.7656	2858	19rajawali_prostB	[345,11,238,133]	restock
2025-05-29 08:38:42.411577	cam1	Beaches	Cerveza 330ml	0.795	2859	32beachescK	[318,67,209,209]	restock
2025-10-16 03:27:26.411577	cam1	New City	1L	0.8153	2860	24newcityB	[299,312,248,216]	sold
2025-11-14 13:54:52.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.7042	2861	10kawa_hijauB	[164,97,108,221]	added
2025-08-15 12:43:25.411577	cam1	Rajawali	Prost 620ml	0.7121	2862	19rajawali_prostB	[159,327,140,38]	added
2025-10-10 04:48:53.411577	cam1	Kura Kura	Session Hazy 330ml	0.7543	2863	05kura_shK	[233,275,159,98]	added
2025-11-18 04:43:29.411577	cam1	Captain Morgan	Spice Gold 750ml	0.7835	2864	35cm_sgB	[271,393,78,240]	added
2025-10-25 07:12:50.411577	cam1	Kura Kura	Lager 330ml	0.9466	2865	05kura_lK	[77,217,107,116]	sold
2025-05-25 17:14:47.411577	cam1	Canard	Porter 330ml	0.6974	2866	04canard_pK	[377,190,218,55]	restock
2025-09-15 00:22:55.411577	cam1	Sababay	Ludisia 750ml	0.7965	2867	02sababay_lB	[128,338,34,202]	sold
2026-01-14 15:28:48.411577	cam1	Yakult	1 pack 325ml	0.7469	2868	60yakultK	[353,192,147,31]	restock
2025-09-09 01:07:35.411577	cam1	Suntory Roku	Gin 700ml	0.7326	2869	43rokuB	[42,311,198,117]	added
2025-10-16 00:18:46.411577	cam1	Cham Joeun	Lychee 360ml	0.9636	2870	40chamj_lS	[322,365,74,250]	added
2026-02-26 10:48:35.411577	cam1	Iceland	Berry Lemonade 275ml	0.8064	2871	03iceland_beleS	[273,59,167,159]	added
2025-04-10 22:48:50.411577	cam1	Baliwein	Semara 750ml	0.7421	2872	08baliwein_semB	[16,44,165,107]	restock
2025-12-08 18:08:54.411577	cam1	Canard	Kolsch 330ml	0.9095	2873	04canard_kK	[178,353,163,108]	added
2026-02-12 16:55:29.411577	cam1	Kulturale	L. L. Stout 330ml	0.9813	2874	09kulturale_llsK	[46,171,148,35]	sold
2026-01-12 18:41:03.411577	cam1	Gordon's	PinkPremium 750ml	0.9114	2875	44gordon_ppB	[377,16,46,171]	restock
2025-10-19 02:12:03.411577	cam1	Santai	Lemon & Lime 330ml	0.7362	2876	14santai_llK	[345,117,55,75]	sold
2026-01-28 05:35:19.411577	cam1	Kura Kura	IPA 330ml	0.8635	2877	05kura_ipaK	[83,362,155,117]	sold
2025-09-13 02:27:58.411577	cam1	Canard	Witbier 330ml	0.7953	2878	04canard_wK	[269,106,184,174]	sold
2025-03-20 11:42:12.411577	cam1	Canard	Weizenbock 330ml	0.9489	2879	04canard_weK	[153,109,105,200]	sold
2025-10-28 23:01:07.411577	cam1	Gilbey's	Whisky 350ml	0.9133	2880	37gilbeys_wS	[207,382,81,168]	added
2025-08-04 06:35:33.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.8578	2881	23palapaB	[156,205,117,243]	sold
2025-06-29 21:56:41.411577	cam1	Jagermeister	700ml	0.8329	2882	42jagermeisterB	[308,387,181,82]	restock
2025-10-12 20:27:08.411577	cam1	Chum Churum	Soju 360ml	0.9642	2883	12chumS	[368,178,66,227]	added
2025-11-24 09:19:39.411577	cam1	Vibe	Exotic Lychee 700ml	0.6803	2884	11vibe_elB	[322,174,93,193]	restock
2025-07-28 12:07:22.411577	cam1	Jagermeister	700ml	0.8231	2885	42jagermeisterB	[343,263,36,217]	added
2025-10-19 12:27:19.411577	cam1	Kulturale	Amarillo 330ml	0.9397	2886	09kulturale_aK	[128,115,120,119]	added
2025-04-01 01:41:58.411577	cam1	Iceland	Berry Lemonade 275ml	0.9447	2887	03iceland_beleS	[337,15,153,144]	sold
2025-03-19 23:35:02.411577	cam1	Corona	Extra 355ml	0.7519	2888	47corona_eS	[161,312,199,184]	added
2025-09-30 14:47:22.411577	cam1	Suntory Roku	Gin 700ml	0.7881	2889	43rokuB	[25,340,73,176]	sold
2025-08-04 17:29:14.411577	cam1	Bintang	Radler 330ml	0.6693	2890	06bintang_radlerS	[387,306,221,147]	added
2025-03-26 13:38:17.411577	cam1	Suntory Roku	Gin 700ml	0.9665	2891	43rokuB	[128,282,194,192]	added
2026-01-04 07:10:49.411577	cam1	Bullsit	Gin 500ml	0.8455	2892	16bullsit_gS	[233,235,78,181]	restock
2026-02-14 06:57:04.411577	cam1	Albens	Apple Cier 330ml	0.8055	2893	07albensS	[330,144,228,181]	added
2025-05-30 02:00:01.411577	cam1	Sababay	Black Velvet 750ml	0.9244	2894	02sababay_bvB	[11,229,159,195]	added
2025-09-07 18:48:06.411577	cam1	Iceland	Original 250ml	0.9821	2895	03icelandK	[108,134,154,169]	added
2026-01-08 10:07:07.411577	cam1	Bullsit	Gin 500ml	0.7921	2896	16bullsit_gS	[311,28,67,116]	added
2025-10-25 06:29:12.411577	cam1	Orang Tua	Anggur Putih 620ml	0.7211	2897	01ot_aputB	[78,375,175,250]	sold
2025-10-31 19:27:45.411577	cam1	Bullsit	Vodka 500ml	0.9557	2898	16bullsit_vS	[285,221,63,50]	sold
2025-07-21 02:44:49.411577	cam1	Canard	Weizenbock 330ml	0.9162	2899	04canard_weK	[357,314,52,235]	restock
2025-03-16 09:27:30.411577	cam1	Bullsit	Gin 500ml	0.7621	2900	16bullsit_gS	[133,79,138,75]	sold
2025-11-19 03:49:25.411577	cam1	Gilbey's	Gin 350ml	0.8041	2901	37gilbeys_gS	[198,96,96,105]	sold
2025-05-26 09:18:30.411577	cam1	Sababay	Ludisia 750ml	0.8129	2902	02sababay_lB	[88,371,205,64]	sold
2025-11-14 01:24:34.411577	cam1	Three Peaks	Dry Gin 700ml	0.8516	2903	33threep_dgB	[225,137,134,196]	added
2026-01-30 22:29:33.411577	cam1	Bacardi	Spiced Rum 750ml	0.9304	2904	36bacardi_srB	[103,62,247,166]	sold
2025-03-16 17:11:53.411577	cam1	Kura Kura	Island Ale 330ml	0.8379	2905	05kura_iaK	[293,78,153,82]	added
2026-02-12 19:45:07.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.6745	2906	01ot_atlasrpB	[188,216,172,66]	added
2026-01-18 09:46:44.411577	cam1	New City	1L	0.976	2907	24newcityB	[199,193,156,111]	sold
2025-03-25 12:54:58.411577	cam1	Canard	Strawberry Gose 330ml	0.7523	2908	04canard_sgK	[84,216,75,33]	added
2025-11-26 03:11:30.411577	cam1	Captain Morgan	Spice Gold 750ml	0.8862	2909	35cm_sgB	[343,373,116,173]	sold
2025-10-07 08:23:19.411577	cam1	Rajawali	Prost 620ml	0.8678	2910	19rajawali_prostB	[273,398,211,152]	restock
2026-02-27 20:47:46.411577	cam1	Iceland	Lychee Martini 275ml	0.9337	2911	03iceland_lmS	[154,147,128,119]	restock
2025-06-22 04:55:47.411577	cam1	Jagermeister	700ml	0.9136	2912	42jagermeisterB	[335,232,123,66]	added
2025-11-12 19:08:49.411577	cam1	Kulturale	L. L. Stout 330ml	0.9172	2913	09kulturale_llsK	[217,260,47,41]	added
2025-11-16 21:02:02.411577	cam1	Drum	Whisky Black 700ml	0.678	2914	22drum_wbB	[122,225,84,48]	restock
2025-08-16 12:10:28.411577	cam1	Kura Kura	Island Ale 330ml	0.8934	2915	05kura_iaK	[338,400,136,64]	sold
2026-02-13 11:51:13.411577	cam1	Iceland	Blue Lagoon 275ml	0.7026	2916	03iceland_blS	[164,166,196,211]	restock
2026-01-11 01:05:00.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.6866	2917	08baliwein_abjmB	[94,107,187,188]	added
2025-07-12 09:59:04.411577	cam1	Pu Tao Chee Chiew	330ml	0.8843	2918	31putaoccS	[157,111,169,218]	sold
2025-10-27 01:55:59.411577	cam1	Canard	Weizenbock 330ml	0.8132	2919	04canard_weK	[182,23,103,62]	restock
2025-07-07 18:46:07.411577	cam1	Albens	Apple Cier 330ml	0.8317	2920	07albensS	[152,14,200,169]	sold
2025-05-08 13:11:23.411577	cam1	Orang Tua	Anggur Putih 620ml	0.7272	2921	01ot_aputB	[341,398,127,136]	added
2025-07-24 20:51:15.411577	cam1	Kura Kura	Lager 330ml	0.7949	2922	05kura_lK	[27,371,160,234]	sold
2026-02-22 19:04:40.411577	cam1	New City	1L	0.8041	2923	24newcityB	[67,327,118,161]	sold
2025-09-12 22:05:01.411577	cam1	Bintang	Pilsener 620ml	0.9745	2924	06bintangB	[104,135,47,125]	sold
2025-08-06 05:24:37.411577	cam1	Cham Joeun	Lychee 360ml	0.843	2925	40chamj_lS	[26,117,181,174]	sold
2025-10-23 15:33:21.411577	cam1	Jameson	Irish Whiskey 700ml	0.901	2926	41jamesonB	[202,366,218,175]	restock
2025-09-04 16:39:35.411577	cam1	Sababay	Black Velvet 750ml	0.9083	2927	02sababay_bvB	[50,141,38,151]	sold
2025-09-18 06:37:48.411577	cam1	Iceland	Blue Lagoon 275ml	0.7716	2928	03iceland_blS	[98,251,132,56]	sold
2025-08-01 02:11:16.411577	cam1	Wija	Blueberry 360ml	0.6637	2929	15wija_bS	[270,251,206,239]	restock
2025-03-29 11:02:42.411577	cam1	Iceland	Original 700ml	0.7388	2930	03icelandB	[270,165,125,128]	sold
2026-02-11 09:43:53.411577	cam1	Heineken	330ml	0.8642	2931	46heinekenS	[199,260,120,233]	sold
2025-09-15 23:23:09.411577	cam1	Canard	Porter 330ml	0.7517	2932	04canard_pK	[33,287,97,143]	added
2026-03-04 18:00:25.411577	cam1	Gilbey's	Whisky 350ml	0.9113	2933	37gilbeys_wS	[93,24,169,177]	restock
2025-04-24 09:03:19.411577	cam1	Polaris	Soda Water 330ml	0.7174	2934	54polarisK	[249,49,92,33]	restock
2025-09-24 07:41:00.411577	cam1	Captain Morgan	Spice Gold 750ml	0.9114	2935	35cm_sgB	[261,78,98,202]	sold
2025-04-19 03:12:02.411577	cam1	Orang Tua	Anggur Merah 620ml	0.8312	2936	01ot_amerB	[197,73,155,36]	added
2026-02-08 18:31:38.411577	cam1	Canard	Weizenbock 330ml	0.8166	2937	04canard_weK	[121,291,86,43]	sold
2025-05-03 08:20:17.411577	cam1	Baliwein	Anggur Salak 750ml	0.6672	2938	08baliwein_absB	[187,221,199,168]	added
2025-09-23 15:14:03.411577	cam1	Vibe	Black Tea 700ml	0.9516	2939	11vibe_btB	[62,169,103,232]	added
2025-08-31 03:49:26.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.9379	2940	10kawa_hijauB	[241,227,244,46]	sold
2025-07-06 13:38:40.411577	cam1	Bullsit	Gin 500ml	0.895	2941	16bullsit_gS	[294,228,31,204]	added
2025-10-30 04:37:59.411577	cam1	Beaches	Cerveza 330ml	0.6631	2942	32beachescK	[342,317,206,129]	restock
2025-03-19 14:30:43.411577	cam1	Kura Kura	IPA 330ml	0.7986	2943	05kura_ipaK	[391,354,162,249]	sold
2025-09-16 13:58:56.411577	cam1	Guiness	Draught Stout 500ml	0.7317	2944	34guiness_dsBC	[270,199,74,147]	added
2025-10-11 01:03:10.411577	cam1	Canard	Session IPA 330ml	0.9112	2945	04canard_siK	[296,373,166,185]	sold
2025-12-08 02:52:57.411577	cam1	Rajawali	Prost Apple Lime 320ml	0.9516	2946	19rajawali_prostalK	[223,38,220,246]	restock
2025-07-21 03:04:48.411577	cam1	Heineken	330ml	0.6712	2947	46heinekenS	[211,130,125,119]	added
2025-11-11 02:30:49.411577	cam1	Orang Tua	Intisari Blackcurrant 620ml	0.6944	2948	01ot_bcintB	[275,82,62,84]	restock
2025-05-18 03:51:59.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.9757	2949	01ot_atlasrpB	[313,215,77,52]	sold
2025-12-07 16:57:43.411577	cam1	Bintang	Pilsener 620ml	0.9108	2950	06bintangB	[265,340,60,36]	restock
2025-06-11 06:14:27.411577	cam1	Wija	Lychee 360ml	0.8386	2951	15wija_lS	[211,40,78,193]	restock
2026-01-29 04:40:52.411577	cam1	Orang Tua	Singaraja 620ml	0.7727	2952	01ot_singarajaB	[21,262,159,107]	restock
2025-10-17 06:14:19.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.9668	2953	08baliwein_abjmB	[160,278,143,145]	restock
2025-09-20 03:04:21.411577	cam1	Orang Tua	Atlas Lychee 620ml	0.6632	2954	01ot_atlaslB	[226,243,128,248]	sold
2026-02-12 11:40:33.411577	cam1	Kura Kura	Easy Ale 330ml	0.6789	2955	05kura_eaK	[329,392,59,109]	sold
2025-05-07 18:55:59.411577	cam1	Orang Tua	Singaraja 620ml	0.9276	2956	01ot_singarajaB	[358,144,120,188]	added
2025-06-20 10:31:31.411577	cam1	Kulturale	Amarillo 330ml	0.9405	2957	09kulturale_aK	[360,203,198,180]	sold
2026-02-05 13:16:44.411577	cam1	Orang Tua	Atlas Rose Pink 620ml	0.789	2958	01ot_atlasrpB	[44,105,191,52]	added
2025-04-21 16:24:47.411577	cam1	Santai	Passionfruit & Guava 330ml	0.7901	2959	14santai_pgK	[104,22,149,49]	added
2025-03-12 18:30:39.411577	cam1	Kulturale	Amarillo 330ml	0.7762	2960	09kulturale_aK	[256,35,222,145]	added
2025-12-30 12:39:42.411577	cam1	Suntory Roku	Gin 700ml	0.7731	2961	43rokuB	[33,217,121,108]	restock
2025-12-20 08:14:56.411577	cam1	Kura Kura	Island Ale 330ml	0.9168	2962	05kura_iaK	[54,106,206,224]	sold
2025-11-10 11:50:09.411577	cam1	Sababay	Mascetti 750ml	0.7861	2963	02sababay_masB	[372,60,250,50]	added
2025-04-13 05:23:45.411577	cam1	Kulturale	Bravo 330ml	0.7661	2964	09kulturale_bK	[249,150,37,155]	restock
2025-09-20 15:19:34.411577	cam1	Iceland	Berry Lemonade 275ml	0.7727	2965	03iceland_beleS	[103,328,156,142]	sold
2025-08-04 13:37:55.411577	cam1	Vibe	Black Tea 700ml	0.9123	2966	11vibe_btB	[60,385,106,198]	added
2025-12-23 12:27:31.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.8044	2967	10kawa_hijauB	[285,207,52,83]	restock
2025-09-16 16:19:30.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.693	2968	23palapaB	[93,82,226,189]	sold
2025-09-25 20:31:06.411577	cam1	Three Peaks	Dry Gin 700ml	0.9885	2969	33threep_dgB	[144,268,116,219]	sold
2026-02-24 21:32:37.411577	cam1	Rajawali	Prost 620ml	0.9104	2970	19rajawali_prostB	[331,114,175,173]	sold
2025-12-20 14:29:02.411577	cam1	Baileys	Irish Cream 750ml	0.8647	2971	51baileys_icB	[296,189,186,155]	added
2025-07-20 04:15:00.411577	cam1	Kura Kura	IPA 330ml	0.9031	2972	05kura_ipaK	[43,170,98,185]	added
2025-10-28 17:49:36.411577	cam1	Yakult	1 pack 325ml	0.805	2973	60yakultK	[124,355,73,150]	sold
2025-09-14 12:47:36.411577	cam1	Sprite	390ml	0.9886	2974	59spriteK	[177,89,76,81]	added
2025-03-14 04:52:13.411577	cam1	Canard	Weizenbock 330ml	0.9563	2975	04canard_weK	[331,215,190,164]	sold
2025-03-22 01:32:21.411577	cam1	Palapa	Nutmeg Liqueur 700ml	0.9371	2976	23palapaB	[38,284,132,133]	added
2025-11-05 06:34:41.411577	cam1	Extra Joss	Ultimate 250ml	0.6625	2977	53extrajK	[18,395,94,80]	restock
2026-03-06 13:36:29.411577	cam1	Kulturale	L. L. Stout 330ml	0.8513	2978	09kulturale_llsK	[117,194,148,88]	added
2025-03-15 22:10:17.411577	cam1	Corona	Extra 355ml	0.6974	2979	47corona_eS	[139,17,143,38]	added
2025-07-29 08:44:42.411577	cam1	Kura Kura	Island Ale 330ml	0.6776	2980	05kura_iaK	[29,261,157,234]	restock
2025-11-27 19:29:06.411577	cam1	Kulturale	Naganini 330ml	0.6925	2981	09kulturale_nbwK	[391,50,189,112]	sold
2025-04-22 00:46:09.411577	cam1	Canard	Porter 330ml	0.6523	2982	04canard_pK	[284,325,237,80]	restock
2025-06-25 07:29:40.411577	cam1	Captain Morgan	Spice Gold 750ml	0.9237	2983	35cm_sgB	[248,85,53,199]	added
2025-09-07 03:21:58.411577	cam1	Jameson	Irish Whiskey 700ml	0.8115	2984	41jamesonB	[199,325,63,96]	sold
2025-03-12 19:54:05.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.9386	2985	01ot_amergoldB	[170,298,222,174]	sold
2025-06-23 00:46:24.411577	cam1	Gilbey's	Whisky 350ml	0.945	2986	37gilbeys_wS	[63,295,213,164]	added
2026-01-18 06:09:55.411577	cam1	Vibe	Black Tea 700ml	0.6516	2987	11vibe_btB	[210,187,236,167]	sold
2026-02-09 08:43:10.411577	cam1	Vibe	Black Tea 700ml	0.7442	2988	11vibe_btB	[187,286,114,72]	added
2025-08-20 03:31:51.411577	cam1	Kulturale	Amarillo 330ml	0.9292	2989	09kulturale_aK	[94,85,115,233]	restock
2025-04-06 02:03:47.411577	cam1	Albens	Apple Mango Cider 330ml	0.9439	2990	07albens_amcS	[220,98,116,52]	restock
2025-07-24 19:08:01.411577	cam1	Bintang	Pilsener 330ml	0.7294	2991	06bintangK	[350,51,103,113]	added
2025-09-03 02:57:36.411577	cam1	Baileys	Irish Cream 750ml	0.7509	2992	51baileys_icB	[103,289,230,182]	restock
2025-08-06 20:10:07.411577	cam1	Chum Churum	Soju 360ml	0.73	2993	12chumS	[298,21,38,107]	added
2026-03-09 11:48:55.411577	cam1	Iceland	Blue Lagoon 275ml	0.7413	2994	03iceland_blS	[34,364,116,182]	sold
2025-07-22 17:21:58.411577	cam1	Santai	Lemon & Lime 330ml	0.7507	2995	14santai_llK	[280,317,173,55]	added
2025-10-16 17:22:28.411577	cam1	Sprite	390ml	0.7276	2996	59spriteK	[68,225,247,36]	added
2025-11-09 10:19:59.411577	cam1	Smirnoff	Vodka 700ml	0.8803	2997	45smirnoffB	[263,226,155,112]	sold
2026-01-20 19:06:33.411577	cam1	Iceland	Lychee Martini 275ml	0.9586	2998	03iceland_lmS	[109,367,167,111]	added
2025-09-28 20:26:45.411577	cam1	Kura Kura	Island Ale 330ml	0.6567	2999	05kura_iaK	[45,49,184,173]	restock
2025-07-31 11:54:48.411577	cam1	Bintang	Pilsener 500ml	0.7295	3000	06bintangBC	[130,28,103,38]	restock
2025-06-04 12:56:06.411577	cam1	Three Peaks	Dry Gin 700ml	0.6709	3001	33threep_dgB	[290,179,69,102]	sold
2025-05-28 02:13:57.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.7397	3002	10kawa_bcB	[82,138,130,92]	added
2026-01-25 02:20:44.411577	cam1	Kura Kura	Lager 330ml	0.7228	3003	05kura_lK	[264,67,55,168]	sold
2025-05-28 16:04:06.411577	cam1	Santai	Passionfruit & Guava 330ml	0.6581	3004	14santai_pgK	[304,195,237,234]	added
2025-07-31 08:57:23.411577	cam1	Sababay	Mascetti 750ml	0.7672	3005	02sababay_masB	[320,335,202,126]	restock
2025-12-20 06:16:48.411577	cam1	Bullsit	Whisky 500ml	0.7111	3006	16bullsit_wS	[292,303,182,52]	restock
2025-08-11 09:36:01.411577	cam1	Gilbey's	Gin 350ml	0.7714	3007	37gilbeys_gS	[91,67,154,208]	sold
2026-03-04 09:30:45.411577	cam1	Orang Tua	Atlas Lychee 620ml	0.835	3008	01ot_atlaslB	[318,123,99,98]	added
2025-05-10 22:01:00.411577	cam1	Bintang	Pilsener 330ml	0.752	3009	06bintangK	[85,343,232,128]	added
2025-08-25 14:39:58.411577	cam1	Kura Kura	Island Ale 330ml	0.7032	3010	05kura_iaK	[237,216,165,146]	added
2025-12-18 22:24:16.411577	cam1	Asahi	Super Dry 334ml	0.8023	3011	48asahiK	[59,230,188,179]	sold
2026-02-23 09:33:11.411577	cam1	Vibe	Exotic Lychee 700ml	0.7014	3012	11vibe_elB	[387,126,43,202]	sold
2025-04-20 22:33:31.411577	cam1	Guiness	Foreign Extra Stout 320ml	0.7326	3013	34guinessK_fesKC	[116,101,34,139]	restock
2025-09-20 13:32:49.411577	cam1	Pokka	Green Tea 300ml	0.8164	3014	57pokkaK	[110,262,191,244]	restock
2025-12-15 15:05:08.411577	cam1	Santai	Lemon & Lime 330ml	0.961	3015	14santai_llK	[218,196,235,61]	added
2026-03-09 02:01:16.411577	cam1	Smirnoff	Vodka 700ml	0.7245	3016	45smirnoffB	[92,279,166,200]	restock
2025-09-20 02:52:50.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.92	3017	10kawa_bcB	[163,342,52,61]	restock
2025-07-10 19:33:56.411577	cam1	Bintang	Radler 330ml	0.9473	3018	06bintang_radlerS	[328,221,116,140]	sold
2026-03-09 10:01:25.411577	cam1	Royal Brewhouse	Black Royale 350ml	0.9176	3019	18rb_brS	[386,377,61,73]	restock
2025-04-14 05:55:32.411577	cam1	Santai	Lemon & Lime 330ml	0.7183	3020	14santai_llK	[22,22,72,177]	sold
2025-12-17 17:28:09.411577	cam1	Orang Tua	Arak Obat 620ml	0.8304	3021	01ot_aoB	[239,189,32,135]	sold
2025-06-04 01:28:14.411577	cam1	Bintang	Pilsener 500ml	0.8306	3022	06bintangBC	[325,162,166,198]	sold
2025-11-21 04:47:40.411577	cam1	Baliwein	Semara 750ml	0.8078	3023	08baliwein_semB	[148,201,121,160]	restock
2025-09-13 10:47:30.411577	cam1	Kawa Kawa	Blackcurrant 600ml	0.7879	3024	10kawa_bcB	[183,235,97,127]	restock
2025-03-25 07:33:02.411577	cam1	Gilbey's	Whisky 350ml	0.9426	3025	37gilbeys_wS	[84,209,72,88]	sold
2026-02-26 21:27:28.411577	cam1	Royal Brewhouse	Black Royale 350ml	0.8775	3026	18rb_brS	[394,88,141,36]	added
2025-07-06 20:35:49.411577	cam1	Sababay	Black Velvet 750ml	0.8022	3027	02sababay_bvB	[136,309,184,95]	added
2025-04-12 05:27:46.411577	cam1	Beaches	Cerveza 330ml	0.8829	3028	32beachescK	[369,309,144,171]	restock
2025-10-30 13:38:52.411577	cam1	Bintang	Radler 330ml	0.7125	3029	06bintang_radlerS	[90,386,156,67]	restock
2025-11-10 00:42:53.411577	cam1	Orang Tua	Arak Obat 620ml	0.876	3030	01ot_aoB	[358,219,71,63]	sold
2025-09-17 18:00:44.411577	cam1	Orang Tua	Anggur Putih 620ml	0.928	3031	01ot_aputB	[337,309,176,101]	sold
2025-06-25 00:49:24.411577	cam1	Bullsit	Gin 500ml	0.9817	3032	16bullsit_gS	[24,178,91,67]	restock
2025-08-22 08:12:26.411577	cam1	Kulturale	Amarillo 330ml	0.8829	3033	09kulturale_aK	[195,52,43,61]	restock
2025-08-07 06:19:50.411577	cam1	Kawa Kawa	Anggur Merah 600ml	0.9794	3034	10kawa_merahB	[87,70,91,99]	added
2025-11-20 16:26:50.411577	cam1	Bullsit	Gin 500ml	0.8126	3035	16bullsit_gS	[366,334,78,73]	added
2025-05-07 22:46:38.411577	cam1	Bintang	Pilsener 620ml	0.7755	3036	06bintangB	[389,306,141,141]	sold
2026-02-16 18:52:48.411577	cam1	Guiness	Foreign Extra Stout 620ml	0.7015	3037	34guiness_fesB	[236,163,186,95]	restock
2025-09-03 12:13:42.411577	cam1	Sababay	Ludisia 750ml	0.7076	3038	02sababay_lB	[389,151,231,74]	added
2025-11-14 15:12:55.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.914	3039	01ot_amergoldB	[209,281,159,158]	restock
2025-08-23 11:47:42.411577	cam1	Kulturale	N. R. K. DIPA 330ml	0.8403	3040	09kulturale_nrkK	[95,37,240,48]	sold
2025-11-03 20:34:05.411577	cam1	Rajawali	Prost 620ml	0.8915	3041	19rajawali_prostB	[101,346,229,138]	added
2025-06-29 23:00:56.411577	cam1	Cham Joeun	Soju 360ml	0.8414	3042	40chamjS	[330,205,239,67]	restock
2025-06-04 17:51:18.411577	cam1	Batavia	Whisky 700ml	0.825	3043	21bataviaB	[83,10,133,99]	restock
2025-08-08 06:29:05.411577	cam1	New City	1L	0.9032	3044	24newcityB	[27,212,125,173]	sold
2025-04-08 14:40:07.411577	cam1	Gilbey's	Whisky 350ml	0.8366	3045	37gilbeys_wS	[196,162,100,127]	restock
2025-11-23 20:24:30.411577	cam1	Asahi	Super Dry 334ml	0.7411	3046	48asahiK	[33,208,155,151]	sold
2025-11-23 12:28:31.411577	cam1	Orang Tua	Atlas Lychee 620ml	0.8339	3047	01ot_atlaslB	[386,155,119,176]	sold
2025-10-29 20:05:24.411577	cam1	Bullsit	Gin 500ml	0.9459	3048	16bullsit_gS	[175,320,132,113]	added
2025-10-07 19:37:17.411577	cam1	Kulturale	L. L. Stout 330ml	0.8311	3049	09kulturale_llsK	[142,210,57,76]	added
2026-02-18 22:43:45.411577	cam1	Vibe	Black Tea 700ml	0.9029	3050	11vibe_btB	[189,343,155,38]	sold
2026-01-04 09:00:02.411577	cam1	Canard	Weizenbock 330ml	0.6865	3051	04canard_weK	[283,350,160,211]	added
2025-07-30 06:54:25.411577	cam1	Crystalline	330ml	0.7829	3052	55crystalinK	[357,95,33,116]	added
2026-01-18 09:57:44.411577	cam1	Iceland	Berry Lemonade 275ml	0.9451	3053	03iceland_beleS	[367,284,165,216]	restock
2025-11-20 12:56:37.411577	cam1	Wija	Soju 360ml	0.7786	3054	15wijaS	[350,200,107,152]	added
2026-01-01 19:12:35.411577	cam1	Smirnoff	Vodka 700ml	0.6535	3055	45smirnoffB	[186,256,156,190]	sold
2025-06-18 17:20:45.411577	cam1	Sababay	Pink Blossom 750ml	0.9552	3056	02sababay_pbB	[353,14,165,181]	restock
2025-07-18 16:54:09.411577	cam1	Bintang	Pilsener 500ml	0.8599	3057	06bintangBC	[314,186,119,170]	added
2025-06-21 09:05:24.411577	cam1	Bintang	Pilsener 620ml	0.8919	3058	06bintangB	[195,23,180,248]	sold
2025-04-16 21:47:28.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.8269	3059	01ot_apiptB	[281,122,203,244]	sold
2025-07-24 15:51:32.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.6987	3060	01ot_apiptB	[377,146,190,233]	sold
2025-06-20 02:15:38.411577	cam1	Canard	Porter 330ml	0.7801	3061	04canard_pK	[217,378,152,215]	added
2025-11-26 11:32:19.411577	cam1	Iceland	Berry Lemonade 275ml	0.669	3062	03iceland_beleS	[166,258,126,89]	sold
2025-06-13 09:21:24.411577	cam1	Drum	Whisky Black 700ml	0.7863	3063	22drum_wbB	[208,98,75,242]	sold
2025-06-25 22:14:27.411577	cam1	Polaris	Soda Water 330ml	0.9702	3064	54polarisK	[282,85,74,135]	restock
2025-12-25 12:13:27.411577	cam1	Bintang	Pilsener 500ml	0.9458	3065	06bintangBC	[362,119,77,58]	restock
2026-01-30 12:49:59.411577	cam1	Kulturale	Bravo 330ml	0.7833	3066	09kulturale_bK	[354,287,138,52]	added
2025-08-30 05:46:44.411577	cam1	Canard	Weizenbock 330ml	0.8032	3067	04canard_weK	[196,305,241,238]	sold
2025-09-02 21:12:27.411577	cam1	Captain Morgan	Spice Gold 750ml	0.8152	3068	35cm_sgB	[336,263,210,223]	added
2025-09-15 08:34:35.411577	cam1	Kulturale	N. R. K. DIPA 330ml	0.9298	3069	09kulturale_nrkK	[289,335,53,37]	restock
2025-08-16 02:05:47.411577	cam1	Sababay	Ludisia 750ml	0.9816	3070	02sababay_lB	[147,190,163,234]	restock
2025-12-14 05:48:47.411577	cam1	Crystalline	330ml	0.7818	3071	55crystalinK	[295,325,135,46]	sold
2025-10-16 00:38:37.411577	cam1	Extra Joss	Ultimate 250ml	0.8331	3072	53extrajK	[240,233,246,230]	restock
2025-05-05 19:21:24.411577	cam1	Canard	Weizenbock 330ml	0.8522	3073	04canard_weK	[229,145,207,120]	sold
2025-07-21 15:33:41.411577	cam1	Iceland	Original 250ml	0.7979	3074	03icelandK	[141,371,212,31]	restock
2025-08-25 03:32:02.411577	cam1	Bintang	Pilsener 500ml	0.6746	3075	06bintangBC	[333,362,41,230]	restock
2025-09-13 17:17:59.411577	cam1	Chum Churum	Soju 360ml	0.7716	3076	12chumS	[338,12,224,202]	sold
2025-10-22 12:15:37.411577	cam1	Cham Joeun	Soju 360ml	0.7997	3077	40chamjS	[265,364,128,182]	restock
2025-05-23 09:37:16.411577	cam1	Sababay	Ludisia 750ml	0.8414	3078	02sababay_lB	[90,283,95,203]	restock
2025-09-02 06:43:48.411577	cam1	Captain Morgan	Spice Gold 750ml	0.904	3079	35cm_sgB	[108,266,219,185]	added
2025-09-17 20:05:02.411577	cam1	Kura Kura	Island Ale 330ml	0.8031	3080	05kura_iaK	[276,382,203,197]	added
2026-01-03 08:19:18.411577	cam1	Beaches	Cerveza 330ml	0.7447	3081	32beachescK	[85,127,95,195]	restock
2025-07-29 07:18:35.411577	cam1	Iceland	Blue Lagoon 275ml	0.7184	3082	03iceland_blS	[88,273,200,217]	sold
2025-04-07 12:40:48.411577	cam1	Wija	Soju 360ml	0.6801	3083	15wijaS	[90,203,153,47]	sold
2025-03-26 16:16:58.411577	cam1	Kulturale	Naganini 330ml	0.7958	3084	09kulturale_nbwK	[388,53,224,97]	added
2025-03-30 07:47:02.411577	cam1	Captain Morgan	Silver Rum 750ml	0.7005	3085	35cm_ssB	[15,126,173,57]	restock
2025-10-07 06:32:55.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.7815	3086	01ot_apihjB	[380,248,242,164]	added
2025-07-22 23:46:01.411577	cam1	Wija	Soju 360ml	0.8288	3087	15wijaS	[345,295,162,229]	restock
2025-07-22 21:59:42.411577	cam1	Bintang	Pilsener 330ml	0.7231	3088	06bintangK	[25,346,166,215]	sold
2025-03-27 07:27:01.411577	cam1	Bintang	Pilsener 620ml	0.9306	3089	06bintangB	[391,306,91,47]	added
2026-02-03 02:17:21.411577	cam1	New City	1L	0.6824	3090	24newcityB	[143,281,218,132]	sold
2025-11-21 04:21:43.411577	cam1	Vibe	Exotic Lychee 700ml	0.9631	3091	11vibe_elB	[385,101,229,199]	added
2025-03-14 21:59:58.411577	cam1	Bacardi	Spiced Rum 750ml	0.6703	3092	36bacardi_srB	[172,252,38,120]	sold
2025-03-25 14:09:28.411577	cam1	Rajawali	Prost 620ml	0.9018	3093	19rajawali_prostB	[44,156,115,148]	sold
2026-01-10 06:53:29.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.8089	3094	01ot_apiptB	[344,297,229,39]	added
2025-09-27 19:18:52.411577	cam1	Iceland	Orange 700ml	0.7748	3095	03iceland_oB	[50,361,234,204]	sold
2025-07-19 10:42:25.411577	cam1	Kulturale	N. R. K. DIPA 330ml	0.7371	3096	09kulturale_nrkK	[24,192,40,113]	added
2026-02-15 09:00:19.411577	cam1	Jameson	Irish Whiskey 700ml	0.8078	3097	41jamesonB	[387,367,163,108]	added
2025-06-17 12:23:16.411577	cam1	Jameson	Irish Whiskey 700ml	0.8474	3098	41jamesonB	[64,106,201,140]	added
2025-11-27 22:27:48.411577	cam1	Orang Tua	API Anggur Putih 620ml	0.7712	3099	01ot_apiptB	[77,149,30,180]	added
2025-04-08 17:56:58.411577	cam1	Crystalline	330ml	0.9696	3100	55crystalinK	[361,293,42,45]	added
2025-08-23 07:41:39.411577	cam1	Baliwein	Anggur Jambu Mete 750ml	0.9418	3101	08baliwein_abjmB	[191,155,49,209]	added
2026-02-12 23:50:01.411577	cam1	New City	1L	0.919	3102	24newcityB	[106,125,73,49]	restock
2025-12-07 10:46:31.411577	cam1	Gilbey's	Whisky 350ml	0.8393	3103	37gilbeys_wS	[178,265,181,243]	sold
2025-11-15 13:59:55.411577	cam1	Canard	Session IPA 330ml	0.6828	3104	04canard_siK	[146,282,124,170]	sold
2025-09-15 08:27:30.411577	cam1	Orang Tua	Intisari Blackcurrant 620ml	0.8977	3105	01ot_bcintB	[201,332,183,173]	added
2025-11-22 17:47:10.411577	cam1	Orang Tua	API Anggur Hijau 620ml	0.9492	3106	01ot_apihjB	[376,196,47,218]	added
2025-07-23 04:35:20.411577	cam1	Iceland	Original 250ml	0.8295	3107	03icelandK	[371,43,240,148]	added
2025-12-27 18:11:22.411577	cam1	Orang Tua	Singaraja 620ml	0.9634	3108	01ot_singarajaB	[383,12,236,169]	restock
2026-01-17 01:10:33.411577	cam1	Kulturale	Bravo 330ml	0.858	3109	09kulturale_bK	[364,225,182,157]	sold
2025-05-19 05:31:52.411577	cam1	Sapporo	330ml	0.9447	3110	49sapporoK	[36,33,147,141]	restock
2026-01-10 19:12:00.411577	cam1	Kawa Kawa	Anggur Hijau 600ml	0.7516	3111	10kawa_hijauB	[15,43,106,101]	restock
2025-05-12 13:56:59.411577	cam1	New City	1L	0.6978	3112	24newcityB	[333,288,236,246]	restock
2026-02-19 19:36:00.411577	cam1	Santai	Passionfruit & Guava 330ml	0.8363	3113	14santai_pgK	[286,361,236,32]	added
2025-08-08 16:26:45.411577	cam1	Kura Kura	Island Ale 330ml	0.8229	3114	05kura_iaK	[125,397,171,244]	added
2025-11-06 18:30:19.411577	cam1	Baliwein	Anggur Salak 750ml	0.7301	3115	08baliwein_absB	[400,319,241,105]	restock
2025-05-14 14:40:47.411577	cam1	Vibe	Black Tea 700ml	0.7849	3116	11vibe_btB	[240,83,155,67]	restock
2025-03-24 14:53:30.411577	cam1	Bacardi	Spiced Rum 750ml	0.6836	3117	36bacardi_srB	[75,96,67,235]	restock
2025-07-12 06:26:52.411577	cam1	Canard	Strawberry Gose 330ml	0.7488	3118	04canard_sgK	[40,63,231,105]	restock
2025-05-27 16:14:54.411577	cam1	Albens	Apple Cier 330ml	0.8589	3119	07albensS	[37,78,133,100]	added
2026-02-12 12:10:51.411577	cam1	Kura Kura	Island Ale 330ml	0.6753	3120	05kura_iaK	[223,193,54,63]	sold
2025-09-02 17:31:11.411577	cam1	Canard	Strawberry Gose 330ml	0.7247	3121	04canard_sgK	[94,136,108,35]	restock
2025-06-07 02:36:53.411577	cam1	Gilbey's	Whisky 350ml	0.9484	3122	37gilbeys_wS	[40,51,242,113]	sold
2025-06-06 05:59:26.411577	cam1	Kulturale	Amarillo 330ml	0.9392	3123	09kulturale_aK	[315,298,112,37]	added
2025-10-08 10:34:08.411577	cam1	Pu Tao Chee Chiew	330ml	0.754	3124	31putaoccS	[219,298,166,185]	added
2026-02-14 02:16:39.411577	cam1	Albens	Apple Cier 330ml	0.7661	3125	07albensS	[97,32,197,235]	restock
2025-10-10 17:21:21.411577	cam1	Iceland	Blue Lagoon 275ml	0.8544	3126	03iceland_blS	[204,44,67,30]	restock
2025-09-21 18:14:08.411577	cam1	Canard	Weizenbock 330ml	0.8587	3127	04canard_weK	[252,64,63,81]	sold
2025-07-12 15:42:45.411577	cam1	Batavia	Whisky 700ml	0.9698	3128	21bataviaB	[126,332,249,47]	sold
2026-01-30 23:56:38.411577	cam1	Orang Tua	Anggur Merah 275ml	0.8055	3129	01ot_amerS	[364,160,116,235]	sold
2025-07-21 20:56:09.411577	cam1	Cham Joeun	Soju 360ml	0.9387	3130	40chamjS	[313,220,157,206]	sold
2025-11-26 00:43:48.411577	cam1	Beaches	Cerveza 330ml	0.728	3131	32beachescK	[231,377,158,205]	sold
2025-06-25 02:44:21.411577	cam1	Orang Tua	Singaraja 620ml	0.7696	3132	01ot_singarajaB	[376,197,36,138]	added
2025-03-23 18:31:33.411577	cam1	Orang Tua	Anggur Merah Gold 620ml	0.9669	3133	01ot_amergoldB	[380,115,89,160]	sold
2025-06-29 02:48:36.411577	cam1	Extra Joss	Ultimate 250ml	0.7868	3134	53extrajK	[189,272,45,101]	added
2026-03-01 02:21:34.411577	cam1	Kulturale	L. L. Stout 330ml	0.6908	3135	09kulturale_llsK	[55,254,155,177]	restock
2025-08-02 17:41:28.411577	cam1	Pokka	Green Tea 300ml	0.8604	3136	57pokkaK	[10,75,129,81]	added
2026-02-25 01:19:58.411577	cam1	Captain Morgan	Spice Gold 750ml	0.7023	3137	35cm_sgB	[263,84,131,234]	added
2025-04-14 20:48:00.411577	cam1	Smirnoff	Vodka 700ml	0.7215	3138	45smirnoffB	[253,171,250,219]	added
2025-10-26 10:49:16.411577	cam1	Pu Tao Chee Chiew	330ml	0.6813	3139	31putaoccS	[299,263,142,32]	added
2026-02-11 00:28:27.411577	cam1	New City	1L	0.8692	3140	24newcityB	[299,16,247,173]	sold
2025-10-15 11:24:44.411577	cam1	Orang Tua	Intisari Anggur Hijau 620ml	0.7354	3141	01ot_hijauintB	[158,370,36,137]	restock
2025-11-22 22:38:02.411577	cam1	Santai	Passionfruit & Guava 330ml	0.952	3142	14santai_pgK	[189,16,178,52]	added
2025-04-04 04:13:46.411577	cam1	Royal Brewhouse	Gold Royale 350ml	0.6803	3143	18rb_grS	[235,77,73,37]	added
2026-02-03 15:58:56.411577	cam1	Guiness	Foreign Extra Stout 320ml	0.9243	3144	34guinessK_fesKC	[320,336,177,243]	sold
2025-05-30 03:52:31.411577	cam1	Jose Cuervo	750ml	0.8636	3145	50josecuervoB	[316,365,58,229]	sold
2026-03-01 09:51:39.411577	cam1	Albens	Apple Cier 330ml	0.8978	3146	07albensS	[374,37,60,155]	sold
2025-11-10 08:21:31.411577	cam1	Jagermeister	700ml	0.8603	3147	42jagermeisterB	[332,229,56,110]	sold
2025-10-12 15:49:51.411577	cam1	Guiness	Foreign Extra Stout 320ml	0.6644	3148	34guinessK_fesKC	[156,382,152,103]	sold
2026-02-12 03:02:04.411577	cam1	Sababay	Black Velvet 750ml	0.8182	3149	02sababay_bvB	[31,64,35,202]	sold
2025-03-16 04:01:38.411577	cam1	Kura Kura	Lager 330ml	0.7658	3150	05kura_lK	[127,391,76,177]	restock
\.


--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: birmas_user
--

COPY public.product (class_id, class_name, product_brand, product_name) FROM stdin;
0	01ot_amerB	Orang Tua	Anggur Merah 620ml
1	01ot_amergoldB	Orang Tua	Anggur Merah Gold 620ml
2	01ot_amerS	Orang Tua	Anggur Merah 275ml
3	01ot_aoB	Orang Tua	Arak Obat 620ml
4	01ot_apihjB	Orang Tua	API Anggur Hijau 620ml
5	01ot_apiptB	Orang Tua	API Anggur Putih 620ml
6	01ot_aputB	Orang Tua	Anggur Putih 620ml
7	01ot_atlaslB	Orang Tua	Atlas Lychee 620ml
8	01ot_atlasrpB	Orang Tua	Atlas Rose Pink 620ml
9	01ot_bcintB	Orang Tua	Intisari Blackcurrant 620ml
10	01ot_hijauintB	Orang Tua	Intisari Anggur Hijau 620ml
11	01ot_singarajaB	Orang Tua	Singaraja 620ml
12	02sababay_bvB	Sababay	Black Velvet 750ml
13	02sababay_lB	Sababay	Ludisia 750ml
14	02sababay_masB	Sababay	Mascetti 750ml
15	02sababay_pbB	Sababay	Pink Blossom 750ml
16	03iceland_beleS	Iceland	Berry Lemonade 275ml
17	03iceland_blS	Iceland	Blue Lagoon 275ml
18	03iceland_lmS	Iceland	Lychee Martini 275ml
19	03iceland_oB	Iceland	Orange 700ml
20	03icelandB	Iceland	Original 700ml
21	03icelandK	Iceland	Original 250ml
22	04canard_kK	Canard	Kolsch 330ml
23	04canard_pK	Canard	Porter 330ml
24	04canard_sgK	Canard	Strawberry Gose 330ml
25	04canard_siK	Canard	Session IPA 330ml
26	04canard_weK	Canard	Weizenbock 330ml
27	04canard_wK	Canard	Witbier 330ml
28	05kura_eaK	Kura Kura	Easy Ale 330ml
29	05kura_iaK	Kura Kura	Island Ale 330ml
30	05kura_ipaK	Kura Kura	IPA 330ml
31	05kura_lK	Kura Kura	Lager 330ml
32	05kura_shK	Kura Kura	Session Hazy 330ml
33	06bintang_radlerS	Bintang	Radler 330ml
34	06bintangB	Bintang	Pilsener 620ml
35	06bintangBC	Bintang	Pilsener 500ml
36	06bintangK	Bintang	Pilsener 330ml
37	07albens_alcS	Albens	Apple Lychee Cider 330ml
38	07albens_amcS	Albens	Apple Mango Cider 330ml
39	07albensS	Albens	Apple Cier 330ml
40	08baliwein_abjmB	Baliwein	Anggur Jambu Mete 750ml
41	08baliwein_absB	Baliwein	Anggur Salak 750ml
42	08baliwein_sekB	Baliwein	Sekala 750ml
43	08baliwein_semB	Baliwein	Semara 750ml
44	09kulturale_aK	Kulturale	Amarillo 330ml
45	09kulturale_bK	Kulturale	Bravo 330ml
46	09kulturale_llsK	Kulturale	L. L. Stout 330ml
47	09kulturale_nbwK	Kulturale	Naganini 330ml
48	09kulturale_nrkK	Kulturale	N. R. K. DIPA 330ml
49	10kawa_bcB	Kawa Kawa	Blackcurrant 600ml
50	10kawa_hijauB	Kawa Kawa	Anggur Hijau 600ml
51	10kawa_merahB	Kawa Kawa	Anggur Merah 600ml
52	11vibe_btB	Vibe	Black Tea 700ml
53	11vibe_elB	Vibe	Exotic Lychee 700ml
54	12chum_pS	Chum Churum	Peach 360ml
55	12chum_yS	Chum Churum	Yogurt 360ml
56	12chumS	Chum Churum	Soju 360ml
57	14santai_agaK	Santai	Apple Ginger & Acai 330ml
58	14santai_llK	Santai	Lemon & Lime 330ml
59	14santai_pgK	Santai	Passionfruit & Guava 330ml
60	15wija_bS	Wija	Blueberry 360ml
61	15wija_lS	Wija	Lychee 360ml
62	15wijaS	Wija	Soju 360ml
63	16bullsit_gS	Bullsit	Gin 500ml
64	16bullsit_vS	Bullsit	Vodka 500ml
65	16bullsit_wS	Bullsit	Whisky 500ml
66	18rb_brS	Royal Brewhouse	Black Royale 350ml
67	18rb_grS	Royal Brewhouse	Gold Royale 350ml
68	19rajawali_prostalK	Rajawali	Prost Apple Lime 320ml
69	19rajawali_prostB	Rajawali	Prost 620ml
70	21bataviaB	Batavia	Whisky 700ml
71	22drum_wbB	Drum	Whisky Black 700ml
72	23palapaB	Palapa	Nutmeg Liqueur 700ml
73	24newcityB	New City	1L
74	31putaoccS	Pu Tao Chee Chiew	330ml
75	32beachescK	Beaches	Cerveza 330ml
76	33threep_dgB	Three Peaks	Dry Gin 700ml
77	34guiness_dsBC	Guiness	Draught Stout 500ml
78	34guiness_fesB	Guiness	Foreign Extra Stout 620ml
79	34guinessK_fesKC	Guiness	Foreign Extra Stout 320ml
80	35cm_sgB	Captain Morgan	Spice Gold 750ml
81	35cm_ssB	Captain Morgan	Silver Rum 750ml
82	36bacardi_cbB	Bacardi	Carta Blanca 750ml
83	36bacardi_srB	Bacardi	Spiced Rum 750ml
84	37gilbeys_gS	Gilbey's	Gin 350ml
85	37gilbeys_wS	Gilbey's	Whisky 350ml
86	40chamj_lS	Cham Joeun	Lychee 360ml
87	40chamjS	Cham Joeun	Soju 360ml
88	41jamesonB	Jameson	Irish Whiskey 700ml
89	42jagermeisterB	Jagermeister	700ml
90	43rokuB	Suntory Roku	Gin 700ml
91	44gordon_ppB	Gordon's	PinkPremium 750ml
92	45smirnoffB	Smirnoff	Vodka 700ml
93	46heinekenS	Heineken	330ml
94	47corona_eS	Corona	Extra 355ml
95	48asahiK	Asahi	Super Dry 334ml
96	49sapporoK	Sapporo	330ml
97	50josecuervoB	Jose Cuervo	750ml
98	51baileys_icB	Baileys	Irish Cream 750ml
99	53extrajK	Extra Joss	Ultimate 250ml
100	54polarisK	Polaris	Soda Water 330ml
101	55crystalinK	Crystalline	330ml
102	57pokkaK	Pokka	Green Tea 300ml
103	59spriteK	Sprite	390ml
104	60yakultK	Yakult	1 pack 325ml
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: birmas_user
--

COPY public.users (id, username, password_hash) FROM stdin;
7	admin	$2b$12$CFYMsbsfsZD5K4J40XNepec4sjg2QFP6H.wt7QIsiwlMEhdrth.ja
8	admin1	$2b$12$y2BHYkA1gEvTL7IICnJhwO63KY5bB8ku1S7ge2XBP6YHtI2yjlGiu
\.


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: birmas_user
--

SELECT pg_catalog.setval('public.events_id_seq', 4, true);


--
-- Name: events_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: birmas_user
--

SELECT pg_catalog.setval('public.events_id_seq1', 3150, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: birmas_user
--

SELECT pg_catalog.setval('public.users_id_seq', 8, true);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: birmas_user
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: birmas_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_events_id; Type: INDEX; Schema: public; Owner: birmas_user
--

CREATE INDEX ix_events_id ON public.events USING btree (ts);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: birmas_user
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: birmas_user
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- PostgreSQL database dump complete
--

\unrestrict 05nu6niK3oEZ5lGiYGPov4aYshcx3MYBUqHLe167PFvLZLNZNyH0fwFiJFZfPFN

